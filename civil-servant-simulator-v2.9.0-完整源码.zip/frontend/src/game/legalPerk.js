/**
 * 政法五条线专属特权与双刃剑（2.7.0）——纯配置与纯函数层。
 *
 * 本文件**不 import engine / sentiment**，也不就地改 state：
 * 它只回答「这条线有什么特权、数值怎么调」，把改状态的动作留给
 * engine.js（advanceQuarter 里的被动结算）与 GameMain（主动技能按钮）。
 * 依赖方向是单向的：engine → legalPerk，反过来不行——engine 是回合引擎，
 * 让它依赖一层特权配置是安全的，让特权层反过来依赖 engine 就绕成环了。
 */

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

/** 政法序列五条线（与 UNIT_TYPES 的政法子集一致，供校验与遍历） */
export const LEGAL_TRACKS = ['公安系统', '检察系统', '法院系统', '司法行政', '纪检监察']

/**
 * 五条线的特权配置。
 *
 *   passive      被动机制名（界面展示）
 *   passiveDesc  一句话说明被动 + 代价（双刃剑要放在一起说）
 *   active       主动技能名；没有主动技能的线此字段为 null
 *   activeDesc   主动技能说明
 *   activeCost   主动技能消耗的行动力
 *   activeYearly 主动技能每年限用一次
 *   activeEffects 主动技能效果（resources 增量，由引擎 applyEffects 结算）
 */
export const LEGAL_PERKS = {
  纪检监察: {
    passive: '廉政防火墙',
    passiveDesc: '小额风险不易触发廉政审查；但自身廉政红线翻倍严苛，风险超 40% 就可能被「灯下黑」从严查处。',
    active: '反腐利剑·线索初核',
    activeDesc: '消耗 1 行动力主动发起线索初核：威信与政绩大涨，但极易得罪人（人缘大跌）。',
    activeCost: 1,
    activeYearly: true,
    activeEffects: { authority: 18, kpi: 15, popularity: -12, risk: 4 },
    // 灯下黑红线：风险超过这个值，每季度额外追加风险
    lampLine: 40,
    lampExtra: 3,
    // 小额风险（非法所得低于这个数）审查通过率加成
    smallIllicit: 500000,
    auditBoost: 0.15
  },

  公安系统: {
    passive: '治安维稳专班',
    passiveDesc: '舆情处置成功率与降温效果翻倍；但长期值班备勤，每年健康与精力额外多耗。',
    active: null,
    activeDesc: '',
    activeCost: 0,
    activeYearly: false,
    activeEffects: {},
    burstFactor: 0.5,   // 舆情爆发概率减半
    coolFactor: 2,      // 主动降温效果翻倍
    yearlyHealth: -2,   // 值班备勤年度额外损耗
    yearlyEnergy: -3
  },

  检察系统: {
    passive: '法治刚性',
    passiveDesc: '专业壁垒高，外行领导不易插手；换届清洗波及减半，相对稳健。',
    active: null,
    activeDesc: '',
    activeCost: 0,
    activeYearly: false,
    activeEffects: {},
    edgeFactor: 0.5     // 派系边缘化年限加码减半
  },

  法院系统: {
    passive: '法治刚性',
    passiveDesc: '专业壁垒高，外行领导不易插手；换届清洗波及减半，相对稳健。',
    active: null,
    activeDesc: '',
    activeCost: 0,
    activeYearly: false,
    activeEffects: {},
    edgeFactor: 0.5
  },

  司法行政: {
    passive: '普法与调解缓冲',
    passiveDesc: '基层矛盾与信访化解效率高、人缘极好，适合养精蓄锐；降温舆情更省力、口碑更好。',
    active: null,
    activeDesc: '',
    activeCost: 0,
    activeYearly: false,
    activeEffects: {},
    decayBonus: 1,      // 舆情自然降温加强
    coolFactor: 1.5,    // 主动降温效果 1.5 倍
    coolPopularity: 4   // 主动降温额外涨人缘
  }
}

/** 取某单位流派的特权配置。不在政法五条线内返回 null */
export function perkOf(unitType) {
  return LEGAL_PERKS[unitType] || null
}

/** 该流派是否处于政法序列 */
export function isLegalTrack(unitType) {
  return LEGAL_TRACKS.indexOf(unitType) !== -1
}

/** 特权展示名（给人物卡/界面用）。非政法线返回空串 */
export function perkNameOf(unitType) {
  const perk = perkOf(unitType)
  return perk ? perk.passive : ''
}

/**
 * 廉政审查通过率的特权调整（纯函数，掷骰仍在 engine 侧）。
 * 纪检干部的「廉政防火墙」：小额风险不易触发审查。
 */
export function auditOddsAdjust(state, odds) {
  const perk = perkOf(state && state.player && state.player.unitType)
  if (!perk || !perk.auditBoost) return odds
  const ill = num(state.player.illicitWealth)
  if (ill < (perk.smallIllicit || 0)) {
    return Math.min(1, odds + perk.auditBoost)
  }
  return odds
}

/** 舆情爆发概率的特权系数（公安减半）。返回 1 表示无加成 */
export function sentimentBurstFactorOf(unitType) {
  const perk = perkOf(unitType)
  return perk && perk.burstFactor ? perk.burstFactor : 1
}

/** 主动降温效果的特权系数（公安翻倍、司法 1.5 倍）。返回 1 表示无加成 */
export function sentimentCoolFactorOf(unitType) {
  const perk = perkOf(unitType)
  return perk && perk.coolFactor ? perk.coolFactor : 1
}

/** 主动降温额外涨的人缘（司法行政专属） */
export function sentimentCoolPopularityOf(unitType) {
  const perk = perkOf(unitType)
  return perk && perk.coolPopularity ? perk.coolPopularity : 0
}

/** 舆情自然降温的额外点数（司法行政专属） */
export function sentimentDecayBonusOf(unitType) {
  const perk = perkOf(unitType)
  return perk && perk.decayBonus ? perk.decayBonus : 0
}

/** 派系边缘化年限加码的系数（法院/检察减半）。返回 1 表示无减免 */
export function factionEdgePenaltyFactorOf(unitType) {
  const perk = perkOf(unitType)
  return perk && perk.edgeFactor ? perk.edgeFactor : 1
}
