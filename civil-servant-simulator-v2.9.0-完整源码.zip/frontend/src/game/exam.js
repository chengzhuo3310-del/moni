/**
 * 考公成绩落到档案上的那一小步。
 *
 * 单独成文件而不是塞进 Exam.vue，是因为它改的是**游戏档案**，
 * 与界面无关：换一个界面（或将来做「重考」功能）也该走同一个函数。
 *
 * 单位类型是硬约束：分档只可能给出 UNIT_TYPES 里的四个值之一，
 * 但这里不替考务那边担保，仍旧挡一道，出现意料之外的值就整条不落库——
 * 一个脏 unitType 进了存档，往后每个读它的地方都得各自防一次。
 */

import { UNIT_TYPES, RESOURCE_LIMITS } from '@/constants/gameConfig'
import { SETTLE_BONUS } from '@/constants/money'
import { unitNameOf } from '@/constants/geo'
import { ensureFaction } from './personnel'
import { logHistory } from './archive'

/** 把数值夹进资源区间 */
function clampResource(key, value) {
  const range = RESOURCE_LIMITS[key]
  if (!range) return null
  const num = Number(value)
  if (!Number.isFinite(num)) return null
  return Math.min(range[1], Math.max(range[0], Math.round(num)))
}

/**
 * 把录用结果写进游戏状态（就地修改）。
 *
 * @param {Object} state  组件 $data（含 player / resources）
 * @param {Object} result evaluatePaper()（见 game/examPaper.js）出的成绩单
 * @returns {{ok: boolean, message: string, applied: Object}}
 */
export function applyExamResult(state, result) {
  if (!result || typeof result !== 'object') {
    return { ok: false, message: '成绩单为空，无法报到。', applied: {} }
  }

  const unitType = result.unitType
  if (!UNIT_TYPES.includes(unitType)) {
    return {
      ok: false,
      message: `成绩单上的单位类型「${unitType}」不在合法范围内，已拒绝写入档案。`,
      applied: {}
    }
  }

  // 职级不动：考公只决定去哪个单位、任什么职务，级别仍从科员起步
  state.player.unitType = unitType
  // 单位名按真实起始地点 + 流派拼装（见 constants/geo.js），
  // 不再用成绩单里那个"XX镇"占位名。
  state.player.unit = unitNameOf(state.player, unitType, state.player.level)
  state.player.position = result.position || state.player.position
  // 成绩单的 score **不取整**（理由见 examPaper.js 里 buildResult 那段：
  // 取整会把 59.5 抬进上一档），而档案里 player.examScore 是个**记录用的整数**
  // （后端 models.py 的 PlayerInfo.exam_score: int 也这么写着）。
  //
  // 这里取整只影响档案里存下来的这个数字。**去哪个单位是按原始分卡
  // 80/60/40 三条红线定的**，早在成绩单出来时就定好了，
  // 不经过这里，所以不会被这次取整改变。
  //
  // （每题 20 分之后分数只会是 10 的倍数，本来就取不到小数——
  //  这道取整留着是为了"分数带小数"这件事哪天回来时仍然是安全的。）
  state.player.examScore = Math.round(Number(result.score) || 0)

  const applied = {}
  const bonus = result.attributeBonus || {}
  Object.keys(bonus).forEach((key) => {
    if (!(key in state.resources)) return
    const safe = clampResource(key, Number(state.resources[key]) + Number(bonus[key]))
    if (safe === null) return
    applied[key] = safe - state.resources[key]
    state.resources[key] = safe
  })

  // 入职安家费。按去的单位发，核心部门给得最多——那些地方人情往来最密，
  // 一个刚报到的年轻人手里没钱，前期几乎没法处理任何需要打点的事。
  //
  // 用 += 而不是 =：重考或读档后重放这个函数时，不该把已经攒下的家产抹掉。
  // 查不到对应金额（理论上不可能，unitType 上面刚校验过）就发 0，不猜。
  const settle = Number(SETTLE_BONUS[unitType]) || 0
  state.player.money = (Number(state.player.money) || 0) + settle
  // 安家费也算**合法收入**。财产申报算的是"你说不清来路的钱"，
  // 少记这一笔，一个刚报到的年轻人第一次申报就会凭空多出几万块的差额——
  // 那是算错了账，不是反腐。
  state.player.legalIncome = (Number(state.player.legalIncome) || 0) + settle

  // 派系初始化（2.4.0）：按出身定一个默认派系，并配第一位直接上级。
  // 必须在考公分配时做——派系跟着人走，不跟着单位走。
  ensureFaction(state)

  // 履历第一笔：考公录用（2.4.0，模块 8）
  logHistory(state,
    `${state.player.age} 岁考公录用（${state.player.examScore} 分），`
    + `分配至${state.player.unit}，任${state.player.position}。`)

  return { ok: true, message: '', applied, settle }
}
