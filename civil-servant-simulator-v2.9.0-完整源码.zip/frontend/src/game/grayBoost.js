/**
 * 灰色博弈冲刺（2.9.0）——纯配置与纯函数层。
 *
 * ── 背景（Gemini 平衡诊断）─────────────────────────────────
 * 2.8.0 之前，risk 几乎是纯负向惩罚，清廉流没有效率惩罚、博弈流除了
 * 多拿钱买资产外，在推进政绩与打通向上管理上缺乏爆发力。结果是理性玩家
 * 玩两局后都无脑走「全清廉流」，放弃了政商博弈这半套系统。
 *
 * 2.8.0 先给清廉流加了「水至清则无鱼」的阻力（coord 选项多耗 1 AP）。
 * 本文件补上对称的另一半：**灰色操作蓄力、灰色冲刺放大政绩/向上管理**，
 * 让玩家在任期考核快到期、或急需抢年龄红线时，产生「明知有风险、
 * 却不得不铤而走险」的真实心理博弈。
 *
 * ── 设计约束（为什么这么设计）─────────────────────────────
 * 1. **不破坏免费净加不变量**：冲刺倍率只作用于「付费」的灰色选项
 *    （花钱/涨风险/耗行动力），validatePool 检查的是静态 effects，
 *    倍率是运行时叠加，且只放大政绩(kpi)与向上管理(mgmt)两项正向值，
 *    不放大人缘/威信，避免面值通胀。
 * 2. **清廉流零影响**：grayMomentum 只有灰色操作才累积，清廉流恒为 0，
 *    倍率恒为 1.0，随机序列与结算一个都不动（与 rollPromotionAudit
 *    那条「只对有案底的人掷骰」是同一套隔离逻辑）。
 * 3. **消耗式释放**：每次冲刺消耗动量，动量靠继续灰色操作补，无法无限刷。
 *
 * 本文件**不 import engine / patrons / wealth**，也不就地改 state。
 * 它只回答「动量多少、倍率多少、怎么折算」，改状态的动作留给调用方。
 * 依赖方向单向：engine / patrons → grayBoost。
 */

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

/** 灰色动能上限 */
export const GRAY_MOMENTUM_MAX = 100

/** 每季度自然衰减：时间冲淡灰色关系，长时间不伸手，动能就凉了 */
export const GRAY_MOMENTUM_DECAY = 3

/** 每次「灰色冲刺」消耗的动量 */
export const GRAY_BOOST_COST = 20

/** 冲刺倍率的上限增益（0.5 = 最高 1.5 倍速） */
export const GRAY_BOOST_MAX_BONUS = 0.5

/** 各灰色操作的动能收益 */
export const GRAY_GAINS = {
  bribe: 15,   // 收礼 / 收受干股（applyOption 的 gainIllicit 统一入口）
  borrow: 20,  // 利益输送（patronBorrow）
  glove: 10    // 白手套代持（patronWhiteGlove）
}

/**
 * 取当前灰色动能（0~100）。未初始化按 0。
 * @param {Object} state 含 player 的组件 $data / 引擎状态
 */
export function grayMomentumOf(state) {
  return Math.max(0, Math.min(GRAY_MOMENTUM_MAX, num(state && state.player && state.player.grayMomentum)))
}

/** 累积灰色动能（夹在 0~100），返回实际变化量 */
export function gainGrayMomentum(state, amount) {
  const before = grayMomentumOf(state)
  const after = Math.max(0, Math.min(GRAY_MOMENTUM_MAX, before + num(amount)))
  if (state && state.player) state.player.grayMomentum = after
  return after - before
}

/** 消耗灰色动能（夹在 0~100），返回实际变化量（负数） */
export function spendGrayMomentum(state, amount) {
  return gainGrayMomentum(state, -num(amount))
}

/** 季度自然衰减（advanceQuarter 调用），返回实际变化量 */
export function decayGrayMomentum(state) {
  const m = grayMomentumOf(state)
  if (m <= 0) return 0
  return gainGrayMomentum(state, -GRAY_MOMENTUM_DECAY)
}

/**
 * 当前冲刺倍率（1.0 ~ 1.5）。线性：动量 100 时封顶 1.5。
 * 清廉流（动量 0）恒为 1.0。
 */
export function grayBoostFactorOf(state) {
  const m = grayMomentumOf(state)
  return 1 + (m / GRAY_MOMENTUM_MAX) * GRAY_BOOST_MAX_BONUS
}

/**
 * 把一组 effects 按冲刺倍率放大——**只放大正向的政绩与向上管理**。
 * 返回新对象，不污染原 effects（与 promotion.js 的 discountedRequirement
 * 同一套理由：原 effects 是事件里的静态字典，就地改会把一次性加成焊死）。
 *
 * @param {Object} effects 静态 effects（{ kpi: 6, mgmt: 4, risk: 8, ... }）
 * @param {number} factor  冲刺倍率（1.0~1.5）
 */
export function grayBoostEffects(effects, factor) {
  const out = { ...(effects || {}) }
  const f = Number.isFinite(Number(factor)) && Number(factor) > 1 ? Number(factor) : 1
  ;['kpi', 'mgmt'].forEach((key) => {
    const v = num(out[key])
    if (v > 0) out[key] = Math.round(v * f)
  })
  return out
}
