/**
 * 晋升「拟任用去向」生成器（2.2.0 新增）。
 *
 * 解决两个问题：
 *   ① 晋升不再是"原地换头衔"。每个职级提任前，组织上会拿出几个差异化去向
 *      让干部本人选——留任深耕、下派地方、跃迁中枢，走哪条路自己定。
 *   ② 核心部门（机关序列）不再"升职级不换地方"。去向里**固定包含**一个
 *      "下派地方主政"的选项，把"机关镀金 → 地方历练 → 调回中枢"这条路补上。
 *
 * 每个去向都是一套**自洽的落点**：单位名、职务、行政层级、城市线级、
 * 省市区镇一起生成，落哪个就用哪个（单位名按真实地名拼，见 constants/geo.js；
 * 职务按区县类型改写，见 constants/county.js）。生成时**不改动 state**，
 * 只产出候选，由引擎在玩家选定后落地。
 */

import { tierOf, randomPositionFor, localizeMunicipality } from '@/constants/positions'
import { unitNameOf, CITIES, randomCityIn, pickDistrictFor, pickTownFor } from '@/constants/geo'
import { nextLevelOf } from '@/constants/promotion'
import { citySalaryFactor, cityExpenseFactor } from '@/constants/backgrounds'
import { salaryFloorOf } from '@/constants/money'

function pick(list) {
  return list[Math.floor(Math.random() * list.length)]
}

/** 城市线级 → 排名，越高越核心。用于"跃迁"挑一个不低于当前线级的城市 */
const TIER_RANK = { 一线: 4, 二线: 3, 三线: 2, 四线: 1 }

function rankOf(city) {
  return TIER_RANK[city && city.tier] || 2
}

/** 同省、且不是当前城市的一个随机城市；取不到就退回全国随机 */
function otherCityInProvince(province, excludeCity) {
  let pool = CITIES.filter((c) => c.province === province && c.name !== excludeCity)
  if (!pool.length) pool = CITIES.filter((c) => c.name !== excludeCity)
  if (!pool.length) pool = CITIES
  return pick(pool)
}

/** 挑一个比当前更核心的城市：先同省更高线级，再全国更高线级，再同级异城 */
function higherTierCity(current) {
  const rank = rankOf(current)
  const province = current && current.province
  let pool = CITIES.filter((c) => c.province === province && rankOf(c) > rank)
  if (!pool.length) pool = CITIES.filter((c) => rankOf(c) > rank)
  if (!pool.length) {
    pool = CITIES.filter((c) => rankOf(c) >= rank && c.name !== (current && current.name))
  }
  if (!pool.length) pool = CITIES
  return pick(pool)
}

/** 随机一线城市（黄金岗位专用：直入最核心的地方） */
function firstTierCity() {
  const pool = CITIES.filter((c) => c.tier === '一线')
  return pick(pool.length ? pool : CITIES)
}

/**
 * 由"单位流派 + 职级 + 一个虚拟地点"算出一套自洽的落点。
 * 不改动 state——地点是候选里存的一份快照。
 */
function buildPlacement(unitType, level, loc) {
  const fake = {
    province: loc.province,
    city: loc.city,
    district: loc.district,
    town: loc.town
  }
  const locationTier = tierOf(unitType, level)
  const unit = unitNameOf(fake, unitType, level)
  let position = randomPositionFor(unit, unitType, level, loc.district)
  // 直辖市省部级职务改写：北京/上海/天津/重庆没有"省"，正省部级是「市长」
  // 而非「省长」、党委是「市委书记」而非「省委书记」。
  position = localizeMunicipality(position, loc.province)
  return { unit, position, locationTier }
}

/**
 * 按行政层级裁剪地点：层级越高，越不该带着区县镇的尾巴。
 *
 * 「省长配一个区」这类错位就出在这里——目标职级是省部级，落点却还写
 * "石家庄市长安区"，等于把省长的办公地点说成某个区。
 * 返回 text（描述用）与裁剪后的 district / town（落地用）。
 */
function tierLocation(tier, loc) {
  if (tier === '国家') return { text: '中央', district: '', town: '' }
  if (tier === '省') return { text: loc.province, district: '', town: '' }
  if (tier === '市') return { text: `${loc.province}${loc.city}`, district: '', town: '' }
  if (tier === '县') return { text: `${loc.province}${loc.city}${loc.district}`, district: loc.district, town: '' }
  return { text: `${loc.province}${loc.city}${loc.district}${loc.town}`, district: loc.district, town: loc.town }
}

/**
 * 生成这一级提任的候选去向。
 *
 * @param {Object} state 组件 $data（含 player / gameStatus）
 * @param {Object} [ctx] 上下文。ctx.breakthrough = true 表示这是破格提拔，
 *        此时黄金岗位（直入中枢）**必出**——破格本就该配一个更重的位置。
 * @returns {Array} 3~4 个去向候选，每个含落点、单位、职务与履新即时加成
 */
export function buildPromotionOptions(state, ctx) {
  const to = nextLevelOf(state.player.level)
  if (!to) return []

  const p = state.player
  const flags = (state.gameStatus && state.gameStatus.flags) || {}
  const breakthrough = Boolean(ctx && ctx.breakthrough)
  const options = []

  // ── A. 留任深耕：现流派、现城市，地点不动 ──
  const stayLoc = { province: p.province, city: p.city, district: p.district, town: p.town }
  const stayPlacement = buildPlacement(p.unitType, to, stayLoc)
  const stayTl = tierLocation(stayPlacement.locationTier, stayLoc)
  options.push({
    id: 'stay',
    kind: 'stay',
    title: '留任深耕',
    tag: p.unitType,
    desc: `留在${stayTl.text}，在${p.unitType}系统内继续深耕。`
      + '人面熟、节奏稳，廉政风险波动小，但政绩出彩要靠自己慢慢熬。',
    unitType: p.unitType,
    province: stayLoc.province,
    city: stayLoc.city,
    district: stayTl.district,
    town: stayTl.town,
    cityTier: p.cityTier,
    bonus: { popularity: 2, risk: -2 },
    ...stayPlacement
  })

  // ── B. 下派地方：换同省新地点，主政一方 ──
  const localCity = otherCityInProvince(p.province, p.city)
  const localDistrict = pickDistrictFor(localCity.name)
  const localTown = pickTownFor(localCity.name)
  const localLoc = { province: localCity.province, city: localCity.name, district: localDistrict, town: localTown }
  const localPlacement = buildPlacement('基层乡镇', to, localLoc)
  const localTl = tierLocation(localPlacement.locationTier, localLoc)
  options.push({
    id: 'local',
    kind: 'local',
    title: '下派地方',
    tag: '基层乡镇',
    desc: `交流下派到${localTl.text}，主政一方。`
      + '政绩打得开局面，但异地重新打开人面，头几个季度要更拼。',
    unitType: '基层乡镇',
    province: localCity.province,
    city: localCity.name,
    district: localTl.district,
    town: localTl.town,
    cityTier: localCity.tier,
    bonus: { kpi: 12, popularity: -8, energy: -5 },
    ...localPlacement
  })

  // ── C. 跃迁中枢：去更高线级的城市、核心部门 ──
  const centralCity = higherTierCity({ name: p.city, province: p.province, tier: p.cityTier })
  const centralDistrict = pickDistrictFor(centralCity.name)
  const centralTown = pickTownFor(centralCity.name)
  const centralLoc = { province: centralCity.province, city: centralCity.name, district: centralDistrict, town: centralTown }
  const centralPlacement = buildPlacement('核心部门', to, centralLoc)
  const centralTl = tierLocation(centralPlacement.locationTier, centralLoc)
  const salaryNote = citySalaryFactor(centralCity.tier) > citySalaryFactor(p.cityTier)
    ? '薪资随城市线级跳涨，'
    : ''
  options.push({
    id: 'central',
    kind: 'central',
    title: '跃迁中枢',
    tag: '核心部门',
    desc: `调往${centralTl.text}的核心部门。${salaryNote}`
      + '接触的层级更高、机会更多，但组织上对向上管理和廉政风险的考核也盯得更紧。',
    unitType: '核心部门',
    province: centralCity.province,
    city: centralCity.name,
    district: centralTl.district,
    town: centralTl.town,
    cityTier: centralCity.tier,
    bonus: { mgmt: 6, authority: 6, risk: 3, popularity: -4 },
    ...centralPlacement
  })

  // ── D. 政法序列：转战公检法司纪 ──
  // 五条政法线各成一个独立流派（见 constants/positions.js），这里随机挑一条。
  // 权力分量重、成就感强，但廉政风险与舆论关注同步走高——执纪执法者更要自身硬。
  const LEGAL_TYPES = ['公安系统', '检察系统', '法院系统', '司法行政', '纪检监察']
  const legalType = pick(LEGAL_TYPES)
  const legalCity = otherCityInProvince(p.province, p.city)
  const legalDistrict = pickDistrictFor(legalCity.name)
  const legalTown = pickTownFor(legalCity.name)
  const legalLoc = { province: legalCity.province, city: legalCity.name, district: legalDistrict, town: legalTown }
  const legalPlacement = buildPlacement(legalType, to, legalLoc)
  const legalTl = tierLocation(legalPlacement.locationTier, legalLoc)
  options.push({
    id: 'legal',
    kind: 'legal',
    title: '政法序列',
    tag: legalType,
    desc: `转战${legalTl.text}的${legalType}。`
      + '执纪执法、监督审判，位高权重也责任如山，组织对你的廉政考察会更严。',
    unitType: legalType,
    province: legalCity.province,
    city: legalCity.name,
    district: legalTl.district,
    town: legalTl.town,
    cityTier: legalCity.tier,
    bonus: { authority: 10, risk: 6, mgmt: 4 },
    ...legalPlacement
  })

  // ── E. 黄金岗位（条件触发）：贵人提携，破格跨省 / 直入中枢 ──
  // 破格提拔时**必出**：破格上岸本就该配一个更重的位置，这是爽点所在。
  if (flags.mentor || flags.elite || flags.golden || breakthrough) {
    const goldenCity = firstTierCity()
    const gDistrict = pickDistrictFor(goldenCity.name)
    const gTown = pickTownFor(goldenCity.name)
    const goldenLoc = { province: goldenCity.province, city: goldenCity.name, district: gDistrict, town: gTown }
    const goldenPlacement = buildPlacement('核心部门', to, goldenLoc)
    const goldenTl = tierLocation(goldenPlacement.locationTier, goldenLoc)
    options.push({
      id: 'golden',
      kind: 'golden',
      title: breakthrough ? '破格直入中枢' : '破格提拔',
      tag: breakthrough ? '组织破格' : '贵人提携',
      desc: breakthrough
        ? `组织上破例一次：跳过剩余年限，直入${goldenTl.text}核心部门。这种机会一辈子碰不上几次。`
        : `有人在更高处替你递了话：破格跨省、直入${goldenTl.text}。这种机会一辈子碰不上几次。`,
      unitType: '核心部门',
      province: goldenCity.province,
      city: goldenCity.name,
      district: goldenTl.district,
      town: goldenTl.town,
      cityTier: goldenCity.tier,
      // 破格的人缘 -10 由引擎 finalizePromotion 统一扣，这里不再重复写——
      // 否则选黄金岗位会双重折损（bonus 一次 + 引擎一次）。
      bonus: breakthrough
        ? { mgmt: 8, authority: 6, risk: 4 }
        : { mgmt: 10, authority: 8, risk: 5 },
      ...goldenPlacement
    })
  }

  return options
}

/**
 * 把一个去向落地到玩家档案（就地修改 state）。
 * 职责：换地点、换单位流派、换职务与单位名、发履新即时加成、提薪。
 *
 * @returns {{
 *   from: string, to: string, position: string, unit: string,
 *   unitChanged: boolean, salary: number, relocation: boolean
 * }}
 */
export function applyPlacement(state, option) {
  const to = nextLevelOf(state.player.level)
  const from = state.player.level
  const oldUnit = state.player.unit
  const oldCity = state.player.city

  // 地点先换：单位名与职务都要按**新地点**拼，顺序不能反
  state.player.province = option.province
  state.player.city = option.city
  state.player.district = option.district
  state.player.town = option.town
  state.player.cityTier = option.cityTier

  // 单位流派与职级一起走
  state.player.unitType = option.unitType
  state.player.level = to
  state.player.position = option.position
  state.player.unit = option.unit
  state.player.locationTier = option.locationTier

  // 提任加薪（与旧 promote 同一套涨幅），再压上新职级的薪级地板。
  // 地板要按**新城市线级**算：去了一线城市，工资地板也要跟着线级抬。
  state.player.salary = Math.round(state.player.salary * 1.15 / 10) * 10
  const floor = Math.round(salaryFloorOf(to) * citySalaryFactor(state.player.cityTier))
  if (floor > state.player.salary) state.player.salary = floor

  return {
    from,
    to,
    position: state.player.position,
    unit: state.player.unit,
    unitChanged: state.player.unit !== oldUnit,
    relocation: state.player.city !== oldCity,
    salary: state.player.salary,
    cityTier: state.player.cityTier
  }
}

/**
 * 履新即时加成的说明文案（供弹窗展示「选了这条会怎样」）。
 * bonus 的数值含义与引擎 applyEffects 一致，这里只负责把它们说成人话。
 */
export function bonusTextOf(bonus) {
  const parts = []
  const map = {
    kpi: '政绩',
    popularity: '人缘',
    energy: '精力',
    mgmt: '向上管理',
    authority: '威信',
    risk: '廉政风险'
  }
  Object.keys(bonus || {}).forEach((key) => {
    const delta = Number(bonus[key]) || 0
    if (!delta) return
    const label = map[key] || key
    parts.push(`${label} ${delta > 0 ? '+' : ''}${delta}`)
  })
  return parts.join('、')
}
