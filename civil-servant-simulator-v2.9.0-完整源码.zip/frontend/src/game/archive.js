/**
 * 个人履历审批表 + 跨局生涯档案（2.4.0，模块 8）。
 *
 * ── 履历时间轴（player.historyLog）──────────────────────────
 * 一局内的结构性变化（考公录用、晋升调动、破格提拔、降级退赃、结局）
 * 都以一条带时间戳的文案记在 player.historyLog，主界面与结局海报可随时查看。
 *
 * ── 跨局生涯档案（localStorage.gwy_career_archive）──────────
 * 不随单局重开清空，永久记录：结局图鉴、历史最高职级、最清廉通关、
 * 成就徽章。每解锁一个结局，下局考公获得微弱初始属性加成，鼓励
 * 玩家体验"清廉务实流 / 激进政绩流 / 高危博弈流"等不同路线。
 */

import { LEVEL_LADDER } from '@/constants/promotion'
import { GAME_VERSION } from '@/constants/gameConfig'

const ARCHIVE_KEY = 'gwy_career_archive'

function store() {
  try {
    return typeof window !== 'undefined' ? window.localStorage : null
  } catch (err) {
    return null
  }
}

function emptyArchive() {
  return {
    version: GAME_VERSION,
    endings: {},          // 结局代号 → 解锁次数
    highestLevel: '科员', // 历史最高职级
    highestKpi: 0,        // 历史最高单局政绩
    cleanRetire: false,   // 是否零风险退休通关
    achievements: [],     // 成就徽章 id 数组
    heirs: [],            // 门生故旧：跨局继承的"自培"下属（2.7.0）
    // 跨局历史纪录榜（2.8.0）：多周目刷纪录的钩子
    records: {
      youngestSenior: null,   // 最年轻省部级 { age, level }
      highestLegalWealth: 0,  // 最高合法积累（累计合法收入）
      highestIllicit: 0       // 单局最高涉案金额
    }
  }
}

/** 读跨局档案。读不到或损坏返回空档案 */
export function loadArchive() {
  const s = store()
  if (!s) return emptyArchive()
  try {
    const raw = s.getItem(ARCHIVE_KEY)
    if (!raw) return emptyArchive()
    const parsed = JSON.parse(raw)
    return { ...emptyArchive(), ...(parsed || {}) }
  } catch (err) {
    return emptyArchive()
  }
}

/** 写跨局档案 */
export function saveArchive(archive) {
  const s = store()
  if (!s) return false
  try {
    s.setItem(ARCHIVE_KEY, JSON.stringify(archive))
    return true
  } catch (err) {
    return false
  }
}

/** 职级 → 阶梯下标。用于比"哪个职级更高" */
function levelIndex(level) {
  const idx = LEVEL_LADDER.findIndex((l) => l.level === level)
  return idx === -1 ? -1 : idx
}

/** 判断结局是否"正面通关"（不是落马/病倒/通缉） */
function isPositiveEnding(code) {
  return code === 'peak' || code === 'narrow' || code === 'landed'
}

/**
 * 结算时把本局成绩并入跨局档案（就地改 archive，返回是否新增了结局解锁）。
 * @param {Object} archive loadArchive() 的结果
 * @param {Object} state   组件 $data
 */
export function recordEnding(archive, state) {
  const p = state.player
  const gs = state.gameStatus || {}
  const code = gs.gameOverEnding
  const kpi = Number(state.resources && state.resources.kpi) || 0

  let newUnlock = false
  if (code) {
    if (!archive.endings[code]) {
      archive.endings[code] = 1
      newUnlock = true
    } else {
      archive.endings[code] += 1
    }
  }

  // 历史最高职级
  if (levelIndex(p.level) > levelIndex(archive.highestLevel)) {
    archive.highestLevel = p.level
  }
  // 历史最高政绩
  if (kpi > (Number(archive.highestKpi) || 0)) archive.highestKpi = kpi
  // 零风险退休（清廉通关）：正面结局且廉政风险为 0
  if (isPositiveEnding(code) && (Number(state.resources.risk) || 0) === 0) {
    archive.cleanRetire = true
  }

  // 成就徽章
  const badges = new Set(archive.achievements || [])
  const add = (id) => badges.add(id)

  // 六边形战士：六项正向资源全部 ≥90（精力/威信/向上管理/人缘/能力/政绩，不含风险健康）
  const r = state.resources || {}
  if (num(r.energy) >= 90 && num(r.authority) >= 90 && num(r.mgmt) >= 90
    && num(r.popularity) >= 90 && num(r.ability) >= 90 && num(r.kpi) >= 120) {
    add('hexagon')
  }
  // 破格奇才：本局破格提拔过
  if (Boolean(gs.lastBreakthrough)) add('breakthrough')
  // 两袖清风：零风险退休
  if (archive.cleanRetire) add('clean')
  // 不倒翁：退过赃（usedRetreat）且活到正面结局
  if (Boolean(gs.usedRetreat) && isPositiveEnding(code)) add('tumbler')

  archive.achievements = Array.from(badges)

  // ── 跨局趣味纪录榜（2.8.0）──────────────────────────────
  // 多周目刷纪录的钩子：最年轻省部级、单局最高合法积累、单局最高涉案金额。
  // 只记"更好"的那一次，坏成绩不覆盖好成绩。
  const records = archive.records || (archive.records = {
    youngestSenior: null,
    highestLegalWealth: 0,
    highestIllicit: 0
  })
  const age = num(p.age)
  // 最年轻省部级：到达副省部级及以上才算"进了省部"，且要拿到合法年龄
  if (levelIndex(p.level) >= levelIndex('副省部级') && age > 0) {
    const cur = records.youngestSenior
    if (!cur || age < num(cur.age)) {
      records.youngestSenior = { age, level: p.level }
    }
  }
  const legalWealth = num(p.legalIncome)
  if (legalWealth > num(records.highestLegalWealth)) records.highestLegalWealth = legalWealth
  const illicit = num(p.illicitWealth)
  if (illicit > num(records.highestIllicit)) records.highestIllicit = illicit

  // 门生故旧（2.7.0）：只把"善终"（光荣退休 / 平安落地 / 涉险过关）这一局里
  // 自己带出来、已经走到副处级以上的自培下属记进跨局档案。落马干部的旧部
  // 不记为"贵人"——人走茶凉，那份关系带不到下一局。
  if (isPositiveEnding(code)) {
    const heirs = collectHeirs(state)
    if (heirs.length) {
      const existing = Array.isArray(archive.heirs) ? archive.heirs : []
      const merged = existing.slice()
      heirs.forEach((h) => {
        const at = merged.findIndex((x) => x.name === h.name)
        if (at === -1) merged.push(h)
        else if (levelIndex(h.level) > levelIndex(merged[at].level)) merged[at] = h
      })
      merged.sort((a, b) => levelIndex(b.level) - levelIndex(a.level))
      archive.heirs = merged.slice(0, 5)
    }
  }

  return { newUnlock, archive }
}

/**
 * 收集本局够格记入"门生故旧"的自培下属。
 * 条件：自己培养（cultivated）且已到副处级及以上。
 */
function collectHeirs(state) {
  const subs = Array.isArray(state.player.subordinates) ? state.player.subordinates : []
  return subs
    .filter((s) => s && s.cultivated && levelIndex(s.level) >= levelIndex('副处级'))
    .map((s) => ({
      name: formalHeirName(s),
      level: s.level,
      position: s.position
    }))
}

/** 「小刘」→「刘」；无姓兜底「某」 */
function surnameOfHeir(name) {
  const stripped = String(name || '').replace(/^小/, '')
  const m = stripped.match(/^([\u4e00-\u9fa5])/)
  return m ? m[1] : '某'
}

/** 旧部走到副处级以上的正式称谓（跨局继承时直接当领导名用） */
const HEIR_HONORIFIC = {
  副处级: '副县长',
  正处级: '县长',
  副厅局级: '副市长',
  正厅局级: '市长',
  副省部级: '副省长',
  正省部级: '省长'
}

/** 把自培下属的名字升格为正式称谓：「小刘·正处级」→「刘县长」 */
function formalHeirName(sub) {
  const surname = surnameOfHeir(sub.name)
  const honorific = HEIR_HONORIFIC[sub.level] || sub.position || '同志'
  return `${surname}${honorific}`
}

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

/** 成就徽章目录：id → 名称与说明 */
export const ACHIEVEMENTS = [
  { id: 'hexagon', name: '六边形战士', desc: '六项正向能力全面拉满' },
  { id: 'breakthrough', name: '破格奇才', desc: '跳过年限，破格提拔上岸' },
  { id: 'clean', name: '两袖清风', desc: '零廉政风险光荣退休' },
  { id: 'tumbler', name: '不倒翁', desc: '退过赃、跌过跤，还是平安落地' }
]

/** 结局图鉴目录（与 engine.js 的 ENDINGS 对齐） */
export const ENDING_ALBUM = [
  { id: 'peak', label: '光荣退休', desc: '登顶且账目干净' },
  { id: 'narrow', label: '涉险过关', desc: '登顶，但账上有过说不清的钱' },
  { id: 'landed', label: '平安落地', desc: '到龄退休，全身而退' },
  { id: 'dismissed', label: '免职闲赋', desc: '没查出问题，但被免职' },
  { id: 'purged', label: '纪委监委留置', desc: '风险触顶，被立案留置' },
  { id: 'corrupted', label: '立案审查调查', desc: '账目说不清，被立案调查' },
  { id: 'collapse', label: '倒在工作岗位上', desc: '过劳病倒' },
  { id: 'rednotice', label: '红色通缉令', desc: '卷款出逃，被国际通缉' },
  { id: 'caught', label: '机场被拦', desc: '出逃失败，机场被截' }
]

/**
 * 下局考公的初始加成：每解锁一个结局，微弱加成一次。
 * 返回 { authority, ability, mgmt, popularity } 的偏移量，封顶 +6。
 */
export function archiveStartBonus() {
  const archive = loadArchive()
  const unlocked = Object.keys(archive.endings || {}).length
  if (!unlocked) return { authority: 0, ability: 0, mgmt: 0, popularity: 0 }
  const boost = Math.min(6, unlocked * 2)
  return { authority: boost, ability: boost, mgmt: 0, popularity: 0 }
}

/**
 * 门生故旧跨局继承（2.7.0）。
 *
 * 新局开局时以一定概率让上一局带出来的旧部以「贵人」身份出现，
 * 作为一位高好感度的直接上级。关系是念旧的，起点比组织新配的上级高；
 * 但这不是白送——它只改变"开局多一位可依靠的老领导"，不改任何资源数值。
 *
 * @param {Object} state 组件 $data。调用方须在首次初始化上级时调用，
 *                       已读档重开的存档不会重复触发（mentors 已有旧值）。
 * @returns {Object|null} 新加的上级对象；未继承返回 null。
 */
export function inheritLegacyMentor(state) {
  const archive = loadArchive()
  const heirs = Array.isArray(archive.heirs) ? archive.heirs : []
  if (!heirs.length) return null
  // 35% 概率再遇旧部——太高会稀释"组织新配上级"的正常流程，太低玩家撞不到
  if (Math.random() > 0.35) return null
  const heir = heirs[Math.floor(Math.random() * heirs.length)]
  if (levelIndex(heir.level) < levelIndex('副处级')) return null

  const mentor = {
    id: `mentor_legacy_${Date.now() % 100000}_${Math.floor(Math.random() * 1000)}`,
    name: heir.name,
    level: heir.position || heir.level, // 与 makeMentor 的 level=称谓 语义对齐
    faction: 'local',
    favor: 62 + Math.floor(Math.random() * 23), // 旧部念旧，起点高
    hiddenRisk: false,
    legacy: true,
    legacyNote: `上一局你带出来的旧部「${heir.name}」，如今已独当一面，对你另眼相看。`
  }
  const mentors = state.player.mentors || (state.player.mentors = [])
  mentors.push(mentor)
  return mentor
}

/** 往履历追加一条（就地修改 state），带当前季度时间戳 */
export function logHistory(state, text) {
  if (!Array.isArray(state.player.historyLog)) state.player.historyLog = []
  state.player.historyLog.push({
    quarter: state.player.quarter || '',
    text
  })
}
