/**
 * 派系、上级关系与下属培养（2.4.0）。
 *
 * 这是模块 3（派系与上下级人事）的逻辑层，与 engine.js 同一套风格：
 * 就地修改 state，返回 { ok, message, changes? }，界面负责播报与存档。
 *
 * ── 三块职责 ──────────────────────────────────────────────
 *   ① 派系：开局按出身定一个默认派系，空降新领导时可通过站队事件改换；
 *      派系靠山落马会触发"边缘化危机"（延长晋升年限，见 engine 联动）。
 *   ② 上级：维护 1~2 位直接上级（好感度 0~100 + 隐藏廉政度），
 *      专题汇报 / 节日走动 / 替领导解围 三种互动涨好感与向上管理，
 *      好感度高可在危机时保一把，捆绑过深则连带审查。
 *   ③ 下属：副科级起解锁，最多 4 名。带教压担子 / 推荐评优 培养，
 *      任人唯贤 / 任人唯亲 / 外放布子 三种任命走向。
 */

import { RESOURCE_LIMITS } from '@/constants/gameConfig'
import {
  makeMentor,
  makeSubordinate,
  factionLabelOf,
  levelUpSubordinate,
  syncSubordinateToPlayer,
  canLevelUpSubordinate,
  refreshMentor
} from '@/constants/factions'
import { applyEffects, moneyOf, spendMoney } from './engine'
import { inheritLegacyMentor } from './archive'

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

function clampResource(key, value) {
  const range = RESOURCE_LIMITS[key]
  if (!range) return null
  const n = Number(value)
  if (!Number.isFinite(n)) return null
  return Math.min(range[1], Math.max(range[0], Math.round(n)))
}

/** 出身 → 默认派系。选调/引进是空降，军转是元老，其余是本土 */
const FACTION_BY_BACKGROUND = {
  xuandiao: 'parachute',
  shengkao: 'local',
  shiyebian: 'local',
  rencai: 'parachute',
  junzhuan: 'veteran'
}

/**
 * 开局初始化派系与第一位上级（就地修改）。
 * 考公分配后调用一次。派系按出身推断，上级是组织安排的第一位直接领导。
 */
export function ensureFaction(state) {
  const p = state.player
  if (!p.faction || p.faction === '无派系') {
    const key = FACTION_BY_BACKGROUND[p.background] || 'local'
    p.faction = key
    p.factionLabel = factionLabelOf(key)
  }
  if (!Array.isArray(p.mentors) || !p.mentors.length) {
    p.mentors = [makeMentor(p.level, p.district, p.unitType)]
    // 门生故旧跨局继承（2.7.0）：新局有概率再遇上一局带出来的旧部。
    // 放在"首次配上级"的分支里——读档重开时 mentors 已有旧值，不会重复触发。
    inheritLegacyMentor(state)
  }
}

/**
 * 副科级起解锁下属：首次晋升到副科级时自动配 1 名核心下属。
 * 之后晋升每升一级再补 1 名，直到 4 名封顶（见 finalizePromotion 联动）。
 */
export function ensureSubordinates(state) {
  const p = state.player
  if (!Array.isArray(p.subordinates)) p.subordinates = []
  const band = p.level
  const canHave = band === '副科级' || band === '正科级'
    || /处级|厅局级|省部级|副国级/.test(band)
  if (!canHave) return
  // 副科级起至少 1 名；每高一档多 1 名，封顶 6
  const ladder = { 副科级: 1, 正科级: 2, 副处级: 2, 正处级: 3, 副厅局级: 3, 正厅局级: 4, 副省部级: 5, 正省部级: 5, 副国级: 6 }
  const target = ladder[band] || 1
  while (p.subordinates.length < Math.min(6, target)) {
    const exclude = p.subordinates.map((s) => s.position)
    p.subordinates.push(makeSubordinate(p.level, { district: p.district, exclude, unitType: p.unitType }))
  }
}

/**
 * 培养新下属（2.5.0）：副科级及以上、班子未满员时，花 1 点行动力
 * 主动纳入一名新下属。让玩家能自己"带队伍"，而不是只能被动等晋升补员。
 */
export function recruitSubordinate(state) {
  const p = state.player
  if (!Array.isArray(p.subordinates)) p.subordinates = []
  const band = p.level
  const canHave = band === '副科级' || band === '正科级'
    || /处级|厅局级|省部级|副国级/.test(band)
  if (!canHave) return { ok: false, message: '副科级及以上才能培养自己的班子。' }
  if (p.subordinates.length >= 6) return { ok: false, message: '班子已满员（6 名核心下属）。' }
  if (num(p.ap) < 1) return { ok: false, message: '行动力不足。' }

  p.ap -= 1
  // 自己培养的下属：起点比本人低两级（新人要一步步带出来），
  // 且带 cultivated 标记——晋升时不随职级自动"跳级匹配"，只等你自己任命提拔。
  const exclude = p.subordinates.map((s) => s.position)
  const sub = makeSubordinate(p.level, { cultivated: true, district: p.district, exclude, unitType: p.unitType })
  p.subordinates.push(sub)
  const changes = []
  applyEffects(state, { energy: -3 }, changes)
  return { ok: true, changes, message: `你把${sub.name}（${sub.level}·${sub.position}）纳入培养名单，班子多了一员。` }
}

/**
 * 任命提拔下属（2.5.0）：玩家主动给下属升一级，耗 1 点行动力。
 *
 * 逻辑上要名正言顺：下属的"阶段任务"完成了（taskDone）才能正常提拔；
 * 任务没完成就提，属于"冒风险提拔"——代价是廉政风险与口碑，赌他德配位。
 * 提拔后重置任务，新的位置有新的一摊事要干。
 */
export function appointSubordinate(state, subId) {
  const p = state.player
  const sub = (p.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  if (num(p.ap) < 1) return { ok: false, message: '行动力不足。' }
  if (sub.outpost) return { ok: false, message: `${sub.name}已经外放，不在你手边了。` }
  if (!canLevelUpSubordinate(p.level, sub)) {
    return { ok: false, message: `${sub.name}已经安排到你能力范围内最高的位置了（再提就跟你平级）。` }
  }

  const taskDone = Boolean(sub.taskDone)
  p.ap -= 1
  const oldLevel = sub.level
  const next = levelUpSubordinate(sub, p.district, p.unitType)
  sub.loyalty = Math.min(100, num(sub.loyalty) + 8)
  // 提拔后开新任务
  sub.taskProgress = 0
  sub.taskDone = false

  const changes = []
  if (taskDone) {
    applyEffects(state, { authority: 3, mgmt: 2 }, changes)
    return {
      ok: true,
      changes,
      message: `你提拔${sub.name}：${oldLevel} → ${next}，任「${sub.position}」。他任务干得漂亮，提得名正言顺。`
    }
  }
  // 冒风险提拔：任务没完成，赌一把
  applyEffects(state, { authority: 3, risk: 6, popularity: -2 }, changes)
  return {
    ok: true,
    changes,
    message: `你力排众议提拔${sub.name}：${oldLevel} → ${next}，任「${sub.position}」。他任务还没干完，这次提拔要担点风险。`
  }
}

/**
 * 玩家晋升后，把直接上级的称谓刷新到配得上新职级（保留关系数值）。
 */
export function refreshMentorTitles(state) {
  const mentors = Array.isArray(state.player.mentors) ? state.player.mentors : []
  mentors.forEach((m) => refreshMentor(m, state.player.level, state.player.district, state.player.unitType))
}

/**
 * 玩家晋升后的下属联动（2.5.0）：
 *   · 系统自动配的下属（非 cultivated）：同步到"比本人低一到两级"，随你水涨船高；
 *   · 自己培养的下属（cultivated）：只提拔一级（你进步了，也拉一把自己带的人）。
 * 返回要追加进播报的文案数组。
 */
export function refreshSubordinatesOnPromotion(state) {
  const p = state.player
  const subs = Array.isArray(p.subordinates) ? p.subordinates : []
  const messages = []
  subs.forEach((s) => {
    if (s.cultivated) {
      const before = s.level
      const next = levelUpSubordinate(s, p.district, p.unitType)
      if (next) {
        s.loyalty = Math.min(100, num(s.loyalty) + 6)
        // 提拔后开新任务
        s.taskProgress = 0
        s.taskDone = false
        messages.push(`你进步后没忘自己带的人，把${s.name}由${before}提拔为${next}。`)
      }
    } else {
      if (syncSubordinateToPlayer(s, p.level, p.district, p.unitType)) {
        // 同步（晋升）后同样开新任务
        s.taskProgress = 0
        s.taskDone = false
      }
    }
  })
  return messages
}

/** ── 上级互动 ────────────────────────────────────────────── */

/**
 * 专题汇报：耗 1 点行动力，涨该上级好感与向上管理。
 * 这是"积极靠拢"的正路——涨的是真本事与真交情。
 */
export function mentorReport(state, mentorId) {
  const mentor = (state.player.mentors || []).find((m) => m.id === mentorId)
  if (!mentor) return { ok: false, message: '这位领导不在了。' }
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }

  state.player.ap -= 1
  const changes = []
  applyEffects(state, { mgmt: 6, ability: 2 }, changes)
  mentor.favor = Math.min(100, num(mentor.favor) + 6)
  return { ok: true, changes, message: `向${mentor.name}做了一次专题汇报，彼此更熟络了。` }
}

/**
 * 节日走动：花一笔家产，涨好感与向上管理，微增廉政风险。
 * 人情世故的灰色地带——见效快，但有代价。
 * 金额随职级水涨船高：给科级领导走动是万把块，给省部级领导走动就不是这个数了。
 */
export function mentorGift(state, mentorId) {
  const mentor = (state.player.mentors || []).find((m) => m.id === mentorId)
  if (!mentor) return { ok: false, message: '这位领导不在了。' }
  const cost = mentorGiftCostOf(state.player.level)
  if (moneyOf(state) < cost) return { ok: false, message: `家底不够（需 ¥${cost.toLocaleString('zh-CN')}）。` }

  const changes = []
  spendMoney(state, cost, changes)
  applyEffects(state, { mgmt: 5, risk: 2 }, changes)
  mentor.favor = Math.min(100, num(mentor.favor) + 10)
  return { ok: true, changes, message: `逢年过节给${mentor.name}备了份礼，话里话外更近了。` }
}

/** 节日走动的花销随玩家职级浮动（越往上，门槛越高） */
export function mentorGiftCostOf(level) {
  const COST_BY_LEVEL = {
    科员: 10000,
    副科级: 15000,
    正科级: 20000,
    副处级: 40000,
    正处级: 60000,
    副厅局级: 100000,
    正厅局级: 150000,
    副省部级: 300000,
    正省部级: 500000,
    副国级: 1000000
  }
  return COST_BY_LEVEL[level] || 20000
}

/**
 * 替领导解围（背锅）：暴涨好感并拿推荐 flag，但风险与威信要付出代价。
 * 这是"表忠心"的高风险高回报——扛下一次，领导记你一辈子。
 */
export function mentorCover(state, mentorId) {
  const mentor = (state.player.mentors || []).find((m) => m.id === mentorId)
  if (!mentor) return { ok: false, message: '这位领导不在了。' }
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }

  state.player.ap -= 1
  const changes = []
  applyEffects(state, { mgmt: 10, authority: -4, risk: 4 }, changes)
  mentor.favor = Math.min(100, num(mentor.favor) + 20)
  const flags = state.gameStatus.flags || (state.gameStatus.flags = {})
  flags.mentor = true // 破格提拔的触发理由之一
  return { ok: true, changes, message: `你替${mentor.name}把事扛了下来。他心里有数，记了你一笔。` }
}

/** ── 下属培养与任命 ──────────────────────────────────────── */

/**
 * 带教压担子：耗 1 点行动力，提升下属能力。
 * 高能力下属每年自动分担精力消耗并产出政绩（见 engine 联动）。
 */
export function trainSubordinate(state, subId) {
  const sub = (state.player.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }

  state.player.ap -= 1
  sub.ability = Math.min(100, num(sub.ability) + 8)
  const changes = []
  applyEffects(state, { energy: -4 }, changes)
  return { ok: true, changes, message: `你给${sub.name}压了担子，他上手越来越快。` }
}

/**
 * 推荐评优：耗 1 点行动力，提升下属忠诚度。
 * 忠诚满值即成为"铁杆心腹"，是外放布子的前置。
 */
export function praiseSubordinate(state, subId) {
  const sub = (state.player.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }

  state.player.ap -= 1
  sub.loyalty = Math.min(100, num(sub.loyalty) + 10)
  const changes = []
  applyEffects(state, { popularity: 3 }, changes)
  return { ok: true, changes, message: `你给${sub.name}评了优，他更死心塌地了。` }
}

/**
 * 任人唯贤：提拔高能力下属，全单位政绩效率提升（+政绩）。
 * 代价：若下属野心高，其出事会引发"用人失察"（见 extraEvents 联动）。
 */
export function assignMerit(state, subId) {
  const sub = (state.player.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  const changes = []
  applyEffects(state, { kpi: 8, authority: 3 }, changes)
  sub.loyalty = Math.min(100, num(sub.loyalty) + 6)
  return { ok: true, changes, message: `你提拔了能力出众的${sub.name}，单位的活越干越顺。` }
}

/**
 * 任人唯亲：提拔心腹，掌控力强（+向上管理、+威信），但微增举报风险。
 */
export function assignLoyal(state, subId) {
  const sub = (state.player.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  const changes = []
  applyEffects(state, { mgmt: 6, authority: 4, risk: 2 }, changes)
  sub.loyalty = Math.min(100, num(sub.loyalty) + 8)
  return { ok: true, changes, message: `你把心腹${sub.name}提到关键位置，班子更听你的了。` }
}

/**
 * 外放布子：把忠诚度足够高的心腹推荐到其他部门/区县，
 * 使其成为"外部眼线"——在风声预警时提前通风报信（见 game/sentiment.js）。
 */
export function assignOutpost(state, subId) {
  const sub = (state.player.subordinates || []).find((s) => s.id === subId)
  if (!sub) return { ok: false, message: '这位下属不在你的班子里。' }
  if (num(sub.loyalty) < 70) {
    return { ok: false, message: `${sub.name}的忠诚度还不够（需 ≥70），外放有反水的风险。` }
  }
  sub.outpost = true
  const changes = []
  applyEffects(state, { mgmt: 4 }, changes)
  return { ok: true, changes, message: `你把${sub.name}外放到了别的部门，从此多了一双外面的眼睛。` }
}

/** 是否有外放心腹（风声预警的触发条件之一） */
export function hasOutpost(state) {
  return (state.player.subordinates || []).some((s) => s.outpost)
}

/**
 * 连带审查：上级落马时，按绑定深度判定你是否被"拔出萝卜带出泥"。
 * 好感度越高、上级越贪，你被牵连的概率越大。纯判定，不改状态。
 * @returns {{risk: boolean, reason: string}} risk 为 true 时需触发边缘化/立案
 */
export function checkMentorCollapse(state) {
  const mentors = state.player.mentors || []
  const risky = mentors.filter((m) => m.hiddenRisk && num(m.favor) >= 60)
  if (!risky.length) return { risk: false, reason: '' }
  return {
    risk: true,
    reason: `你的老领导${risky[0].name}被查了。你与他过往甚密，组织上会重点看一看你。`
  }
}

/**
 * 派系边缘化：所属派系靠山倒了，晋升年限延长（正科及以上）。
 * 返回要延长的季度数（一次性判定，供 engine 消费）。
 */
export function factionEdgePenalty(state) {
  const flags = state.gameStatus.flags || {}
  // 只有"站了队"且"靠山倒台"标记存在时才罚
  if (!flags.faction_fallen) return 0
  return state.player.faction === 'independent' ? 0 : 4 // 多坐一年
}

/**
 * 季末人事随机进展（2.5.0）。
 *
 * 上下级不是摆在面板里的静态卡片——他们有自己的日子要过：
 * 下属会成长、也会懈怠，野心大的会出事；上级会赏识你、也可能生出嫌隙。
 * 每季度按概率抽几条好/坏进展，追加进本季通报。
 *
 * 另有两件"确定性"的事，每季度都发生、不靠抽签：
 *   ① 下属的阶段任务自动推进（能力越高干得越快），攒满即"可名正言顺提拔"；
 *   ② 下属偶尔来"孝敬"你（送礼金/购物卡），收下涨钱、也涨廉政风险。
 *
 * @param {Object} state 组件 $data
 * @param {Array}  notes 本季通报数组（就地追加）
 * @returns {Array} notes（原样返回，方便链式调用）
 */
export function settlePersonnelProgress(state, notes) {
  const p = state.player
  const subs = Array.isArray(p.subordinates) ? p.subordinates : []
  const mentors = Array.isArray(p.mentors) ? p.mentors : []
  // 威信威慑（2.8.0）：威信不够，下属更容易不服管教、擅自违规
  const authority = num(state.resources && state.resources.authority)
  const ambitionGate = authority < 50 ? 35 : 50
  let count = 0

  // 每季度最多 2 条随机人事进展，别让通报被下属家长里短刷屏
  const bump = () => { count += 1 }

  // ── ① 下属阶段任务推进（确定性）：能力越高干得越快，攒满即完成任务 ──
  subs.forEach((s) => {
    if (s.taskDone) return
    const speed = 8 + Math.floor(num(s.ability) / 12)
    s.taskProgress = Math.min(100, num(s.taskProgress) + speed)
    if (s.taskProgress >= 100) {
      s.taskDone = true
      notes.push(`下属${s.name}（${s.level}）把阶段任务干完了，眼下名正言顺，可以提拔了。`)
    }
  })

  // ── ② 随机人事进展：成长 / 捅娄子 / 送礼 / 懈怠 ──
  subs.forEach((s) => {
    if (count >= 2) return
    if (Math.random() > 0.3) return
    const roll = Math.random()
    bump()
    if (roll < 0.35) {
      s.ability = Math.min(100, num(s.ability) + 2 + Math.floor(Math.random() * 4))
      s.loyalty = Math.min(100, num(s.loyalty) + 2 + Math.floor(Math.random() * 4))
      notes.push(`下属${s.name}（${s.level}）这季度上手很快，渐渐能独当一面了。`)
    } else if (roll < 0.5 && num(s.ambition) >= ambitionGate) {
      // 野心高的人更容易捅娄子：轻则离心，重则被举报、你担"用人失察"的名声。
      // 威信不足时门槛更低（2.8.0）——镇不住场子，底下人就更容易乱来。
      s.loyalty = Math.max(0, num(s.loyalty) - 5)
      applyEffects(state, { risk: 3, popularity: -2 }, [])
      notes.push(`下属${s.name}心思有点活泛，被人举报了作风问题，你也跟着沾了点是非。`)
    } else if (roll < 0.62) {
      // 下级"孝敬"：礼金/购物卡随职级水涨船高，收下即涨廉政风险
      const amount = giftFromSubordinateOf(p.level)
      state.player.money = num(state.player.money) + amount
      applyEffects(state, { risk: 4 }, [])
      notes.push(`下属${s.name}悄悄送来一份"心意"（约 ¥${amount.toLocaleString('zh-CN')}）。你收下了，廉政风险跟着上去。`)
    } else {
      s.loyalty = Math.max(0, num(s.loyalty) - 3)
      notes.push(`下属${s.name}这季度有些懈怠，交代的事办得拖沓。`)
    }
  })

  // ── ③ 上级随机进展 ──
  mentors.forEach((m) => {
    if (count >= 2) return
    if (Math.random() > 0.2) return
    const good = Math.random() < 0.6
    bump()
    if (good) {
      m.favor = Math.min(100, num(m.favor) + 3 + Math.floor(Math.random() * 4))
      notes.push(`最近和${m.name}走动多了，他对你的印象更好了。`)
    } else {
      m.favor = Math.max(0, num(m.favor) - 4)
      notes.push(`${m.name}这阵子对你有些看法，得找机会缓和一下。`)
    }
  })

  return notes
}

/** 下属"孝敬"的礼金金额随玩家职级浮动（0.5~1.5 倍随机） */
function giftFromSubordinateOf(level) {
  const base = {
    科员: 2000, 副科级: 3000, 正科级: 5000,
    副处级: 10000, 正处级: 20000, 副厅局级: 40000,
    正厅局级: 80000, 副省部级: 150000, 正省部级: 300000, 副国级: 500000
  }
  const b = base[level] || 5000
  return Math.round(b * (0.5 + Math.random()))
}
