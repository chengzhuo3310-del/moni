/**
 * 商城购买逻辑（2.2.0）。
 *
 * 两类商品走两条路，共同点是**都扣家产、都不允许欠债**：
 *   · 资产类（安居座驾）→ wealth.js 的 buyAsset：车房进 player.assets，
 *     直接进财产申报的分子——这是商城与风控联动的落点（钱换成了看得见的东西，
 *     说得清来路才买得安生）。
 *   · 消费品（健康进修 / 人情门路）→ 走 spendMoney 记累计支出，
 *     applyEffects 应用即时效果，并写冷却（防钱多无限刷属性）。
 */

import { shopItemOf } from '@/constants/shop'
import { assetSpecOf } from '@/constants/assets'
import { buyAsset, propertyRiskOf, DECLARE_TIER } from './wealth'
import { absQuarterOf, applyEffects, moneyOf, spendMoney } from './engine'

/**
 * 购买一件商城商品。
 *
 * @param {Object} state   组件 $data
 * @param {string} itemId  资产 id（car_compact 等）或消费品 id（checkup 等）
 * @param {string} [holder] 资产类商品的代持方式 self / proxy，消费品忽略
 * @returns {{ok: boolean, message: string, changes?: Array, asset?: Object}}
 */
export function purchaseShopItem(state, itemId, holder = 'self') {
  // ── 资产类：安居与座驾 ──
  const spec = assetSpecOf(itemId)
  if (spec) {
    const out = buyAsset(state, {
      kind: itemId,
      holder,
      cityTier: state.player.cityTier
    })
    if (!out.ok) return { ok: false, message: out.message }

    // 资产本身已进财产申报；这里再发一次"即时加成"（买车撑门面、买房落户口）。
    const changes = []
    applyEffects(state, spec.effects, changes)

    // 商城风控比对（2.4.0，模块 2）：买完这一件，可见财产相对合法收入
    // 是否已经"说不清"。到立案线就当场点醒，不等下一次财产申报。
    const risk = propertyRiskOf(state)
    let message = out.message
    if (risk.tier === DECLARE_TIER.SEVERE || risk.tier === DECLARE_TIER.CASE) {
      message += ' 注意：以你目前的合法收入，这笔家底已经说不清了，下次申报恐被立案审查。'
    } else if (risk.tier === DECLARE_TIER.TALK) {
      message += ' 提醒：这笔置办让家底超出了合法收入的合理范围，建议早做打算。'
    }
    return { ok: true, changes, message, asset: out.asset }
  }

  // ── 消费品：健康进修 / 人情门路 ──
  const item = shopItemOf(itemId)
  if (!item) return { ok: false, message: '商品不存在。' }

  // 冷却：加属性类消费不能连买，否则钱一多就无限刷满
  if (item.cooldown) {
    const cd = state.player.shopCooldowns || {}
    if (Number(cd[itemId]) > absQuarterOf(state)) {
      return { ok: false, message: `「${item.name}」还在冷却期，过段时间再来。` }
    }
  }

  // 每任期限购：体检/研修这类重消费，同一任期只能买一次，
  // 履新（tenureStartAbs 变化）后才重新解锁——防后期钱多无限刷满属性。
  if (item.perTenure) {
    const perTenure = state.player.shopPerTenure || {}
    const startAbs = Number(state.gameStatus.tenureStartAbs) || 1
    if (perTenure[itemId] === startAbs) {
      return { ok: false, message: `「${item.name}」本任期已消费过，履新后才能再来。` }
    }
  }

  // 灰色门路：没有灰色资金就不解锁
  if (item.needIllicit && !(Number(state.player.illicitWealth) > 0)) {
    return { ok: false, message: '你还没有那条门路。' }
  }

  // 行动力：进修这类"花时间"的消费要占 AP
  if (item.costAp && state.player.ap < item.costAp) {
    return { ok: false, message: `行动力不足（需 ${item.costAp} 点）。` }
  }

  // 验资：先验后扣，绝不出现负余额
  if (moneyOf(state) < item.price) {
    return { ok: false, message: `家底不够（需 ¥${item.price.toLocaleString('zh-CN')}）。` }
  }

  if (item.costAp) state.player.ap -= item.costAp

  const changes = []
  // 花钱记支出：不记的话，商城会变成一条把差额洗掉的通道（见 engine 的 spendMoney）
  spendMoney(state, item.price, changes)
  applyEffects(state, item.effects, changes)

  // 冷却写绝对季度号
  if (item.cooldown) {
    if (!state.player.shopCooldowns) state.player.shopCooldowns = {}
    state.player.shopCooldowns[itemId] = absQuarterOf(state) + item.cooldown
  }

  // 每任期限购：记下购买时的任职起算点
  if (item.perTenure) {
    if (!state.player.shopPerTenure) state.player.shopPerTenure = {}
    state.player.shopPerTenure[itemId] = Number(state.gameStatus.tenureStartAbs) || 1
  }

  // 分支标记（字画玉石流转这类，给后续事件留口子）
  if (item.setFlag) {
    const flags = state.gameStatus.flags || (state.gameStatus.flags = {})
    Object.keys(item.setFlag).forEach((key) => {
      flags[key] = item.setFlag[key]
    })
  }

  // 购物留痕（履历/图鉴可读，本期先记一笔）
  if (!Array.isArray(state.player.ownedItems)) state.player.ownedItems = []
  state.player.ownedItems.push({
    id: itemId,
    name: item.name,
    quarter: state.player.quarter || ''
  })

  return { ok: true, changes, message: `购得「${item.name}」。` }
}
