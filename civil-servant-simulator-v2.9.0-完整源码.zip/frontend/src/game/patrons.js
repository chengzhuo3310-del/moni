/**
 * 政商企业家关系卡与白手套机制（2.7.0）。
 *
 * ── 为什么要有这层 ──────────────────────────────────────────
 * 商城有了豪宅豪车，但钱的来源只有死工资和零星贪腐事件——大后期想买
 * 翠屏山别墅（900 万）几乎不可能，博弈也不够刺激。现实里，干部到了
 * 正科/副处这一级，手里开始有审批权、工程发包权或办案权，本地企业家
 * 会主动围上来——这就是「商人围猎」。
 *
 * 这一层把企业家做成**关系卡**，三条互动对应三种走法：
 *   · 亲清交往（招商引资）——合法、安全，涨政绩；
 *   · 利益输送（拆借/干股）——来钱快，涨风险；
 *   · 白手套代持——买超标豪宅豪车不落自己名下，绕过申报，但老板被抓就反噬。
 *
 * 白手套的「反噬」是这套机制的命门：它不能是纯优解。所以白手套资产
 * 平时**完全藏得住**（零暴露、零季度风险），可一旦老板因偷税/涉黑/行贿
 * 被抓（见 mock/extraEvents 里的老板被抓事件），这些资产会当场翻出来，
 * 直接触发「拔出萝卜带出泥」的立案审查。
 */

import { LEVEL_LADDER } from '@/constants/promotion'
import { assetSpecOf, assetCostInCity, illicitCapOf } from '@/constants/assets'
import { buyAsset, exposePatronAssets } from './wealth'
import { applyEffects, moneyOf } from './engine'
import { gainGrayMomentum, GRAY_GAINS } from './grayBoost'

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)]
}

/** 本地知名企业家池。name 是名号，type 是行当（用于文案与事件关联） */
const PATRON_POOL = [
  { name: '宏达地产 周总', type: '地产' },
  { name: '城建集团 陈总', type: '城建' },
  { name: '远大建设 赵总', type: '建设' },
  { name: '启元科技 钱总', type: '科技' },
  { name: '金桥实业 孙总', type: '实业' }
]

/** 白手套可代持的「超标」资产档（豪宅/豪车） */
export const WHITE_GLOVE_ASSETS = ['house_villa', 'car_super', 'house_river', 'car_audi']

/**
 * 白手套「关联暴露度」（0~100，2.8.0）。
 *
 * 2.7.0 的白手套是二元开关：没爆雷完全藏得住，一爆雷当场社会性死亡。
 * 2.8.0 把它改成渐进暴露——每次代持/利益输送都会在暗处留下一点「关联」，
 * 时间会冲淡它，但累积到一定程度，巡视、审计、老板资金链一旦出问题，
 * 会先给你预警、给你止损窗口，而不是直接秒杀。
 */
export const PATRON_EXPOSURE = {
  max: 100,
  decay: 2,        // 每季度自然衰减（时间冲淡关联）
  whiteGlove: 25,  // 每次代持 +25
  borrow: 10,      // 每次利益输送 +10
  warn: 60,        // 预警线：进入可能被延伸调查的阶段
  burst: 100       // 暴雷线：老板东窗事发时全部现形
}

/** 改变白手套关联暴露度，夹在 0~100，返回实际变化 */
export function addPatronExposure(state, delta) {
  const before = num(state.player.patronExposure)
  const after = Math.max(0, Math.min(PATRON_EXPOSURE.max, before + num(delta)))
  state.player.patronExposure = after
  return after - before
}

/** 当前暴露度，未初始化按 0 */
export function patronExposureOf(state) {
  return num(state.player.patronExposure)
}

/** 是否还有老板代持的资产 */
export function hasWhiteGlove(state) {
  return (state.player.assets || []).some((a) => a.patronBacked)
}

/** 职级是否已到「有审批权/发包权」这一级（正科级及以上） */
function hasPatronAccess(level) {
  const idx = LEVEL_LADDER.findIndex((l) => l.level === level)
  return idx >= LEVEL_LADDER.findIndex((l) => l.level === '正科级')
}

/**
 * 首次升到正科级及以上时，刷出 1~2 位本地企业家（就地修改）。
 * 只在玩家还一个企业家都不认识时触发一次。
 */
export function spawnPatronsIfEligible(state) {
  const p = state.player
  if (!hasPatronAccess(p.level)) return
  if (!Array.isArray(p.patrons)) p.patrons = []
  if (p.patrons.length) return

  const count = Math.random() < 0.5 ? 1 : 2
  const used = new Set()
  for (let i = 0; i < count; i += 1) {
    const free = PATRON_POOL.filter((x) => !used.has(x.name))
    const src = free.length ? free : PATRON_POOL
    const tpl = pick(src)
    used.add(tpl.name)
    p.patrons.push({
      id: `patron_${Date.now() % 100000}_${i}_${Math.floor(Math.random() * 1000)}`,
      name: tpl.name,
      type: tpl.type,
      favor: 20 + Math.floor(Math.random() * 30), // 初识好感 20~49
      poisoned: false                              // 是否已被卷入偷税/涉黑等案子（反噬标记）
    })
  }
}

/** 取某位企业家。找不到返回 null */
export function patronOf(state, patronId) {
  return (state.player.patrons || []).find((p) => p.id === patronId) || null
}

/**
 * 亲清交往：拉他来当地投资建厂，耗 1 行动力帮企业解决合法审批难题。
 * 完全合法、安全，直接大幅增加政绩（招商引资成绩），涨企业家好感。
 */
export function patronInvest(state, patronId) {
  const patron = patronOf(state, patronId)
  if (!patron) return { ok: false, message: '这位企业家不在你的人际网络里。' }
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }

  state.player.ap -= 1
  const changes = []
  applyEffects(state, { kpi: 12, popularity: 2 }, changes)
  patron.favor = Math.min(100, num(patron.favor) + 10)
  return {
    ok: true,
    changes,
    message: `你帮${patron.name}解决了几个审批难题，他决定在本地落一个项目。招商引资的成绩记在了你头上。`
  }
}

/**
 * 利益输送：找老板「拆借」或收受「干股/咨询费」。
 * 来钱快（按职级封顶），涨好感与廉政风险。这是贪腐流的灰色入口之一。
 */
export function patronBorrow(state, patronId) {
  const patron = patronOf(state, patronId)
  if (!patron) return { ok: false, message: '这位企业家不在你的人际网络里。' }

  const amount = illicitCapOf(state.player.level)
  const changes = []
  // 收下的钱同时进家产与纪委那本账（与事件 gainIllicit 同一套口径）
  state.player.money = num(state.player.money) + amount
  state.player.illicitWealth = num(state.player.illicitWealth) + amount
  state.player.hasIllicitRecord = true
  changes.push({
    key: 'illicitWealth',
    delta: amount,
    before: state.player.illicitWealth - amount,
    after: state.player.illicitWealth,
    actual: amount
  })
  applyEffects(state, { risk: 6, mgmt: 4 }, changes)
  patron.favor = Math.min(100, num(patron.favor) + 15)
  // 白手套关联暴露度：利益输送在暗处多留一分勾连（2.8.0）
  addPatronExposure(state, PATRON_EXPOSURE.borrow)
  // 灰色动能蓄力：利益输送是灰色冲刺最主要的本钱（2.9.0）
  gainGrayMomentum(state, GRAY_GAINS.borrow)
  return {
    ok: true,
    changes,
    message: `${patron.name}以「咨询费/拆借」的名义给你转了 ¥${amount.toLocaleString('zh-CN')}。`
      + '钱到了账，纪委那本账上也多了一笔，你与他的关联又紧了一分。'
  }
}

/**
 * 白手套代持：好感度刷满的老板帮你代持超标豪宅/豪车。
 * 资产仍走 buyAsset（holder=proxy），但额外打上 patronBacked 标记——
 * 平时零暴露、零季度风险，老板被抓时才整体翻出来（见 wealth.js 与老板被抓事件）。
 */
export function patronWhiteGlove(state, patronId, assetId) {
  const patron = patronOf(state, patronId)
  if (!patron) return { ok: false, message: '这位企业家不在你的人际网络里。' }
  if (num(patron.favor) < 80) {
    return { ok: false, message: `${patron.name}还没到能为你冒这个险的份上（好感需 ≥80）。` }
  }
  const spec = assetSpecOf(assetId)
  if (!spec || WHITE_GLOVE_ASSETS.indexOf(assetId) < 0) {
    return { ok: false, message: '这件资产不适合走白手套代持。' }
  }
  // 已有一件同档白手套资产就不再重复代持（买第二辆豪车不添体面，只添风险）
  const owned = (state.player.assets || []).some(
    (a) => a.patronBacked && (a.assetId === assetId || a.kind === spec.kind)
  )
  if (owned) return { ok: false, message: '白手套里已经有一件同类的资产了。' }

  const out = buyAsset(state, { kind: assetId, holder: 'proxy', cityTier: state.player.cityTier })
  if (!out.ok) return { ok: false, message: out.message }

  // 打上白手套标记：藏得更干净，反噬时也更狠
  out.asset.patronBacked = true
  out.asset.patronId = patronId
  out.asset.patronName = patron.name
  out.asset.exposedQuarterlyRisk = out.asset.quarterlyRisk // 反噬时恢复
  out.asset.quarterlyRisk = 0
  patron.favor = Math.min(100, num(patron.favor) + 5)
  // 代持是最深的勾连，暴露度显著抬升（2.8.0）
  addPatronExposure(state, PATRON_EXPOSURE.whiteGlove)
  // 灰色动能蓄力：代持同样是一份可用的灰色关系（2.9.0）
  gainGrayMomentum(state, GRAY_GAINS.glove)

  const changes = []
  applyEffects(state, spec.effects || {}, changes)
  changes.push({
    key: 'money',
    delta: -out.cost,
    before: moneyOf(state) + out.cost,
    after: moneyOf(state),
    actual: -out.cost
  })
  return {
    ok: true,
    changes,
    asset: out.asset,
    message: `${patron.name}帮你把「${spec.name}」落在了他的公司名下。`
      + '申报时查不到它，但这条线要是断了，会把你一起拽下去。'
  }
}

/**
 * 老板被抓的「致命反噬」（由老板被抓事件调用）。
 * 把该老板代持的所有资产翻出来计入申报，并触发立案审查。
 */
export function patronCaught(state, notes) {
  const p = state.player
  const exposed = exposePatronAssets(state)
  if (!exposed.length) {
    notes.push('你这位老板出了事，好在你没让他替你代持什么，暂时没烧到你身上。')
    return
  }
  // 翻出来的代持资产：直接按购入价计入非法所得，触发「拔出萝卜带出泥」
  const total = exposed.reduce((s, a) => s + num(a.price), 0)
  p.illicitWealth = num(p.illicitWealth) + total
  p.hasIllicitRecord = true
  state.gameStatus.investigationPending = true
  const firstName = exposed[0].patronName || '这位老板'
  notes.push(
    `${exposed[0].name}原来挂在${firstName}名下的资产被顺藤摸了出来，`
    + '你被「拔出萝卜带出泥」——立案审查调查已经启动。'
  )
}

/**
 * 白手套关联暴露度的季度结算（2.8.0，在 advanceQuarter 里调用）。
 *
 * 每季自然衰减一点；累积到暴雷线时，老板一旦东窗事发，代持资产当场现形；
 * 累积到预警线时置起 flag，让事件池把「审计延伸调查 / 老板资金链紧张」的
 * 预警事件提上议程——给玩家一个止损窗口，而不是直接秒杀。
 */
export function settlePatronExposure(state, notes) {
  if (patronExposureOf(state) <= 0) return

  // 时间冲淡关联
  addPatronExposure(state, -PATRON_EXPOSURE.decay)

  const now = patronExposureOf(state)
  // 暴雷线：代持资产还在，老板一出事就全翻出来
  if (now >= PATRON_EXPOSURE.burst && hasWhiteGlove(state)) {
    patronCaught(state, notes)
    return
  }

  // 预警线：进入可能被延伸调查的阶段
  if (now >= PATRON_EXPOSURE.warn) {
    const flags = state.gameStatus.flags || (state.gameStatus.flags = {})
    if (!flags.patronWarning) flags.patronWarning = true
  }
}

/**
 * 切割关系止损（2.8.0）。
 *
 * 把某位老板代持的资产转回自己名下（恢复季度风险暴露）、暴露度清零、
 * 移除这张关系卡。代价是资产从此查得到——"藏"的好处没了，但"暴雷"的
 * 达摩克利斯之剑也撤了。
 */
export function cutPatronTies(state, patronId) {
  const patron = patronOf(state, patronId)
  if (!patron) return { ok: false, message: '这位企业家不在你的人际网络里。' }

  const assets = (state.player.assets || []).filter(
    (a) => a.patronBacked && a.patronId === patronId
  )
  assets.forEach((a) => {
    a.patronBacked = false
    a.holder = 'self'
    a.quarterlyRisk = num(a.exposedQuarterlyRisk)
    delete a.patronId
    delete a.patronName
    delete a.exposedQuarterlyRisk
  })

  state.player.patronExposure = 0
  state.player.patrons = (state.player.patrons || []).filter((p) => p.id !== patronId)
  if (state.gameStatus.flags) state.gameStatus.flags.patronWarning = false

  return {
    ok: true,
    message: assets.length
      ? `你与${patron.name}彻底切割，${assets.length} 处代持资产转回了自己名下。`
        + '这条线断了，但那几处资产从此是要过财产申报的。'
      : `你与${patron.name}断了往来，不再沾他的边。`
  }
}

/**
 * 抛售套现止损（2.8.0）。
 *
 * 让老板把代持资产低价变现，钱回到你手里、暴露度大幅下降。代价是这笔
 * 变现是「灰色资产折现」，照样记进纪委那本账——钱回来了，账也脏了。
 */
export function dumpPatronAssets(state, patronId) {
  const patron = patronOf(state, patronId)
  if (!patron) return { ok: false, message: '这位企业家不在你的人际网络里。' }

  const target = (state.player.assets || []).filter(
    (a) => a.patronBacked && a.patronId === patronId
  )
  if (!target.length) return { ok: false, message: '没有可抛售的代持资产。' }

  const DUMP_RATE = 0.6
  const total = Math.round(target.reduce((s, a) => s + num(a.price), 0) * DUMP_RATE)
  state.player.assets = (state.player.assets || []).filter(
    (a) => !(a.patronBacked && a.patronId === patronId)
  )

  state.player.money = num(state.player.money) + total
  state.player.illicitWealth = num(state.player.illicitWealth) + total
  state.player.hasIllicitRecord = true
  addPatronExposure(state, -50)

  return {
    ok: true,
    message: `你让${patron.name}把代持资产低价出手，套回 ¥${total.toLocaleString('zh-CN')}。`
      + '钱回来了，账上也多了一笔说不清的进项；你与他的关联倒是松了大半。'
  }
}
