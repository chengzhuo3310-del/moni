/**
 * 专项督导攻坚副本（2.7.0）——纯配置与选择函数。
 *
 * 本文件只定义「副本有哪些剧本、多久来一次、目标多大」，不就地改 state。
 * 开启/推进/攻坚/成败结算的改状态动作都在 engine.js（advanceQuarter 与
 * campaignAttack），依赖方向 engine → campaign 单向，避免循环依赖。
 *
 * ── 为什么要有「副本」─────────────────────────────────────────
 * 一局 36 年，如果每年都是「点 1 个事件 + 点 3 下培养/走动」，中期就会
 * 节奏疲劳。每隔 4~5 年插入一次持续 2 年的专项大案，把长线切成有波峰波谷的
 * 战役段：打赢了拿「二等功/专项表彰」解锁破格提拔，打输了冻结当年晋升。
 */

/** 副本持续季度数：2 年 */
export const CAMPAIGN_DURATION_QUARTERS = 8

/** 副本目标进度：攒满即完美收官 */
export const CAMPAIGN_TARGET = 100

/** 副本间隔季度数：4 年（保证不会连轴转） */
export const CAMPAIGN_SPACING_QUARTERS = 16

/** 副本最早出现的绝对季度：第 3 年起（给开局留两年熟悉期） */
export const CAMPAIGN_FIRST_ABS = 9

/** 判定某单位流派属于党政线还是政法线副本 */
export function isLegalCampaignType(unitType) {
  return ['公安系统', '检察系统', '法院系统', '司法行政', '纪检监察'].indexOf(unitType) !== -1
}

/** 党政线剧本 */
const PARTY_CAMPAIGNS = [
  { title: '全国文明城市创建攻坚战', desc: '台账、点位、暗访，一场硬仗。' },
  { title: '百亿级重点项目征地拆迁', desc: '拆得动、稳得住，才是真本事。' },
  { title: '重大环保督察整改', desc: '问题清单摆在桌上，整改不到位就问责。' }
]

/** 政法线剧本 */
const LEGAL_CAMPAIGNS = [
  { title: '扫黑除恶专项斗争', desc: '打伞破网，深挖彻查。' },
  { title: '政法队伍教育整顿', desc: '刀刃向内，刮骨疗毒。' },
  { title: '跨省特大金融诈骗专案', desc: '受害者遍布多省，卷宗堆成山。' }
]

function pick(list) {
  return list[Math.floor(Math.random() * list.length)]
}

/**
 * 按单位流派挑一个副本剧本。返回带 id / title / type / desc 的纯对象。
 * 不改 state。
 */
export function pickCampaign(unitType) {
  const legal = isLegalCampaignType(unitType)
  const pool = legal ? LEGAL_CAMPAIGNS : PARTY_CAMPAIGNS
  const spec = pick(pool)
  const id = `campaign_${Date.now() % 100000}_${Math.floor(Math.random() * 1000)}`
  return {
    id,
    title: spec.title,
    desc: spec.desc,
    type: legal ? 'legal' : 'party'
  }
}

/**
 * 是否该开一场新副本（纯判定）。
 * 条件：本季是年初（Q1）、还没有进行中的副本、距离上一场 ≥ 4 年、且过了开局熟悉期。
 */
export function shouldStartCampaign(state, absQuarter) {
  if (state.gameStatus.campaign) return false
  if (absQuarter < CAMPAIGN_FIRST_ABS) return false
  const last = Number(state.gameStatus.lastCampaignAbs) || 0
  return absQuarter - last >= CAMPAIGN_SPACING_QUARTERS
}
