/**
 * 55 岁退居二线（2.4.0，模块 6）。
 *
 * 正处或副厅、晋升无望、年满 55 岁时，组织上会来谈一次话：
 *   接受退二线 → 转任调研员/人大政协，安稳过渡到 60 岁体面退休；
 *   拒绝退二线 → 保留晋升机会，但此后精力与健康损耗更高（见 engine 的 aging）。
 *
 * 与危机公关、立案审查一样，这条不是从事件池抽的——它是"年龄到了"这一
 * 生命周期节点的强制谈话，抽卡抽不出来的东西不能决定这条路的走向。
 */

/** 是否到了该谈退二线的时机（一次谈话，接受或拒绝后都不再弹） */
export function needsSecondLine(state) {
  const p = state.player
  const gs = state.gameStatus || {}
  if ((Number(p.age) || 0) < 55) return false
  if (p.retiredToSecondLine || gs.secondLineRefused) return false
  // 只对"正处 / 副厅"这一档触发——更低的没资格谈退二线，更高的不在这一档
  return p.level === '正处级' || p.level === '副厅局级'
}

/** 构造退居二线谈话事件 */
export function buildSecondLineEvent(state) {
  const p = state.player
  return {
    id: 'evt_second_line',
    title: '退居二线的谈话',
    npcName: '组织部',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description:
      `${p.age} 岁了。组织上找你谈话：按惯例，你这个位置到龄可以转任调研员，`
      + '退居二线，安安稳稳干到退休；也可以再留任一届，继续冲刺，但身体要自己扛。',
    options: [
      {
        id: 'opt_a',
        text: '接受安排，退居二线',
        costAp: 0,
        secondLine: true,
        effects: { risk: -5 },
        note: '安稳过渡到 60 岁退休，精力与健康损耗大幅降低。'
      },
      {
        id: 'opt_b',
        text: '婉拒，还想再干一届',
        costAp: 0,
        refuseSecondLine: true,
        effects: { authority: 4 },
        note: '保留晋升机会，但此后每年精力与健康损耗更高。'
      },
      {
        id: 'opt_c',
        text: '说听组织安排',
        costAp: 0,
        secondLine: true,
        effects: { mgmt: 4 }
      }
    ]
  }
}
