/**
 * 舆情热度与内部风声情报（2.4.0，模块 5）。
 *
 * ── 舆情热度（player.sentiment，0~100）──────────────────────
 * 强硬拆迁、敷衍信访、安全事故处理不当会推高舆情；超 75 且未及时降温，
 * 有概率触发"全网热搜 / 上级联合调查组进驻"，重创威信与向上管理。
 * 玩家可花 AP 与资金通过"基层走访化解 / 主动信息公开"降热度。
 *
 * ── 内部风声条（gameStatus.insiderTip）──────────────────────
 * 拥有"外放的心腹下属"或较高的人缘/向上管理时，在财产申报、换届调整
 * 前会弹出一条内部风声，给玩家留出退赃/平账/捐赠/调岗的避险窗口。
 */

import { applyEffects, absQuarterOf, spendMoney } from './engine'
import { hasOutpost } from './personnel'
import {
  sentimentBurstFactorOf,
  sentimentCoolFactorOf,
  sentimentCoolPopularityOf,
  sentimentDecayBonusOf
} from './legalPerk'

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : 0
}

/** 舆情热度相关阈值 */
export const SENTIMENT = {
  decay: 3,        // 每季度自然降温
  alert: 75,       // 超过该值有概率触发联合调查组
  burstOdds: 0.3,  // 超过 alert 后每季度触发调查组的概率
  max: 100,
  min: 0
}

/** 改变舆情热度，夹在 0~100，返回实际变化 */
export function addSentiment(state, delta) {
  const before = num(state.player.sentiment)
  const after = Math.max(SENTIMENT.min, Math.min(SENTIMENT.max, before + num(delta)))
  state.player.sentiment = after
  return after - before
}

/**
 * 人缘护盾（2.8.0）：厅级及以上、人缘 ≥80 时，舆情/匿名举报类负面效果
 * 抵消 30%。系数 0.7 表示"只承受七成"。低于厅级或人缘不够时系数为 1。
 *
 * 为什么卡"厅级以上"：前期人缘 ≥80 太容易，若全期生效，人缘会变成
 * 无脑拉满的万能盾，反而把它从"保命神技"退化成"必点数值"。卡在厅级，
 * 是让这条护盾只在舆情与举报真正密集的大后期起效——那时它也确实是
 * 唯一还在硬扛的资源。
 */
export function sentimentShieldFactor(state) {
  const level = state.player.level
  const senior = /厅局级|省部级|副国级/.test(level)
  const popular = num(state.resources && state.resources.popularity) >= 80
  return (senior && popular) ? 0.7 : 1
}

/**
 * 季度结算舆情（在 advanceQuarter 里调用）。
 * 自然降温；超阈值掷骰，触发则重创威信与向上管理并清零一次热度。
 */
export function settleSentiment(state, notes) {
  const before = num(state.player.sentiment)
  if (before <= 0) return

  // 自然降温（司法行政「普法调解」降温更快）
  addSentiment(state, -(SENTIMENT.decay + sentimentDecayBonusOf(state.player.unitType)))

  // 超阈值判定（公安「治安维稳」处置更强，爆发概率减半）
  if (before >= SENTIMENT.alert
    && Math.random() < SENTIMENT.burstOdds * sentimentBurstFactorOf(state.player.unitType)) {
    const changes = []
    // 人缘护盾（2.8.0）：厅级以上且人缘≥80，负面效果抵消 30%——
    // 群众和老同事都替你说话，热搜的杀伤力小一截。
    const shield = sentimentShieldFactor(state)
    applyEffects(state, {
      authority: -Math.round(15 * shield),
      mgmt: -Math.round(10 * shield),
      risk: Math.round(5 * shield)
    }, changes)
    addSentiment(state, -30) // 爆发后热度泄掉一部分
    notes.push(
      '你的负面舆情冲上了热搜，上级派了联合调查组进驻。'
      + '威信大损，向上管理受挫，事情还在发酵。'
    )
  }
}

/**
 * 主动降温：花 1 点行动力与一笔家产，走访化解 + 信息公开。
 * 这是"舆情起来了还能救"的主动出口，与"走动关系"同属固定动作。
 */
export function coolSentiment(state) {
  if (num(state.player.ap) < 1) return { ok: false, message: '行动力不足。' }
  const cost = 30000
  if (num(state.player.money) < cost) {
    return { ok: false, message: `家底不够（需 ¥${cost.toLocaleString('zh-CN')}）。` }
  }
  state.player.ap -= 1
  const changes = []
  // 花钱记支出，防止舆情降温变成洗钱通道（与走动关系同理）
  spendMoney(state, cost, changes)
  // 政法特权（公安/司法）主动降温更给力
  addSentiment(state, -Math.round(12 * sentimentCoolFactorOf(state.player.unitType)))
  applyEffects(state, { popularity: 4 + sentimentCoolPopularityOf(state.player.unitType) }, changes)
  return { ok: true, changes, message: '你下基层走访、主动公开信息，舆论慢慢缓下来了。' }
}

/**
 * 生成内部风声条（在 advanceQuarter 里、财产申报前调用）。
 * 有情报源（外放心腹 或 人缘≥60 或 向上管理≥60）且正处于申报前一季时，
 * 给出一条避险提示。存进 gameStatus.insiderTip，界面顶部渲染。
 */
export function maybeInsiderTip(state, absQuarter) {
  const p = state.player
  const rs = state.resources || {}
  const hasSource = hasOutpost(state)
    || num(rs.popularity) >= 60
    || num(rs.mgmt) >= 60
  if (!hasSource) return null

  // 财产申报每 5 季一次，前一季（absQuarter % 5 === 4）给出预警
  if (absQuarter % 5 !== 4) return null

  const tip = {
    text: '内部风声：下一季度要搞个人有关事项报告了。'
      + '你从熟人那儿听到，这次会比往年查得细。',
    expiresAt: absQuarter + 2 // 两条季度内有效
  }
  state.gameStatus.insiderTip = tip
  return tip
}

/** 取当前风声条，过期则清空并返回 null */
export function currentInsiderTip(state) {
  const tip = state.gameStatus && state.gameStatus.insiderTip
  if (!tip) return null
  if (num(tip.expiresAt) < absQuarterOf(state)) {
    state.gameStatus.insiderTip = null
    return null
  }
  return tip
}
