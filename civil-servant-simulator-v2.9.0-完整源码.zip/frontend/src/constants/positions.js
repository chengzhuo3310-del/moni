/**
 * 职级 × 单位流派 → 实权职务（2.0.0 起扩为 10 级 + 平行岗位随机分配）。
 *
 * ── 与旧版的两处不同 ────────────────────────────────────────
 * ① 职务不再是"一张表一个解"，而是**每个职级多个平行实权岗位**：
 *    晋升时随机分配一个（见 randomPositionFor）。同一个县长位置，
 *    有人接的是县长、有人接的是县委书记——仕途才谈得上"各有各的走法"。
 * ② 行政层级（省市县镇 + 国家）随职级上行。**单位名不在这里拼**——
 *    单位要用真实省市地名（见 constants/geo.js 的 unitNameOf），
 *    这里只管"这一级该在哪个行政层级、当什么职务"。
 *
 * ── 表怎么读 ──────────────────────────────────────────────
 * POSITION_POOLS[流派][职级] = 该级可随机分配的职务数组。
 * 层级由 tierOf() 决定：四个流派里，业务局委与清水衙门到了厅局级
 * 升到"省"（省财政厅、省档案馆），属地线与党委线则留在"市"。
 */

import { LEVEL_LADDER } from './promotion'
import { UNIT_TYPES } from './gameConfig'
import { localizeCounty, countyKindOf } from './county'

/**
 * 直辖市职务改写：北京/上海/天津/重庆没有"省"，其正省部级是「市长」
 * 而非「省长」，党委是「市委书记」而非「省委书记」。
 * 只在省部级职务上调用（含"省委书记/省长/副省长/省委常委/省政协主席"等字样）。
 */
const MUNICIPALITY_REWRITE = {
  省长: '市长',
  省委书记: '市委书记',
  省委常委: '市委常委',
  副省长: '副市长',
  省政协主席: '市政协主席',
  省政协副主席: '市政协副主席',
  省委秘书长: '市委秘书长'
}

export function localizeMunicipality(position, province) {
  const s = String(position || '')
  if (!s || !isMunicipalityProvince(province)) return s
  let out = s
  Object.keys(MUNICIPALITY_REWRITE).forEach((from) => {
    out = out.split(from).join(MUNICIPALITY_REWRITE[from])
  })
  return out
}

/** 是不是直辖市省名（北京市/上海市/天津市/重庆市） */
export function isMunicipalityProvince(province) {
  return ['北京市', '上海市', '天津市', '重庆市'].includes(String(province || ''))
}

/** 职级 → 默认行政层级（业务局委/清水衙门到厅局级再改到"省"） */
const TIER_OF_LEVEL = {
  科员: '乡镇',
  副科级: '乡镇',
  正科级: '乡镇',
  副处级: '县',
  正处级: '县',
  副厅局级: '市',
  正厅局级: '市',
  副省部级: '省',
  正省部级: '省',
  副国级: '国家'
}

/**
 * 政法序列里"最低设在县一级"的流派：检察院、法院、司法局、纪委监委
 * 在乡镇没有本级机构（公安有派出所，所以不在此列）。
 * 这些流派科员~正科级也要落在"县"，不能像党政机关那样落在乡镇。
 */
const LEGAL_UNITS_AT_COUNTY = ['检察系统', '法院系统', '司法行政', '纪检监察']

/** 每个职级可随机分配的平行实权岗位。值必须是数组，且至少一个 */
const POSITION_POOLS = {
  基层乡镇: {
    科员: ['科员', '办事员'],
    副科级: ['副镇长', '镇党委委员', '街道办副主任'],
    正科级: ['镇长', '镇党委书记', '街道办主任'],
    副处级: ['副县长', '县委副书记', '县委常委'],
    正处级: ['县长', '县委书记', '县委副书记'],
    副厅局级: ['副市长', '市委常委', '副州长'],
    正厅局级: ['市长', '市委书记', '州长'],
    副省部级: ['副省长', '省委常委', '副省长兼市委书记'],
    正省部级: ['省长', '省委书记'],
    副国级: ['国务委员', '全国政协副主席', '全国人大常委会副委员长']
  },

  核心部门: {
    科员: ['科员', '组织干事'],
    副科级: ['党政办副主任', '组织办副主任', '宣传办副主任'],
    正科级: ['党政办主任', '组织办主任', '宣传办主任'],
    副处级: ['县委办副主任', '县委组织部副部长', '县纪委副书记'],
    正处级: ['县委办主任', '县委组织部常务副部长', '县纪委常务副书记'],
    副厅局级: ['市委副秘书长', '市委组织部副部长', '市纪委副书记'],
    正厅局级: ['市委秘书长', '市委组织部常务副部长', '市纪委常务副书记'],
    副省部级: ['省委常委', '副省长', '省委秘书长'],
    正省部级: ['省委书记', '省长'],
    副国级: ['中央政治局委员', '国务委员', '全国政协副主席']
  },

  常规局委: {
    科员: ['科员', '办事员'],
    副科级: ['财政所副所长', '国土所副所长', '市场监管所副所长'],
    正科级: ['财政所所长', '国土所所长', '市场监管所所长'],
    副处级: ['县财政局副局长', '县发改局副局长', '县住建局副局长'],
    正处级: ['县财政局局长', '县发改局局长', '县住建局局长'],
    副厅局级: ['省财政厅副厅长', '省发改委副主任', '省住建厅副厅长'],
    正厅局级: ['省财政厅厅长', '省发改委主任', '省住建厅厅长'],
    副省部级: ['副省长', '省委常委', '省政协副主席'],
    正省部级: ['省长', '省委书记'],
    副国级: ['国务委员', '全国人大常委会副委员长', '全国政协副主席']
  },

  边缘部门: {
    科员: ['科员', '档案管理员'],
    副科级: ['文化站副站长', '档案室副主任', '方志办副主任'],
    正科级: ['文化站站长', '档案室主任', '方志办主任'],
    副处级: ['县档案馆副馆长', '县方志办副主任', '县政协办公室副主任'],
    正处级: ['县档案馆馆长', '县方志办主任', '县政协办公室主任'],
    副厅局级: ['省档案馆副馆长', '省政府研究室副主任', '省文史馆副馆长'],
    正厅局级: ['省档案馆馆长', '省政府研究室主任', '省文史馆馆长'],
    副省部级: ['省政协副主席', '副省长', '省委常委'],
    正省部级: ['省政协主席', '省长'],
    副国级: ['全国政协副主席', '全国人大常委会副委员长']
  },

  // ── 政法序列（2.6.0 新增）──────────────────────────────
  // 公安/检察/法院/司法/纪检五条线各自独立成"流派"，岗位平行随机分配。
  // 检察/法院/司法/纪检最低设在县一级（tierOf 已让科级即到"县"），
  // 公安科级仍在乡镇（派出所）。
  // 职位池只写县域默认表述（副县长/县检察院），「县→区」由 localizeCounty 改写；
  // 公安的「公安局→公安分局」由 localizePosition 里的专项规则改写。
  公安系统: {
    科员: ['民警', '派出所科员', '一级警员'],
    副科级: ['派出所副所长', '刑侦中队中队长', '治安中队中队长'],
    正科级: ['派出所所长', '刑侦大队大队长', '治安大队大队长'],
    副处级: ['县公安局副局长', '市局支队副支队长'],
    正处级: ['县公安局局长', '市局支队支队长'],
    副厅局级: ['市公安局副局长', '市局党委委员', '市局政治部主任'],
    正厅局级: ['市公安局局长', '市局党委副书记', '省厅总队总队长'],
    副省部级: ['省公安厅厅长', '省公安厅党委副书记'],
    正省部级: ['公安部常务副部长', '公安部党委副书记'],
    副国级: ['国务委员兼公安部部长', '中央政法委书记']
  },

  检察系统: {
    科员: ['检察官助理', '书记员', '一级检察官助理'],
    副科级: ['助理检察员', '县检察院检察员'],
    正科级: ['检察员', '县检察院科长'],
    副处级: ['县检察院副检察长', '市检察院检察委员会委员'],
    正处级: ['县检察院检察长', '市检察院部门主任'],
    副厅局级: ['市检察院副检察长', '市检察院检察委员会专职委员'],
    正厅局级: ['市检察院检察长', '省检察院副检察长'],
    副省部级: ['省检察院检察长', '省检察院党组副书记'],
    正省部级: ['最高人民检察院常务副检察长', '最高人民检察院党组副书记'],
    副国级: ['最高人民检察院检察长', '中央政法委书记']
  },

  法院系统: {
    科员: ['法官助理', '书记员', '一级法官助理'],
    副科级: ['助理审判员', '县法院副庭长'],
    正科级: ['审判员', '县法院庭长'],
    副处级: ['县法院副院长', '市中级人民法院审判委员会委员'],
    正处级: ['县法院院长', '市中级人民法院庭长'],
    副厅局级: ['市中级人民法院副院长', '市中级人民法院审判委员会专职委员'],
    正厅局级: ['市中级人民法院院长', '省高级人民法院副院长'],
    副省部级: ['省高级人民法院院长', '省高级人民法院党组副书记'],
    正省部级: ['最高人民法院常务副院长', '最高人民法院党组副书记'],
    副国级: ['最高人民法院院长', '中央政法委书记']
  },

  司法行政: {
    科员: ['司法局科员', '司法所助理员', '社区矫正科员'],
    副科级: ['司法所副所长', '法律援助中心副主任', '公证处副主任'],
    正科级: ['司法所所长', '法律援助中心主任', '公证处主任'],
    副处级: ['县司法局副局长', '监狱副监狱长'],
    正处级: ['县司法局局长', '监狱长'],
    副厅局级: ['市司法局副局长', '监狱管理局副局长', '戒毒管理局副局长'],
    正厅局级: ['市司法局局长', '监狱管理局局长', '省司法厅副厅长'],
    副省部级: ['省司法厅厅长', '省司法厅党委副书记'],
    正省部级: ['司法部常务副部长', '司法部党组副书记'],
    副国级: ['司法部部长', '中央政法委书记']
  },

  纪检监察: {
    科员: ['纪检监察员', '县纪委监委科员'],
    副科级: ['乡镇纪委书记', '派驻纪检监察组副组长', '县纪委监委室副主任'],
    正科级: ['县纪委常委', '派驻纪检监察组组长', '县纪委监委室主任'],
    副处级: ['县纪委副书记', '县监委副主任'],
    正处级: ['县纪委书记', '县监委主任'],
    副厅局级: ['市纪委副书记', '市监委副主任', '市纪委常委'],
    正厅局级: ['市纪委书记', '市监委主任', '省纪委常委'],
    副省部级: ['省纪委书记', '省监委主任', '省纪委副书记'],
    正省部级: ['中央纪委副书记', '国家监委副主任'],
    副国级: ['中央纪委书记', '国家监察委员会主任']
  }
}

/** 职级不认识（数据异常）时的兜底，退回老表的值 */
function legacyFallback(level) {
  const entry = LEVEL_LADDER.find((item) => item.level === level)
  return (entry && entry.typicalPosition) || ''
}

/** 某职级在各流派中的默认行政层级。不认识返回 '乡镇'（基层是默认归宿） */
export function tierOf(unitType, level) {
  if ((unitType === '常规局委' || unitType === '边缘部门')
      && (level === '副厅局级' || level === '正厅局级')) {
    return '省'
  }
  // 检察院/法院/司法局/纪委监委最低设在县一级，科级不该落到乡镇
  if (LEGAL_UNITS_AT_COUNTY.includes(unitType)
      && (level === '科员' || level === '副科级' || level === '正科级')) {
    return '县'
  }
  return TIER_OF_LEVEL[level] || '乡镇'
}

/** 该职级全部可选职务（已解析成字符串数组）。缺配置返回空数组 */
export function positionsFor(unitType, level) {
  const row = POSITION_POOLS[unitType]
  if (!row) return []
  const pool = row[level]
  return Array.isArray(pool) ? pool : []
}

/**
 * 把职务按「县/区」类型落到当前区县（统一出口，三处共用）。
 *
 * 处级（县层级）职务池写的是县域默认表述（副县长、县检察院），
 * 落在「区」里时把「县」改「区」（见 county.js 的 localizeCounty）。
 * 公安系统多一条专项：区里的规范叫法是「公安分局」而非「公安局」，
 * 所以「县公安局」要改成「区公安分局」，不是生硬的「区公安局」。
 */
function localizePosition(raw, unitType, level, district) {
  let out = raw
  if (tierOf(unitType, level) === '县') {
    out = localizeCounty(raw, district)
    if (unitType === '公安系统' && countyKindOf(district) === '区') {
      out = out.split('区公安局').join('区公安分局')
    }
  }
  return out
}

/**
 * 取职务（确定性：取第一顺位）。供读档修复、遴选、组织调离等
 * "组织决定"的场景使用——这些地方不该掷骰子。
 *
 * @param {string} [district] 所在区县名。处级（县层级）职务里的「县」
 *        会按区县类型改写成「区」——不传则不改写，退回县域默认表述。
 * @returns {string} 职务；取不到返回 ''
 */
export function positionFor(unit, unitType, level, district) {
  const pool = positionsFor(unitType, level)
  const raw = pool[0] || legacyFallback(level)
  return localizePosition(raw, unitType, level, district)
}

/**
 * 取职务（随机：平行岗位里抽一个）。供**晋升**使用——这是玩家
 * 仕途的分岔口，同一个职级，走哪条实权岗位看这一抽。
 *
 * @param {string} [district] 同 positionFor，处级职务按区县类型改写。
 * @returns {string} 职务；取不到回落到 positionFor
 */
export function randomPositionFor(unit, unitType, level, district) {
  const pool = positionsFor(unitType, level)
  const raw = pool.length
    ? pool[Math.floor(Math.random() * pool.length)]
    : positionFor(unit, unitType, level, district)
  return localizePosition(raw, unitType, level, district)
}

/**
 * 这个职务是不是 (单位, 职级) 该有的样子。
 * 读档时做一次修复：旧版或异常存档里存着"市档案局的镇长"，
 * 那不是玩家做过什么，是旧模型的错，不该逼玩家重开一局来消除它。
 * 只认得出才修——两个维度任一不认识就返回 true（放着不动）。
 */
export function isPositionConsistent(unit, unitType, level, position, district) {
  const pool = positionsFor(unitType, level)
  if (!pool.length) return true
  if (tierOf(unitType, level) !== '县') {
    return pool.includes(String(position || ''))
  }
  // 处级：候选池也按区县类型改写后再比对。不写这一半的话，
  // 「区委书记」会被误判成与池里的「县委书记」不一致，读档时反复"修复"。
  const localized = pool.map((p) => localizePosition(p, unitType, level, district))
  return localized.includes(String(position || ''))
}

/** 各流派的键，供界面/调试列举 */
export const TRACK_NAMES = Object.keys(POSITION_POOLS)

// 自检：四条流派的阶梯必须覆盖同一个职级集合，缺一格就会出现
// "某单位升到某级时职务算不出来"——而且只在玩家真的升到那一级时才暴露。
if (process.env.NODE_ENV !== 'production') {
  const missing = []
  TRACK_NAMES.forEach((name) => {
    LEVEL_LADDER.forEach((item) => {
      if (item.level === LEVEL_LADDER[LEVEL_LADDER.length - 1].level) return
      const pool = POSITION_POOLS[name][item.level]
      if (!Array.isArray(pool) || !pool.length) missing.push(`${name}·${item.level}`)
    })
  })
  if (missing.length) {
    console.error(`[职务表] 以下格子缺配置，升到该级时职务会算空：\n${missing.join('\n')}`)
  }
  const unknown = TRACK_NAMES.filter((name) => !UNIT_TYPES.includes(name))
  if (unknown.length) {
    console.error(`[职务表] 流派名不在 UNIT_TYPES 里：${unknown.join('、')}`)
  }
}
