/**
 * 出身起跑线（2.0.0 新增）。
 *
 * 开局先选出身，再参加录用考试。出身决定三样：
 *   ① 起跑的城市线级（一线/二线/三线/四线）——城市线级影响工资系数与生活成本；
 *   ② 一撮与出身绑定的初始属性（选调生有人带、军转干部有威信、事业编懂基层）；
 *   ③ 一笔安家费（按出身给，不是按单位给）。
 * 职级所有人一律从「科员」起步——**先从基层干起**，出身决定的是起点的手感，
 * 不是起点的高度。
 *
 * 城市线级在档案里是 player.cityTier，行政层级是 player.locationTier
 * （乡镇/县/市/省/国家，由 constants/positions.js 的 tierOf 随职级推）。
 */

import { RESOURCE_LIMITS } from './gameConfig'
import { archiveStartBonus } from '@/game/archive'

export const CITY_TIERS = ['一线', '二线', '三线', '四线']

/** 城市线级的工资 / 生活成本系数。四线挣得少花得也少，一线都高 */
export const CITY_TIER_EFFECT = {
  一线: { salary: 1.2, expense: 1.3, label: '一线城市' },
  二线: { salary: 1.05, expense: 1.1, label: '二线城市' },
  三线: { salary: 1.0, expense: 1.0, label: '三线城市' },
  四线: { salary: 0.9, expense: 0.85, label: '四线城市' }
}

/** 取某城市线级的工资系数，不认识按 1.0 */
export function citySalaryFactor(tier) {
  const effect = CITY_TIER_EFFECT[tier]
  return (effect && effect.salary) || 1
}

/** 取某城市线级的生活成本系数，不认识按 1.0 */
export function cityExpenseFactor(tier) {
  const effect = CITY_TIER_EFFECT[tier]
  return (effect && effect.expense) || 1
}

/**
 * 出身表。bonus 是**加到资源上的偏移量**（可负），settle 是入职安家费。
 * 加 settle 会同时进 money 与 legalIncome（合法收入），与考试分配那笔安家费
 * 同一套账——否则第一次财产申报就凭空多出一笔"说不清"的钱。
 */
export const BACKGROUNDS = [
  {
    id: 'xuandiao',
    label: '定向选调生',
    tag: '组织部重点关注',
    desc: '名校毕业，组织重点培养，起步就有人盯着你往上走。',
    passive: '选调快车道：35 岁前晋升年限 −2 季',
    cityTier: '二线',
    bonus: { authority: 15, mgmt: 10, ability: 8 },
    settle: 120000
  },
  {
    id: 'shengkao',
    label: '省考统招',
    tag: '稳稳当当的正式编制',
    desc: '笔试面试一路杀出，最普通的公务员，也是最稳的一条路。',
    passive: '最稳编制：无额外被动，全靠实干',
    cityTier: '三线',
    bonus: { ability: 8, popularity: 6 },
    settle: 60000
  },
  {
    id: 'shiyebian',
    label: '基层事业编',
    tag: '泥腿子出身',
    desc: '乡镇站所转岗，最懂基层的事，但往上走的路得自己闯。',
    passive: '逆袭线：科员升副科多熬 2 季',
    cityTier: '四线',
    bonus: { popularity: 15, kpi: 10, mgmt: -5 },
    settle: 20000
  },
  {
    id: 'rencai',
    label: '人才引进',
    tag: '高学历空降',
    desc: '被地方高价引进，起点待遇好，就是人面生、根基浅。',
    passive: '高学历光环：开局能力高，但根基浅',
    cityTier: '二线',
    bonus: { ability: 15, mgmt: 5, popularity: -5 },
    settle: 150000
  },
  {
    id: 'junzhuan',
    label: '军转干部',
    tag: '讲纪律有威信',
    desc: '脱下军装进机关，讲纪律、有威信，业务得从头学。',
    passive: '军旅底色：开局威信健康高，业务起步慢',
    cityTier: '三线',
    bonus: { authority: 20, health: 5, ability: -5 },
    settle: 80000
  }
]

/** 按 id 找出身，找不到返回 null */
export function backgroundOf(id) {
  return BACKGROUNDS.find((b) => b.id === id) || null
}

/** 把数值夹进资源区间 */
function clampResource(key, value) {
  const range = RESOURCE_LIMITS[key]
  if (!range) return null
  const num = Number(value)
  if (!Number.isFinite(num)) return null
  return Math.min(range[1], Math.max(range[0], Math.round(num)))
}

/**
 * 把出身写进档案（就地修改），并发放与出身绑定的属性与安家费。
 *
 * @param {Object} state 组件 $data（含 player / resources）
 * @param {string} bgId  BACKGROUNDS 里的 id
 * @returns {{ok: boolean, message: string}}
 */
export function applyBackground(state, bgId) {
  const bg = backgroundOf(bgId)
  if (!bg) return { ok: false, message: `出身「${bgId}」不存在，请重新选择。` }

  state.player.background = bg.id
  state.player.backgroundLabel = bg.label
  state.player.cityTier = bg.cityTier

  Object.keys(bg.bonus || {}).forEach((key) => {
    if (!(key in state.resources)) return
    const safe = clampResource(key, Number(state.resources[key]) + Number(bg.bonus[key]))
    if (safe !== null) state.resources[key] = safe
  })

  // 跨局生涯档案的初始加成（2.4.0，模块 8）：每解锁一个结局，下局考公
  // 获得微弱的威信/能力加成，鼓励玩家体验不同路线。
  const startBonus = archiveStartBonus()
  Object.keys(startBonus).forEach((key) => {
    if (!(key in state.resources)) return
    const safe = clampResource(key, Number(state.resources[key]) + Number(startBonus[key]))
    if (safe !== null) state.resources[key] = safe
  })

  const settle = Number(bg.settle) || 0
  state.player.money = (Number(state.player.money) || 0) + settle
  state.player.legalIncome = (Number(state.player.legalIncome) || 0) + settle

  return { ok: true, message: '', settle }
}

/**
 * 起跑线被动·任职年限调整（2.8.0，季度数）。
 *
 * 出身不止决定开局那一下，还贯穿全场：
 *   · 定向选调生 35 岁前走「快车道」——晋升年限要求少 2 季；
 *   · 基层事业编「转正慢」——科员升副科要多熬 2 季，逆袭更难，但通关更有味。
 *
 * 返回正数 = 年限要求缩短，负数 = 年限要求延长。其余出身返回 0。
 * 由 engine 在季末晋升裁定前叠加到"已任年限"上，只影响晋升年限判定，
 * 不动破格等其他支线。
 */
export function backgroundTenureAdjust(state) {
  const p = state.player || {}
  if (p.background === 'xuandiao' && Number(p.age) < 35) return 2
  if (p.background === 'shiyebian' && p.level === '科员') return -2
  return 0
}
