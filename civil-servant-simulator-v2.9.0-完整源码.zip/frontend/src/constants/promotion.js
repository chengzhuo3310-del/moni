/**
 * 晋升条件字典
 *
 * 语义约定：键 = 玩家【当前】职级，值 = 提任到【下一级】所需的最低门槛。
 * 例：玩家当前为"乡科级副职"，四项资源达到 { ability:40, mgmt:30, popularity:30, kpi:0 }
 *     且 risk <= 20，方满足提任"乡科级正职"的资历条件。
 *
 * 关于第 8 行：'省部级正职' 是阶梯顶点，没有"下一级"可升，该行为终点占位
 * （门槛字段全为 0），判定时由 nextLevelOf() 返回 null 直接拦截，不参与计算。
 * 保留它是为了让字典行数与职级数严格 1:1，避免后续维护时数漏。
 *
 * 关于 riskMax：廉政风险上限，一票否决——"带病提拔"是高压线。
 * 风险超标不看其他四项是否达标，直接触发暂缓提拔或纪委约谈，详见 evaluatePromotion()。
 */

import { RESOURCE_LABELS } from './gameConfig'

// 职级阶梯（有序）。用于推导"下一级"、判断是否已到终点。
//
// 2.0.0 起扩成 10 个大级别（科员 → 副国级），并给每一级挂上 `band`：
// 事件池、薪级、立案红线都按"档位"取数，10 级不能再靠 floor(idx/2) 硬推，
// 于是档位直接写在行上，谁读谁明白。
// 副国级并入「省部级」档——顶层那批党政大事本就可以共用一套料，不单开档。
export const LEVEL_LADDER = [
  { level: '科员', typicalPosition: '科员', band: '科级' },
  { level: '副科级', typicalPosition: '副镇长', band: '科级' },
  { level: '正科级', typicalPosition: '镇长', band: '科级' },
  { level: '副处级', typicalPosition: '副县长', band: '处级' },
  { level: '正处级', typicalPosition: '县长', band: '处级' },
  { level: '副厅局级', typicalPosition: '副市长', band: '厅级' },
  { level: '正厅局级', typicalPosition: '市长', band: '厅级' },
  { level: '副省部级', typicalPosition: '副省长', band: '省部级' },
  { level: '正省部级', typicalPosition: '省长', band: '省部级' },
  { level: '副国级', typicalPosition: '国务委员', band: '省部级' } // 阶梯顶点
]

// riskMax 一栏 1.4.0 整体上调（原 20/20/15/15/12/10/8）。玩家实测反馈"一票否决
// 卡得太死"：门槛越高，事件库里加风险的事反而越多，风险几乎只涨不落，
// 一旦越线就再也回不来，攒的政绩全废。放宽后越线仍然要付出代价（危机公关），
// 但不再是死局。
export const PROMOTION_REQUIREMENTS = {
  '科员': { ability: 30, mgmt: 20, popularity: 25, kpi: 0, riskMax: 40 },
  '副科级': { ability: 40, mgmt: 30, popularity: 30, kpi: 0, riskMax: 35 },
  '正科级': { ability: 55, mgmt: 45, popularity: 45, kpi: 20, riskMax: 30 },
  '副处级': { ability: 65, mgmt: 60, popularity: 55, kpi: 40, riskMax: 25 },
  '正处级': { ability: 75, mgmt: 70, popularity: 65, kpi: 65, riskMax: 20 },
  '副厅局级': { ability: 82, mgmt: 80, popularity: 72, kpi: 90, riskMax: 20 },
  '正厅局级': { ability: 88, mgmt: 88, popularity: 80, kpi: 125, riskMax: 20 },
  '副省部级': { ability: 93, mgmt: 94, popularity: 86, kpi: 145, riskMax: 20 },
  '正省部级': { ability: 96, mgmt: 96, popularity: 90, kpi: 150, riskMax: 18 },
  '副国级': { ability: 0, mgmt: 0, popularity: 0, kpi: 0, riskMax: 0 } // 终点占位
}

/**
 * 职级档位。科级/处级/厅级/省部级四档（副国级并入省部级档）。
 *
 * 放在这里而不是事件库里，是因为它有两个消费方：事件池按档取料（mock/localEvents.js），
 * 薪级表按档定月薪（constants/money.js）。抄两份的话，将来阶梯加一级，
 * 总有一边会静默漏掉新职级。
 */
export const BANDS = ['科级', '处级', '厅级', '省部级']

/** 职级 → 档位。未知职级返回 null，由调用方决定怎么兜底 */
export function bandOfLevel(level) {
  const entry = LEVEL_LADDER.find((item) => item.level === level)
  return (entry && entry.band) || null
}

// 参与门槛比对的四项资源（risk 单独走一票否决，不在此列）
export const PROMOTION_GATES = ['ability', 'mgmt', 'popularity', 'kpi']

/**
 * 名望加成：威信折算成门槛分的比率。
 *
 * 加这个是因为威信此前是个**废属性**——它只在事件结算里加减，不进任何判定。
 * 玩家几十局下来会发现涨威信不如涨工作能力，于是这条资源条等于不存在，
 * 而它占着八分之一的位置、还在事件里分走了不少选项的收益。
 *
 * 规则：每 10 点威信，四项资历门槛在**判定时**各视作 +1。
 * 上限 +10（威信满 100）。这个上限是刻意压着的：
 *   · 科级门槛 40，+10 是 25% 的折扣，前期威信能实打实帮你够线；
 *   · 省部级政绩门槛 145（政绩上限才 150），+10 只有 7%。
 * 也就是说"名望"越往上越顶不了硬资历——这跟体制里的实际观感是一致的，
 * 组织上不会因为你有威信就免了你的政绩。
 *
 * 为什么是"判定时视作"而不是直接加在 resources 上：威信是资源条上
 * 玩家看得见的一个数。悄悄给它加 6 点，资源条写着 62、判定按 68 算，
 * 两个数字对不上，玩家只会认为界面算错了。
 */
export const AUTHORITY_PER_BONUS = 10

/** 威信折算出的名望分。威信 62 → 6 */
export function authorityBonusOf(resources) {
  const authority = Number((resources && resources.authority) || 0)
  if (!(authority > 0)) return 0
  return Math.floor(authority / AUTHORITY_PER_BONUS)
}

/**
 * 风险超标的处置分档：
 *   risk <= riskMax                     → 通过
 *   riskMax < risk <= riskMax + margin  → 暂缓提拔（组织上再"观察观察"）
 *   risk >  riskMax + margin            → 纪委约谈（直接进谈话函询流程）
 * 该 margin 为建议值，待策划复核。
 */
export const RISK_INTERVIEW_MARGIN = 15

/**
 * 最低任职年限（兜底值）：任现职满 6 个季度（1.5 年）才列入提任考虑。
 *
 * 2.3.0 起不再是全局唯一值——提任年限按职级阶梯**差异化**（见下方
 * TENURE_QUARTERS_BY_LEVEL），越往上越要坐得住。这个常量退居为
 * "数据缺失时的兜底"，凡要取年限的地方一律走 tenureQuartersOf(level)。
 */
export const MIN_TENURE_QUARTERS = 6

/**
 * 差异化任职年限（季度）。键 = 玩家【当前】职级，值 = 提任到下一级所需的
 * 最低任职季度数。一年四季：8 季 = 2 年、12 季 = 3 年、16 季 = 4 年。
 *
 * ── 为什么年限要分级 ──────────────────────────────────────────
 * 旧版一个 6 季（1.5 年）用到底：科员熬 1.5 年、正厅也熬 1.5 年，
 * 越往上越显得"随便就能挪位置"——厅长和办事员用同一套时间成本，
 * 升迁的庄重感荡然无存。现实中干部职级越高、越要经历完整任期，
 * 年限分级正是把这份"越往上越重"的观感落到数值上。
 *
 * 分级本身也在给"破格提拔"留张力：年限上去了，坐满 3、4 年的收益
 * 被拉长，于是"不坐满、靠本事破格"才显得值钱（见 evaluateBreakthrough）。
 */
export const TENURE_QUARTERS_BY_LEVEL = {
  '科员': 8,       // 2 年
  '副科级': 8,     // 2 年
  '正科级': 12,    // 3 年
  '副处级': 12,    // 3 年
  '正处级': 12,    // 3 年
  '副厅局级': 12,  // 3 年
  '正厅局级': 16,  // 4 年
  '副省部级': 16,  // 4 年
  '正省部级': 16   // 4 年（提任副国级）
}

/** 取某职级提任下一级所需的最低任职季度数，无配置回落到 MIN_TENURE_QUARTERS */
export function tenureQuartersOf(level) {
  const v = TENURE_QUARTERS_BY_LEVEL[level]
  return Number.isFinite(Number(v)) ? Number(v) : MIN_TENURE_QUARTERS
}

/**
 * 任期（季度数）→ 年月文案。
 *
 * **凡是要给玩家看"任现职多久"的地方都走它**，理由与 formatMoney 一样：
 * 同一个数各写各的，改一处必漏一处。这条不是假设——原先就有三个地方
 * 各写各的，左栏提任面板和季末通报写成 `(q / 4).toFixed(1)` 年，
 * 结算画面的履历表却还写着"X 个季度"，同一个任期在两屏上三个说法。
 *
 * 为什么不用带小数的"年"：`toFixed(1)` 会写出 "0.5 年""1.0 年""2.5 年"
 * 这种念不出来的数。体制内讲任期论年月，半年就是六个月，
 * 没有"零点五年"这个说法。
 *
 * 一季三个月、一年四季，整数换算，没有余数问题：
 *   formatTenure(0)  === '0个月'     ← 刚上任那一季，不写"0年0个月"
 *   formatTenure(1)  === '3个月'
 *   formatTenure(4)  === '1年'
 *   formatTenure(10) === '2年6个月'  ← 即 MIN_TENURE_QUARTERS，提任年限
 */
export function formatTenure(quarters) {
  // 负数与脏存档一律按 0 处理：这是纯展示函数，宁可显示出错也不能返回 NaN
  const q = Math.max(0, Math.floor(Number(quarters) || 0))
  const years = Math.floor(q / 4)
  const months = (q % 4) * 3
  if (!years) return `${months}个月`
  return months ? `${years}年${months}个月` : `${years}年`
}

/**
 * 任期目标完成后的提任加分：四项资历门槛各降 10%。
 *
 * 这是"任期考核"的兑现口径——超额完成本任期重点任务，下次晋升考察时
 * 组织上高看一眼，门槛自然松一松。只降四项资历（能力/向上管理/人缘/政绩），
 * **不降廉政风险上限**：带病提拔是高压线，政绩再好也不能拿纪律换。
 * 也不降年限：年限是"坐得住"的硬地板，靠业绩冲不掉。
 */
export const TASK_GATE_DISCOUNT = 0.1

/**
 * 任期重点任务的政绩增量目标：履新时的政绩 + 这个数，就是本任期要达成的
 * 政绩目标。达标即置 flags.task_done，下次晋升门槛打折（见 TASK_GATE_DISCOUNT）。
 *
 * 15 点是"可够得着"的量级：一个任期 6~16 季，事件政绩一次 +5~15，
 * 认真处理几件正事就能凑够，躺平混日子则差一口气——考核的意义正在这里。
 */
export const TASK_KPI_DELTA = 15

/**
 * 派系边缘化的任职年限加码（季度数）。
 *
 * 纯函数：只吃派系与"靠山是否已倒"两个输入，不碰 state。这样 engine 的
 * advanceQuarter 与 GameMain 的 tenureQuarters 都能用**同一个数**，
 * 不会出现"面板说还差 2 季、季末裁定却要 6 季"的错位（与任职年限同源）。
 *
 * 靠山倒台后，站了队的人往后每一次提任都要多坐一年（4 季）；
 * 无派系的人不站队、也不受牵连——这正是"孤臣"这条路的代价与收益。
 */
export function factionEdgePenaltyQuarters(faction, factionFallen) {
  if (!factionFallen) return 0
  return faction === 'independent' ? 0 : 4
}

/**
 * 把提任门槛按折扣打折（四项资历打、风险上限不打）。
 * 返回新对象，不污染 PROMOTION_REQUIREMENTS 原表——那是全局字典，
 * 就地改会把一次性的加分永久焊死在数值上。
 */
export function discountedRequirement(req, discount) {
  const r = { ...req }
  const d = Number.isFinite(Number(discount)) ? Number(discount) : 0
  PROMOTION_GATES.forEach((key) => {
    if (Number(r[key]) > 0) r[key] = Math.max(0, Math.floor(Number(r[key]) * (1 - d)))
  })
  return r
}

/**
 * 老资格补偿（2.8.0）——「前松后死」的止血阀。
 *
 * 问题：处级往后四项门槛贴顶，玩家若在某一级因差 2 点人缘/向上管理被
 * 事件扣分，就会永久卡死到退休，政绩攒再多也白搭。这在现实里对应
 * 「论资排辈」：干得够久的老同志，组织上会在标准上适当放宽。
 *
 * 规则：任现职超过「规定年限 + 2 年」后才开始补偿，此后每多坐 1 年，
 * 四项资历门槛各降 3%，最多降 12%（封顶）。风险上限与年限从不打折——
 * 熬年头能通融资历，通融不了廉洁这条高压线。
 */
export const VETERAN_GRACE_QUARTERS = 8
export const VETERAN_DISCOUNT_PER_YEAR = 0.03
export const VETERAN_DISCOUNT_MAX = 0.12

/** 计算老资格补偿折扣（0 ~ 0.12）。tenure 未知（null）时返回 0。 */
export function veteranDiscountOf(tenure, tenureRequired) {
  if (!Number.isFinite(Number(tenure))) return 0
  const over = Number(tenure) - (Number(tenureRequired) + VETERAN_GRACE_QUARTERS)
  if (over <= 0) return 0
  const years = Math.floor(over / 4)
  return Math.min(VETERAN_DISCOUNT_MAX, years * VETERAN_DISCOUNT_PER_YEAR)
}

export const AUDIT_BASE_PASS = 0.8
export const AUDIT_PENALTY_PER_MILLION = 0.05
export const AUDIT_MIN_PASS = 0.2

/**
 * 审查未通过后挂起几个季度。6 个季度 = 一年半。
 *
 * ── 为什么单靠"本次否决"不够 ────────────────────────────────
 * 审查只在"四项 + 年限全达标"的那一季触发，而贪腐流**连续很多季都达标**：
 * 实测每局掷骰中位 9 次、最多 20 次。按 65% 通过率，掷 9 次全不过的概率是
 * 0.35^9 ≈ 0.0001——单次否决 + 下季再来，数学上等于没有这道关，
 * 平均只把提任推迟约 1.5 个季度。60 局实测：不走动的登顶率 8.3%（达标），
 * 会走动的 16.7%（目标 5~10%，没压住）。
 *
 * 挂起才是真正的闸门：把"每季重掷一次"变成"失败一次就出局一段时间"，
 * 掷骰次数从 9 次量级降到个位数，这道关才咬得住。
 *
 * 6 是 200 局（种子 2000~2199）扫出来的：2 季 15.5% / 3 季 11.5% /
 * 4 季 13% / **6 季 8%**——只有 6 季让"会走动"与"不走动"两个画像的
 * 登顶率同时落进 5~10%，且落马率仍在 40~60% 内。挂 12 季会过度
 * （走动 6.7%，把人彻底按住，提任的挫败感盖过廉政审查本身的意义）。
 *
 * 一年半在体制内也是个说得通的时长：够一次审查结论走完，
 * 又不至于让一个干部的政治生命就此停摆。
 */
export const AUDIT_HOLD_QUARTERS = 6

/** 审查未通过的通报。面板、季末通报、结局都用这一句，避免三处各写各的 */
export const AUDIT_FAIL_NOTE =
  '廉政审查未通过，材料挂起，一年半内不列入提任考虑。'

/**
 * 廉政审查：有案底的人提任时多过的一道关。
 *
 * ── 为什么要有这一道 ────────────────────────────────────────
 * 记账漏洞修掉之后，贪腐流的落马率回到了 51.7%（目标 40~60%），
 * 但登顶率还停在 16.7%，目标是 5~10%。差的这一截是**幸存者**：
 * 差额还没攒到立案线、或者赌赢了决定书的那批人，照样一级一级往上走。
 * 而现实里"带病提拔"本来就是组织上最防的一件事——
 * 差额没到立案线不等于组织上不知道，只等于还不到收网的时候。
 *
 * ── 通过率为什么跟金额挂钩 ──────────────────────────────────
 * 审查不是掷一次骰子，是**看材料**：账上说不清的部分越多，
 * 能自圆其说的空间越小。这条曲线与决定书上狡辩成功率同源
 * （见 investigation.js 的 excuseOdds，那边是每百万扣 3 个点）——
 * 同一笔赃款，在决定书上让你张不开嘴，在审查室里同样让你张不开嘴。
 *
 * 退过赃的人这里会轻松很多：surrender() 把 illicitWealth 清零，
 * 于是审查通过率回到 80%。这是**有意**的——账已经交清了，
 * 组织上要看的正是"有没有交清"，而不是"历史上有没有拿过"。
 *
 * ── 为什么单独成一个函数，不并进 evaluatePromotion ──────────
 * evaluatePromotion 是**纯函数**，PromotionPanel.vue 每次渲染都会调它。
 * 把掷骰子塞进去，面板显示的结果会和季末裁定的结果不是同一次——
 * 玩家看到"通过"，季末却被告知没通过，那是这个界面上最不该有的东西。
 * 所以这里只提供**通过率**（纯函数、可测），掷骰子由引擎在裁定那一刻做。
 *
 * @param {number} illicitWealth 累计非法所得（退赃后已清零）
 * @returns {number} 通过率 0~1
 */
export function auditPassOddsOf(illicitWealth) {
  const millions = (Number(illicitWealth) || 0) / 1000000
  const odds = AUDIT_BASE_PASS - millions * AUDIT_PENALTY_PER_MILLION
  return Math.max(AUDIT_MIN_PASS, Math.min(1, odds))
}

// 提任裁定结果
export const PROMOTION_VERDICT = {
  PROMOTABLE: 'promotable',         // 条件达标，可上会研究
  PENDING: 'pending',               // 资历未到，暂缓提拔
  TENURE_PENDING: 'tenure_pending', // 四项都达标了，只是任现职年限不够
  RISK_SUSPENDED: 'risk_suspended', // 廉政风险超标，暂缓提拔
  RISK_INTERVIEW: 'risk_interview', // 廉政风险严重超标，触发纪委约谈
  AUDIT_FAILED: 'audit_failed',     // 四项与年限都达标，廉政审查没过（有案底）
  AUDIT_HELD: 'audit_held',         // 审查已挂起，本季连骰子都不掷
  TERMINAL: 'terminal',             // 已到阶梯顶点，无可再升
  NO_CONFIG: 'no_config'            // 字典缺该职级配置（数据异常，需排查）
}

/** 取某职级的下一级，已到顶点返回 null */
export function nextLevelOf(level) {
  const idx = LEVEL_LADDER.findIndex((item) => item.level === level)
  if (idx === -1 || idx === LEVEL_LADDER.length - 1) return null
  return LEVEL_LADDER[idx + 1].level
}

/**
 * 取某职级的上一级，已在最底层（或职级不在阶梯里）返回 null。
 *
 * 降级用的。只在"认罪退赃、降一级使用"这一处用到——
 * 它不参与晋升逻辑，所以刻意不给它任何门槛判定：
 * 降级是组织决定，不看你的四项达标没有。
 */
export function prevLevelOf(level) {
  const idx = LEVEL_LADDER.findIndex((item) => item.level === level)
  if (idx <= 0) return null
  return LEVEL_LADDER[idx - 1].level
}

/** 取某职级的提任门槛，无配置返回 null */
export function requirementOf(level) {
  return PROMOTION_REQUIREMENTS[level] || null
}

/**
 * 提任裁定。纯函数，前端与后端可共用同一套规则。
 *
 * @param {Object} resources      八项资源当前值
 * @param {string} level          玩家当前职级
 * @param {number} [tenureQuarters] 任现职已满几个季度。**不给就不判年限**——
 *        这让不掌握年限的调用方（如只渲染资源条的场景）行为与加这一条之前完全一致，
 *        不必为了签名完整硬塞一个假值进来。
 * @param {boolean} [taskDone] 本任期重点任务是否已完成。为 true 时四项资历门槛
 *        按 TASK_GATE_DISCOUNT 打折（任期考核加分），风险上限与年限不打折。
 * @returns {{
 *   verdict: string,        // PROMOTION_VERDICT 之一
 *   level: string,          // 当前职级
 *   nextLevel: string|null, // 拟提任职级
 *   requirement: Object|null,
 *   gateRequirement: Object|null, // 打折后的门槛（taskDone 时四项略降）
 *   missing: Array<{key, label, current, raw, required}>, // 尚缺的门槛（current 已含名望分）
 *   riskOver: number,       // 风险超出上限的幅度，未超标为 0
 *   authorityBonus: number, // 威信折算出的名望分（四项门槛各 +这么多）
 *   tenureQuarters: number|null, // 任现职季度数，未知为 null
 *   tenureShort: number,    // 还差几个季度才够年限，够或未知为 0
 *   tenureRequired: number, // 该职级的最低任职季度数（差异化年限）
 *   taskDone: boolean,      // 任期考核是否已达成（加分是否生效）
 *   reason: string          // 面向玩家的说辞
 * }}
 */
export function evaluatePromotion(resources, level, tenureQuarters, taskDone) {
  const next = nextLevelOf(level)
  const authorityBonus = authorityBonusOf(resources)
  const knownTenure = Number.isFinite(Number(tenureQuarters))
  const tenure = knownTenure ? Number(tenureQuarters) : null
  const tenureRequired = tenureQuartersOf(level)
  const tenureShort = knownTenure ? Math.max(0, tenureRequired - tenure) : 0
  const done = Boolean(taskDone)
  // 老资格补偿：熬年头能通融资历门槛，但通融不了风险上限（2.8.0）
  const veteranDiscount = veteranDiscountOf(tenure, tenureRequired)

  // 已到顶点
  if (!next) {
    return {
      verdict: PROMOTION_VERDICT.TERMINAL,
      level,
      nextLevel: null,
      requirement: null,
      gateRequirement: null,
      missing: [],
      riskOver: 0,
      authorityBonus,
      tenureQuarters: tenure,
      tenureShort: 0,
      tenureRequired,
      taskDone: done,
      veteranDiscount: 0,
      reason: '已至阶梯顶点，再无提任空间。'
    }
  }

  const req = requirementOf(level)
  // 任期考核加分 + 老资格补偿：两者都可对四项资历门槛打折，风险上限不动。
  // gateReq 供四项比较用；requirement 保留原始值，riskMax 始终读它。
  let gateReq = req
  if (req && done) gateReq = discountedRequirement(gateReq, TASK_GATE_DISCOUNT)
  if (req && veteranDiscount > 0) gateReq = discountedRequirement(gateReq, veteranDiscount)
  const base = {
    level,
    nextLevel: next,
    requirement: req,
    gateRequirement: gateReq,
    missing: [],
    riskOver: 0,
    authorityBonus,
    tenureQuarters: tenure,
    tenureShort,
    tenureRequired,
    taskDone: done,
    veteranDiscount
  }

  if (!req) {
    return {
      ...base,
      verdict: PROMOTION_VERDICT.NO_CONFIG,
      reason: `晋升条件字典缺少「${level}」的配置，请排查数据。`
    }
  }

  // ── 一票否决：先查廉政风险，风险超标时不看其余四项 ──
  const risk = Number(resources.risk) || 0
  const riskOver = risk - req.riskMax
  if (riskOver > 0) {
    const toInterview = riskOver > RISK_INTERVIEW_MARGIN
    return {
      ...base,
      riskOver,
      verdict: toInterview
        ? PROMOTION_VERDICT.RISK_INTERVIEW
        : PROMOTION_VERDICT.RISK_SUSPENDED,
      reason: toInterview
        ? `廉政风险 ${risk}% 已远超上限 ${req.riskMax}%，先到纪委谈谈话。`
        : `廉政风险 ${risk}% 超出上限 ${req.riskMax}%，此次提任暂缓。`
    }
  }

  // ── 四项资历门槛 ──
  // 名望分只在这一处生效：比较的是"当前值 + 名望分"，不是 resources 本身。
  // 判定和提示都走同一个 effective，界面上就不会出现"数字没够、却显示已达标"。
  const effectiveOf = (key) => (Number(resources[key]) || 0) + authorityBonus

  const missing = PROMOTION_GATES.filter((key) => effectiveOf(key) < gateReq[key])
    .map((key) => ({
      key,
      label: RESOURCE_LABELS[key] || key,
      current: effectiveOf(key),
      raw: Number(resources[key]) || 0,
      required: gateReq[key]
    }))

  if (missing.length > 0) {
    return {
      ...base,
      missing,
      verdict: PROMOTION_VERDICT.PENDING,
      reason: '资历尚浅，组织上再考察考察。'
    }
  }

  // ── 任职年限：四项都够了，但椅子还没坐热 ──
  // 排在四项之后、PROMOTABLE 之前，是为了让提示**只在真达标时**出现。
  // 反过来的话，一个四项还差一半的人会看到"四项条件已达标"，
  // 那句话会当场把玩家对这个界面的信任打掉。
  if (tenureShort > 0) {
    return {
      ...base,
      verdict: PROMOTION_VERDICT.TENURE_PENDING,
      reason: '四项条件已达标，但任职年限尚浅，组织上再考察考察。'
    }
  }

  return {
    ...base,
    verdict: PROMOTION_VERDICT.PROMOTABLE,
    reason: `条件成熟，可提请研究提任「${next}」。`
  }
}

/**
 * 破格提拔（2.3.0 新增）——「加分逻辑要合理、也要有爽点」的核心落点。
 *
 * 常规年限坐满才提拔，是"按部就班"；破格提拔是"不按部就班"的那条
 * 稀缺通道：年限不够，但本事硬、有硬货（立功/举荐/连续优秀），
 * 组织上破例一次。它让"熬年限"不再是唯一解，也给"选择有走向"再添一层：
 * 平时是攒资源，还是攒立功的 flag，走的是两条完全不同的路。
 *
 * 破格的三个约束（缺一不可，任一不满足都不解锁）：
 *   ① 至少任满 1 年——不能同年连跳；
 *   ② 工作能力与政绩都达到当前职级常规标准的 130% 以上——本事得真硬；
 *   ③ 廉政风险 ≤ 15——带病提拔不破这个例；
 * 外加一条"触发理由"：merit / excellent / mentor / elite 四选一。
 *
 * 代价：破格上岸后新岗位人缘 -10（同事眼红），且禁止连续两任破格——
 * 破一次要按常规年限沉淀一任，否则"破格"就退化成"常规"。
 */
export const BREAKTHROUGH = {
  abilityKpiMult: 1.3,   // 能力与政绩需达常规标准的 130%
  riskMax: 15,           // 廉政风险 ≤ 15
  minTenure: 4,          // 至少已任 1 年（4 季）
  popularityCost: 10,    // 破格代价：新岗位人缘 -10
  // 触发条件（满足其一即可）。flag 由事件选项 setFlag 置位（见 mock/extraEvents.js）。
  triggers: [
    { flag: 'merit', label: '重大立功（二等功及以上 / 国家级表彰）' },
    { flag: 'excellent', label: '连续两年考核优秀' },
    { flag: 'mentor', label: '上级强力举荐' },
    { flag: 'elite', label: '公开遴选高分通过' }
  ]
}

/**
 * 破格提拔判定。纯函数，只判够不够格，不改状态、不掷骰子。
 *
 * @param {Object} resources  八项资源当前值
 * @param {string} level      当前职级
 * @param {number} tenureQuarters 任现职季度数
 * @param {Object} flags      gameStatus.flags（触发理由的来源）
 * @param {boolean} [lastWasBreakthrough] 上一任是否已是破格（禁止连破）
 * @returns {{eligible:boolean, triggers?:Array, hardShort?:Array,
 *            abilityNeed?:number, kpiNeed?:number, reason:string}}
 */
export function evaluateBreakthrough(resources, level, tenureQuarters, flags, lastWasBreakthrough) {
  const next = nextLevelOf(level)
  if (!next) return { eligible: false, reason: '已至阶梯顶点。' }

  const req = requirementOf(level)
  if (!req) return { eligible: false, reason: '晋升条件字典缺配置，请排查数据。' }

  // ① 至少任满 1 年
  const tenure = Number(tenureQuarters) || 0
  if (tenure < BREAKTHROUGH.minTenure) {
    return {
      eligible: false,
      reason: `任现职 ${formatTenure(tenure)}，未满 ${formatTenure(BREAKTHROUGH.minTenure)}，`
        + '同年不连跳。'
    }
  }

  // ② 禁止连续两任破格
  if (lastWasBreakthrough) {
    return { eligible: false, reason: '上一任已是破格提拔，本任需按常规年限沉淀。' }
  }

  // ③ 硬性门槛：能力 + 政绩 ≥ 常规标准 130%；风险 ≤ 15
  const ability = Number(resources.ability) || 0
  const kpi = Number(resources.kpi) || 0
  const risk = Number(resources.risk) || 0
  const abilityNeed = Math.ceil(req.ability * BREAKTHROUGH.abilityKpiMult)
  const kpiNeed = Math.ceil(req.kpi * BREAKTHROUGH.abilityKpiMult)

  const hardShort = []
  if (ability < abilityNeed) hardShort.push(`工作能力 ${ability}/${abilityNeed}`)
  if (kpi < kpiNeed) hardShort.push(`政绩 ${kpi}/${kpiNeed}`)
  if (risk > BREAKTHROUGH.riskMax) hardShort.push(`廉政风险 ${risk}%（需 ≤ ${BREAKTHROUGH.riskMax}%）`)

  if (hardShort.length) {
    return {
      eligible: false,
      hardShort,
      abilityNeed,
      kpiNeed,
      reason: `硬性门槛未达：${hardShort.join('、')}。`
    }
  }

  // ④ 触发理由（四选一）
  const hit = BREAKTHROUGH.triggers.filter((t) => flags && flags[t.flag])
  if (!hit.length) {
    return {
      eligible: false,
      abilityNeed,
      kpiNeed,
      reason: '硬性门槛已够，但缺少破格理由（立功 / 连续优秀 / 强力举荐 / 遴选其一）。'
    }
  }

  return {
    eligible: true,
    triggers: hit,
    abilityNeed,
    kpiNeed,
    risk,
    reason: `符合破格条件，可跳过剩余年限直接提拔。`
      + `代价：新岗位人缘 −${BREAKTHROUGH.popularityCost}，且下任不得再破格。`
  }
}
