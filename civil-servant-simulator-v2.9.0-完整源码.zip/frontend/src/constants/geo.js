/**
 * 真实中国行政区划与城市线级（2.1.0 新增）。
 *
 * 目的：把"XX省/XX市/XX县/XX镇"这种占位地名，换成真实、可读的省市。
 * 城市线级（一线~四线）与 constants/backgrounds.js 的 CITY_TIER_EFFECT
 * 联动——你在哪座城，决定工资系数与生活成本。
 *
 * 数据口径说明：
 *   · 34 个省级行政区全部收录（含直辖市、自治区、特别行政区；
 *     台湾地区城市按"台湾省"口径录入，香港/澳门按特别行政区口径录入）。
 *   · 地级市为**代表性收录**（各省省会 + 主要城市，约 200 个），
 *     非全量 293 个地级市的穷举——全量穷举既无必要，也易因区划调整失真。
 *   · 区县、镇街为**真实名称抽样池**，随机组合；行政层级（乡镇/县/市/省）
 *     与职级挂钩，单位名按层级用真实地名拼装（见 unitNameOf）。
 */

import { tierOf } from './positions'
import { countyKindOf } from './county'

/** 省级行政区。type 仅作展示 */
export const PROVINCES = [
  '北京市', '天津市', '上海市', '重庆市',
  '河北省', '山西省', '辽宁省', '吉林省', '黑龙江省',
  '江苏省', '浙江省', '安徽省', '福建省', '江西省', '山东省',
  '河南省', '湖北省', '湖南省', '广东省', '海南省',
  '四川省', '贵州省', '云南省', '陕西省', '甘肃省', '青海省',
  '台湾省',
  '内蒙古自治区', '广西壮族自治区', '西藏自治区', '宁夏回族自治区', '新疆维吾尔自治区',
  '香港特别行政区', '澳门特别行政区'
]

/** 城市线级枚举（与 backgrounds.js 的 CITY_TIER_EFFECT 键一致） */
export const CITY_TIER_NAMES = ['一线', '二线', '三线', '四线']

/**
 * 城市表：name / province / tier。
 * tier 参照通行的城市商业魅力分级做了简化（一线 4 城，其余归入二~四线）。
 */
export const CITIES = [
  // 直辖市
  { name: '北京市', province: '北京市', tier: '一线' },
  { name: '上海市', province: '上海市', tier: '一线' },
  { name: '天津市', province: '天津市', tier: '二线' },
  { name: '重庆市', province: '重庆市', tier: '二线' },

  // 河北
  { name: '石家庄市', province: '河北省', tier: '二线' },
  { name: '唐山市', province: '河北省', tier: '三线' },
  { name: '保定市', province: '河北省', tier: '三线' },
  { name: '邯郸市', province: '河北省', tier: '三线' },
  { name: '秦皇岛市', province: '河北省', tier: '三线' },
  { name: '廊坊市', province: '河北省', tier: '三线' },
  { name: '沧州市', province: '河北省', tier: '三线' },
  { name: '邢台市', province: '河北省', tier: '三线' },
  { name: '张家口市', province: '河北省', tier: '四线' },
  { name: '承德市', province: '河北省', tier: '四线' },
  { name: '衡水市', province: '河北省', tier: '四线' },

  // 山西
  { name: '太原市', province: '山西省', tier: '二线' },
  { name: '大同市', province: '山西省', tier: '三线' },
  { name: '临汾市', province: '山西省', tier: '三线' },
  { name: '运城市', province: '山西省', tier: '三线' },
  { name: '长治市', province: '山西省', tier: '四线' },
  { name: '晋中市', province: '山西省', tier: '四线' },

  // 辽宁
  { name: '沈阳市', province: '辽宁省', tier: '二线' },
  { name: '大连市', province: '辽宁省', tier: '二线' },
  { name: '鞍山市', province: '辽宁省', tier: '三线' },
  { name: '抚顺市', province: '辽宁省', tier: '三线' },
  { name: '锦州市', province: '辽宁省', tier: '三线' },
  { name: '营口市', province: '辽宁省', tier: '三线' },

  // 吉林
  { name: '长春市', province: '吉林省', tier: '二线' },
  { name: '吉林市', province: '吉林省', tier: '三线' },
  { name: '延边州', province: '吉林省', tier: '三线' },
  { name: '四平市', province: '吉林省', tier: '四线' },
  { name: '通化市', province: '吉林省', tier: '四线' },
  { name: '松原市', province: '吉林省', tier: '四线' },

  // 黑龙江
  { name: '哈尔滨市', province: '黑龙江省', tier: '二线' },
  { name: '大庆市', province: '黑龙江省', tier: '三线' },
  { name: '齐齐哈尔市', province: '黑龙江省', tier: '三线' },
  { name: '牡丹江市', province: '黑龙江省', tier: '三线' },
  { name: '佳木斯市', province: '黑龙江省', tier: '三线' },

  // 江苏
  { name: '南京市', province: '江苏省', tier: '二线' },
  { name: '苏州市', province: '江苏省', tier: '二线' },
  { name: '无锡市', province: '江苏省', tier: '二线' },
  { name: '常州市', province: '江苏省', tier: '二线' },
  { name: '南通市', province: '江苏省', tier: '二线' },
  { name: '徐州市', province: '江苏省', tier: '二线' },
  { name: '扬州市', province: '江苏省', tier: '三线' },
  { name: '镇江市', province: '江苏省', tier: '三线' },
  { name: '泰州市', province: '江苏省', tier: '三线' },
  { name: '盐城市', province: '江苏省', tier: '三线' },
  { name: '淮安市', province: '江苏省', tier: '三线' },
  { name: '连云港市', province: '江苏省', tier: '三线' },
  { name: '宿迁市', province: '江苏省', tier: '三线' },

  // 浙江
  { name: '杭州市', province: '浙江省', tier: '二线' },
  { name: '宁波市', province: '浙江省', tier: '二线' },
  { name: '温州市', province: '浙江省', tier: '二线' },
  { name: '绍兴市', province: '浙江省', tier: '二线' },
  { name: '嘉兴市', province: '浙江省', tier: '三线' },
  { name: '金华市', province: '浙江省', tier: '三线' },
  { name: '台州市', province: '浙江省', tier: '三线' },
  { name: '湖州市', province: '浙江省', tier: '三线' },
  { name: '丽水市', province: '浙江省', tier: '四线' },
  { name: '衢州市', province: '浙江省', tier: '四线' },
  { name: '舟山市', province: '浙江省', tier: '四线' },

  // 安徽
  { name: '合肥市', province: '安徽省', tier: '二线' },
  { name: '芜湖市', province: '安徽省', tier: '三线' },
  { name: '蚌埠市', province: '安徽省', tier: '三线' },
  { name: '马鞍山市', province: '安徽省', tier: '三线' },
  { name: '安庆市', province: '安徽省', tier: '三线' },
  { name: '滁州市', province: '安徽省', tier: '三线' },
  { name: '阜阳市', province: '安徽省', tier: '三线' },

  // 福建
  { name: '福州市', province: '福建省', tier: '二线' },
  { name: '厦门市', province: '福建省', tier: '二线' },
  { name: '泉州市', province: '福建省', tier: '二线' },
  { name: '漳州市', province: '福建省', tier: '三线' },
  { name: '莆田市', province: '福建省', tier: '三线' },
  { name: '龙岩市', province: '福建省', tier: '三线' },
  { name: '三明市', province: '福建省', tier: '四线' },
  { name: '宁德市', province: '福建省', tier: '四线' },

  // 江西
  { name: '南昌市', province: '江西省', tier: '二线' },
  { name: '赣州市', province: '江西省', tier: '三线' },
  { name: '九江市', province: '江西省', tier: '三线' },
  { name: '上饶市', province: '江西省', tier: '三线' },
  { name: '宜春市', province: '江西省', tier: '三线' },
  { name: '吉安市', province: '江西省', tier: '三线' },

  // 山东
  { name: '济南市', province: '山东省', tier: '二线' },
  { name: '青岛市', province: '山东省', tier: '二线' },
  { name: '烟台市', province: '山东省', tier: '二线' },
  { name: '潍坊市', province: '山东省', tier: '三线' },
  { name: '临沂市', province: '山东省', tier: '三线' },
  { name: '淄博市', province: '山东省', tier: '三线' },
  { name: '济宁市', province: '山东省', tier: '三线' },
  { name: '泰安市', province: '山东省', tier: '三线' },
  { name: '威海市', province: '山东省', tier: '三线' },
  { name: '东营市', province: '山东省', tier: '三线' },
  { name: '日照市', province: '山东省', tier: '三线' },
  { name: '德州市', province: '山东省', tier: '三线' },
  { name: '聊城市', province: '山东省', tier: '三线' },
  { name: '菏泽市', province: '山东省', tier: '三线' },

  // 河南
  { name: '郑州市', province: '河南省', tier: '二线' },
  { name: '洛阳市', province: '河南省', tier: '二线' },
  { name: '南阳市', province: '河南省', tier: '三线' },
  { name: '新乡市', province: '河南省', tier: '三线' },
  { name: '许昌市', province: '河南省', tier: '三线' },
  { name: '开封市', province: '河南省', tier: '三线' },
  { name: '商丘市', province: '河南省', tier: '三线' },
  { name: '周口市', province: '河南省', tier: '三线' },
  { name: '信阳市', province: '河南省', tier: '三线' },
  { name: '安阳市', province: '河南省', tier: '三线' },
  { name: '平顶山市', province: '河南省', tier: '三线' },
  { name: '焦作市', province: '河南省', tier: '三线' },

  // 湖北
  { name: '武汉市', province: '湖北省', tier: '二线' },
  { name: '宜昌市', province: '湖北省', tier: '三线' },
  { name: '襄阳市', province: '湖北省', tier: '三线' },
  { name: '荆州市', province: '湖北省', tier: '三线' },
  { name: '黄石市', province: '湖北省', tier: '三线' },
  { name: '十堰市', province: '湖北省', tier: '三线' },
  { name: '孝感市', province: '湖北省', tier: '三线' },
  { name: '黄冈市', province: '湖北省', tier: '三线' },

  // 湖南
  { name: '长沙市', province: '湖南省', tier: '二线' },
  { name: '株洲市', province: '湖南省', tier: '三线' },
  { name: '湘潭市', province: '湖南省', tier: '三线' },
  { name: '衡阳市', province: '湖南省', tier: '三线' },
  { name: '岳阳市', province: '湖南省', tier: '三线' },
  { name: '常德市', province: '湖南省', tier: '三线' },
  { name: '郴州市', province: '湖南省', tier: '三线' },
  { name: '益阳市', province: '湖南省', tier: '三线' },
  { name: '永州市', province: '湖南省', tier: '三线' },
  { name: '怀化市', province: '湖南省', tier: '三线' },
  { name: '邵阳市', province: '湖南省', tier: '三线' },

  // 广东
  { name: '广州市', province: '广东省', tier: '一线' },
  { name: '深圳市', province: '广东省', tier: '一线' },
  { name: '佛山市', province: '广东省', tier: '二线' },
  { name: '东莞市', province: '广东省', tier: '二线' },
  { name: '珠海市', province: '广东省', tier: '二线' },
  { name: '中山市', province: '广东省', tier: '三线' },
  { name: '惠州市', province: '广东省', tier: '三线' },
  { name: '江门市', province: '广东省', tier: '三线' },
  { name: '湛江市', province: '广东省', tier: '三线' },
  { name: '茂名市', province: '广东省', tier: '三线' },
  { name: '肇庆市', province: '广东省', tier: '三线' },
  { name: '汕头市', province: '广东省', tier: '三线' },
  { name: '揭阳市', province: '广东省', tier: '三线' },
  { name: '清远市', province: '广东省', tier: '三线' },
  { name: '梅州市', province: '广东省', tier: '四线' },
  { name: '韶关市', province: '广东省', tier: '四线' },
  { name: '河源市', province: '广东省', tier: '四线' },
  { name: '阳江市', province: '广东省', tier: '四线' },
  { name: '潮州市', province: '广东省', tier: '四线' },
  { name: '汕尾市', province: '广东省', tier: '四线' },
  { name: '云浮市', province: '广东省', tier: '四线' },

  // 海南
  { name: '海口市', province: '海南省', tier: '三线' },
  { name: '三亚市', province: '海南省', tier: '三线' },
  { name: '儋州市', province: '海南省', tier: '四线' },

  // 四川
  { name: '成都市', province: '四川省', tier: '二线' },
  { name: '绵阳市', province: '四川省', tier: '三线' },
  { name: '宜宾市', province: '四川省', tier: '三线' },
  { name: '德阳市', province: '四川省', tier: '三线' },
  { name: '南充市', province: '四川省', tier: '三线' },
  { name: '泸州市', province: '四川省', tier: '三线' },
  { name: '乐山市', province: '四川省', tier: '三线' },
  { name: '达州市', province: '四川省', tier: '三线' },
  { name: '攀枝花市', province: '四川省', tier: '三线' },
  { name: '眉山市', province: '四川省', tier: '三线' },
  { name: '自贡市', province: '四川省', tier: '四线' },
  { name: '内江市', province: '四川省', tier: '四线' },
  { name: '遂宁市', province: '四川省', tier: '四线' },

  // 贵州
  { name: '贵阳市', province: '贵州省', tier: '二线' },
  { name: '遵义市', province: '贵州省', tier: '三线' },
  { name: '毕节市', province: '贵州省', tier: '三线' },
  { name: '六盘水市', province: '贵州省', tier: '四线' },
  { name: '安顺市', province: '贵州省', tier: '四线' },

  // 云南
  { name: '昆明市', province: '云南省', tier: '二线' },
  { name: '曲靖市', province: '云南省', tier: '三线' },
  { name: '玉溪市', province: '云南省', tier: '三线' },
  { name: '大理州', province: '云南省', tier: '三线' },
  { name: '丽江市', province: '云南省', tier: '三线' },
  { name: '红河州', province: '云南省', tier: '三线' },

  // 陕西
  { name: '西安市', province: '陕西省', tier: '二线' },
  { name: '咸阳市', province: '陕西省', tier: '三线' },
  { name: '宝鸡市', province: '陕西省', tier: '三线' },
  { name: '渭南市', province: '陕西省', tier: '三线' },
  { name: '汉中市', province: '陕西省', tier: '三线' },
  { name: '榆林市', province: '陕西省', tier: '三线' },
  { name: '延安市', province: '陕西省', tier: '三线' },

  // 甘肃
  { name: '兰州市', province: '甘肃省', tier: '二线' },
  { name: '天水市', province: '甘肃省', tier: '三线' },
  { name: '酒泉市', province: '甘肃省', tier: '三线' },
  { name: '张掖市', province: '甘肃省', tier: '三线' },
  { name: '庆阳市', province: '甘肃省', tier: '三线' },

  // 青海
  { name: '西宁市', province: '青海省', tier: '三线' },
  { name: '海东市', province: '青海省', tier: '四线' },

  // 台湾
  { name: '台北市', province: '台湾省', tier: '二线' },
  { name: '新北市', province: '台湾省', tier: '三线' },
  { name: '高雄市', province: '台湾省', tier: '三线' },
  { name: '台中市', province: '台湾省', tier: '三线' },
  { name: '台南市', province: '台湾省', tier: '三线' },

  // 内蒙古
  { name: '呼和浩特市', province: '内蒙古自治区', tier: '二线' },
  { name: '包头市', province: '内蒙古自治区', tier: '三线' },
  { name: '鄂尔多斯市', province: '内蒙古自治区', tier: '三线' },
  { name: '赤峰市', province: '内蒙古自治区', tier: '三线' },
  { name: '呼伦贝尔市', province: '内蒙古自治区', tier: '三线' },

  // 广西
  { name: '南宁市', province: '广西壮族自治区', tier: '二线' },
  { name: '柳州市', province: '广西壮族自治区', tier: '三线' },
  { name: '桂林市', province: '广西壮族自治区', tier: '三线' },
  { name: '北海市', province: '广西壮族自治区', tier: '三线' },
  { name: '玉林市', province: '广西壮族自治区', tier: '三线' },

  // 西藏
  { name: '拉萨市', province: '西藏自治区', tier: '三线' },
  { name: '日喀则市', province: '西藏自治区', tier: '四线' },
  { name: '昌都市', province: '西藏自治区', tier: '四线' },
  { name: '林芝市', province: '西藏自治区', tier: '四线' },

  // 宁夏
  { name: '银川市', province: '宁夏回族自治区', tier: '二线' },
  { name: '石嘴山市', province: '宁夏回族自治区', tier: '四线' },
  { name: '吴忠市', province: '宁夏回族自治区', tier: '四线' },
  { name: '固原市', province: '宁夏回族自治区', tier: '四线' },

  // 新疆
  { name: '乌鲁木齐市', province: '新疆维吾尔自治区', tier: '二线' },
  { name: '喀什地区', province: '新疆维吾尔自治区', tier: '三线' },
  { name: '伊犁州', province: '新疆维吾尔自治区', tier: '三线' },
  { name: '昌吉州', province: '新疆维吾尔自治区', tier: '三线' },
  { name: '克拉玛依市', province: '新疆维吾尔自治区', tier: '三线' },

  // 特别行政区
  { name: '香港', province: '香港特别行政区', tier: '一线' },
  { name: '澳门', province: '澳门特别行政区', tier: '二线' }
]

/**
 * 区名抽样池（真实名称，用于直辖市、一线城市与地级市**城区**）。
 * 直辖市/一线城市只配「区 + 街道」，不该出现「县 + 镇」——
 * 北京配个"博罗县"再下到"石湾镇"，那是把地级市的乡镇套在直辖市头上。
 */
export const URBAN_DISTRICTS = [
  '天河区', '越秀区', '海珠区', '白云区', '荔湾区', '黄埔区', '番禺区',
  '南山区', '福田区', '罗湖区', '宝安区', '龙岗区', '龙华区', '光明区',
  '朝阳区', '海淀区', '东城区', '西城区', '丰台区', '石景山区', '通州区',
  '浦东新区', '黄浦区', '静安区', '徐汇区', '长宁区', '杨浦区', '闵行区',
  '和平区', '河西区', '南开区', '河东区', '河北区', '红桥区',
  '渝中区', '江北区', '南岸区', '沙坪坝区', '九龙坡区', '两江新区',
  '鼓楼区', '玄武区', '秦淮区', '建邺区', '栖霞区',
  '西湖区', '上城区', '拱墅区', '滨江区', '萧山区', '余杭区',
  '锦江区', '武侯区', '青羊区', '金牛区', '成华区', '高新区',
  '江汉区', '武昌区', '洪山区', '汉阳区', '硚口区',
  '雁塔区', '碑林区', '莲湖区', '未央区', '新城区'
]

/**
 * 县名抽样池（真实名称，用于普通地级市**下辖县**）。
 *
 * 只收"当前仍是县"的行政区，不收县级市（四会、台山、开平、鹤山、恩平、
 * 乐昌、南雄、兴宁这些早就是县级市了），也不收已撤县设区的（梅县、曲江、
 * 清新已改区）——把县级市/区硬写成"县"，才是"地区乱乱"的根源之一。
 */
export const COUNTIES = [
  '博罗县', '惠东县', '龙门县',
  '海丰县', '陆河县',
  '紫金县', '龙川县', '连平县', '和平县', '东源县',
  '五华县', '丰顺县', '大埔县', '平远县', '蕉岭县',
  '饶平县', '惠来县', '揭西县',
  '仁化县', '始兴县', '翁源县', '新丰县', '乳源县',
  '阳山县', '连山县', '连南县', '佛冈县',
  '怀集县', '广宁县', '德庆县', '封开县',
  '新兴县', '郁南县', '遂溪县', '徐闻县', '阳西县'
]

/**
 * 区/县名全量抽样池（向后兼容）。新代码请用 URBAN_DISTRICTS / COUNTIES，
 * 按城市类型选池——见 pickDistrictFor。
 */
export const DISTRICTS = URBAN_DISTRICTS.concat(COUNTIES)

/** 街道名抽样池（真实名称，用于城区） */
export const STREETS = [
  '车陂街道', '五山街道', '石牌街道', '天河南街道', '猎德街道', '黄村街道', '沙河街道', '员村街道',
  '三元里街道', '沙头街道', '石岩街道', '大浪街道', '龙华街道', '布吉街道', '横岗街道', '平湖街道',
  '建国门街道', '朝阳门街道', '东直门街道', '西长安街街道', '金融街街道', '德胜街道',
  '陆家嘴街道', '南京东路街道', '静安寺街道', '徐家汇街道', '五角场街道',
  '滨江道街道', '解放桥街道', '中山路街道', '望江门街道', '湖滨街道'
]

/** 镇名抽样池（真实名称，用于普通地级市下辖镇） */
export const TOWNSHIPS = [
  '石湾镇', '罗阳镇', '龙溪镇', '园洲镇', '石排镇', '茶山镇', '寮步镇', '大朗镇', '黄江镇',
  '塘厦镇', '凤岗镇', '清溪镇', '长安镇', '虎门镇', '厚街镇', '沙田镇', '麻涌镇', '中堂镇',
  '桥头镇', '企石镇', '横沥镇', '东坑镇', '常平镇', '樟木头镇', '谢岗镇', '石碣镇',
  '三水镇', '芦苞镇', '大塘镇', '乐平镇', '白坭镇', '杨和镇', '明城镇', '更合镇'
]

/** 镇/街道名全量抽样池（向后兼容）。新代码请用 STREETS / TOWNSHIPS */
export const TOWNS = STREETS.concat(TOWNSHIPS)

/** 直辖市：没有"省"，也不存在下辖县/镇的层级问题 */
const MUNICIPALITIES = ['北京市', '上海市', '天津市', '重庆市']

function pick(list) {
  return list[Math.floor(Math.random() * list.length)]
}

/**
 * 这座城市是不是"城区型"城市（直辖市或一线城市）。
 * 城区型城市只配「区 + 街道」，不该出现「县 + 镇」。
 */
export function isMetropolitan(cityName) {
  if (MUNICIPALITIES.includes(cityName)) return true
  const city = CITIES.find((c) => c.name === cityName)
  return Boolean(city && city.tier === '一线')
}

/** 按城市类型挑一个区县名：城区型只给区，普通地级市给区或县 */
export function pickDistrictFor(cityName) {
  return pick(isMetropolitan(cityName) ? URBAN_DISTRICTS : DISTRICTS)
}

/** 按城市类型挑一个镇/街道名：城区型只给街道，普通地级市给街道或镇 */
export function pickTownFor(cityName) {
  return pick(isMetropolitan(cityName) ? STREETS : TOWNS)
}

/** 随机取一个城市，可按城市线级筛选；筛选为空时退回到全量 */
export function randomCity(tier) {
  const pool = tier ? CITIES.filter((c) => c.tier === tier) : CITIES
  const source = pool.length ? pool : CITIES
  return pick(source)
}

/**
 * 给玩家落一个真实起始地点（就地修改 player）。
 * 城市线级优先按出身的城市线级来，落点城市、区县、镇街随机。
 */
export function assignLocation(player, cityTier) {
  const city = randomCity(cityTier)
  player.province = city.province
  player.city = city.name
  player.cityTier = city.tier
  player.district = pickDistrictFor(city.name)
  player.town = pickTownFor(city.name)
}

/**
 * 按行政层级 + 流派拼单位名（真实地名）。
 * 乡镇级在区/县下、县级在区/县本级、市级在市本级、省级在省本级。
 * @returns {string} 单位名；取不到时退回到"某市人民政府"
 */
export function unitNameOf(player, unitType, level) {
  const tier = tierOf(unitType, level)
  const p = (player && player.province) || '某省'
  const c = (player && player.city) || '某市'
  const d = (player && player.district) || '某区'
  const t = (player && player.town) || '某街道'

  const MAP = {
    基层乡镇: {
      乡镇: `${c}${d}${t}办事处`,
      县: `${c}${d}人民政府`,
      市: `${c}人民政府`,
      省: `${p}人民政府`,
      国家: '国务院'
    },
    核心部门: {
      乡镇: `${c}${d}党政办公室`,
      县: `${c}${d}委办公室`,
      市: `${c}委办公室`,
      省: `${p}委办公厅`,
      国家: '中共中央办公厅'
    },
    常规局委: {
      乡镇: `${c}${d}财政所`,
      县: `${c}${d}财政局`,
      市: `${c}财政局`,
      省: `${p}财政厅`,
      国家: '国家发展和改革委员会'
    },
    边缘部门: {
      乡镇: `${c}${d}综合文化站`,
      县: `${c}${d}档案馆`,
      市: `${c}档案馆`,
      省: `${p}档案馆`,
      国家: '国家档案局'
    },

    // ── 政法序列（2.6.0 新增）──────────────────────────────
    // 公安在区里叫"公安分局"（市局派出机构）、在县里叫"公安局"；
    // 检察院/法院/司法/纪检在区县都叫"XX区/县XX院（局）"。
    公安系统: {
      乡镇: `${c}${d}${t}派出所`,
      县: countyKindOf(d) === '区' ? `${c}${d}公安分局` : `${c}${d}公安局`,
      市: `${c}公安局`,
      省: `${p}公安厅`,
      国家: '公安部'
    },
    检察系统: {
      乡镇: `${c}${d}人民检察院`,
      县: `${c}${d}人民检察院`,
      市: `${c}人民检察院`,
      省: `${p}人民检察院`,
      国家: '最高人民检察院'
    },
    法院系统: {
      乡镇: `${c}${d}人民法院`,
      县: `${c}${d}人民法院`,
      市: `${c}中级人民法院`,
      省: `${p}高级人民法院`,
      国家: '最高人民法院'
    },
    司法行政: {
      乡镇: `${c}${d}司法所`,
      县: `${c}${d}司法局`,
      市: `${c}司法局`,
      省: `${p}司法厅`,
      国家: '司法部'
    },
    纪检监察: {
      乡镇: `${c}${d}纪律检查委员会`,
      县: `${c}${d}纪委监委`,
      市: `${c}纪委监委`,
      省: `${p}纪委监委`,
      国家: '中央纪委国家监委'
    }
  }

  const row = MAP[unitType]
  return (row && row[tier]) || `${c}人民政府`
}

// 区县类型判断与「县 → 区」改写是纯字符串工具，抽到 constants/county.js
// 统一出口（positions.js 与 geo.js 都要用，放一起避免循环依赖）。
export { countyKindOf, countySuffixOf, localizeCounty } from './county'

/** 随机取一个城市，可按城市线级与省份同时筛选；筛选后为空退回到全量 */
export function randomCityIn(tier, province) {
  let pool = CITIES
  if (province) pool = pool.filter((c) => c.province === province)
  if (tier) pool = pool.filter((c) => c.tier === tier)
  return pick(pool.length ? pool : CITIES)
}

/**
 * 给玩家换一个落脚点（就地修改 player 的省/市/区县/镇/线级）。
 * 可选：限定城市线级、限定省份、指定城市或区县。缺省全部随机。
 *
 * 这是「晋升去向三选一」里每个去向落地的共用动作：先把人挪到新地方，
 * 再按新地点拼单位名与职务（见 game/placement.js）。
 */
export function relocatePlayer(player, opts = {}) {
  const city = opts.city || randomCityIn(opts.tier, opts.province)
  player.province = city.province
  player.city = city.name
  player.cityTier = city.tier
  player.district = opts.district || pickDistrictFor(city.name)
  player.town = opts.town || pickTownFor(city.name)
  return {
    province: player.province,
    city: player.city,
    district: player.district,
    town: player.town,
    cityTier: player.cityTier
  }
}
