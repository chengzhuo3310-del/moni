/**
 * 资产目录与财产申报参数。
 *
 * ── 为什么价目表只写一份 ──────────────────────────────────────
 * 「买豪车要 50 万」这件事只在 ASSET_CATALOG 里写一次，事件里**不写价格**，
 * 只写 `buyAsset: { kind: 'car', holder: 'self' }`。
 * 价格写两遍（事件里一个 costMoney、目录里一个 price）迟早会对不上：
 * 改了一处忘了另一处，表现是"选项上写着 50 万，实际扣了 60 万"，
 * 而两边都不报错。钱的事不能靠人记着同步。
 *
 * ── 代持的代价与收益 ─────────────────────────────────────────
 * 亲友代持要额外付 PROXY_FEE_RATE 的手续费（走账、过人情都得花钱），
 * 换来的是**两头都降低被发现的机会**：季度风险减半、申报时不进总数。
 * 但只是降低，不是消除——每次财产申报仍有一定概率被翻出来（见 PROXY_EXPOSE_ODDS）。
 *
 * 为什么代持不能做成"完全查不到"：那样它就是一个纯优解，
 * 玩家永远该代持，「本人名下」这个选项从此没人点，等于白设计了两个选项。
 */

// 贪腐金额上限与申报红线都按职级档位取，档位定义在 constants/promotion.js。
// 依赖方向是 assets → promotion，**不能反过来**：promotion 是职级阶梯的
// 权威定义，让它依赖资产目录会绕成环。
import { bandOfLevel } from '@/constants/promotion'

/** 资产类别。与后端 models.py 的 ASSET_KINDS 逐字对齐 */
export const ASSET_KINDS = ['house', 'car']

/** 代持方式。与后端 models.py 的 ASSET_HOLDERS 逐字对齐 */
export const ASSET_HOLDERS = ['self', 'proxy']

/**
 * 资产目录。
 *
 * quarterlyRisk 是**每季末**往廉政风险上加的点数——买了不是一次性代价，
 * 而是从此每季度都要还的一笔账。豪车比豪宅低，是因为车可以停在车库里，
 * 房子杵在那儿，谁路过都看得见。
 */
/**
 * 资产目录（2.2.0 起按**档次**展开）。
 *
 * key 是具体的资产 id（car_compact、house_river 这类），每个条目带
 * `kind`（car / house，仍是两种大类）、`tier`（档次）、价格、季度风险与
 * 即时加成。商城「安居与座驾」从这里取货，事件里的 `buyAsset: { kind: 'car' }`
 * 仍按旧大类写法工作——assetSpecOf 会把 'car' / 'house' 映射到默认档
 * （见 DEFAULT_ASSET_BY_KIND），所以旧事件的价码一分没动。
 *
 * 多档次的用途：一个干部买「低调代步车」还是「豪华商务车」，
 * 在财产申报里是两笔完全不同的账——这才是商城与风控真正联动的地方。
 */
export const ASSET_CATALOG = {
  // ── 座驾出行（7 档，全城统一指导价）──
  car_compact: {
    kind: 'car', tier: 'compact', icon: '🚗',
    name: '比亚迪秦 PLUS',
    price: 100000, quarterlyRisk: 1,
    effects: { energy: 4, popularity: 2 }
  },
  car_mid: {
    kind: 'car', tier: 'mid', icon: '🚙',
    name: '丰田凯美瑞',
    price: 200000, quarterlyRisk: 1,
    effects: { energy: 6, popularity: 3 }
  },
  car_business: {
    kind: 'car', tier: 'business', icon: '🚘',
    name: '大众迈腾',
    price: 240000, quarterlyRisk: 2,
    effects: { authority: 8, energy: 6 }
  },
  car_flagship: {
    kind: 'car', tier: 'flagship', icon: '🚙',
    name: '红旗 H9',
    price: 320000, quarterlyRisk: 2,
    effects: { authority: 12, mgmt: 4 }
  },
  car_audi: {
    kind: 'car', tier: 'audi', icon: '🚗',
    name: '黑色奥迪 A6L',
    price: 450000, quarterlyRisk: 3,
    effects: { authority: 15, mgmt: 8 }
  },
  car_luxury: {
    kind: 'car', tier: 'luxury', icon: '🏎️',
    name: '奔驰 E300L',
    price: 520000, quarterlyRisk: 4,
    effects: { authority: 18, energy: 5 }
  },
  car_super: {
    kind: 'car', tier: 'super', icon: '🏎️',
    name: '奥迪 A8L',
    price: 1100000, quarterlyRisk: 7,
    effects: { authority: 25, mgmt: 10 }
  },

  // ── 安居置业（6 档，基准价随城市线级浮动）──
  house_dorm: {
    kind: 'house', tier: 'dorm', icon: '🏠',
    name: '单位周转房',
    price: 30000, quarterlyRisk: 0,
    effects: { energy: 2 }
  },
  house_old: {
    kind: 'house', tier: 'old', icon: '🏠',
    name: '建设路老城步梯两居',
    price: 450000, quarterlyRisk: 1,
    effects: { health: 6, energy: 4 }
  },
  house_fine: {
    kind: 'house', tier: 'fine', icon: '🏡',
    name: '滨河雅苑精装电梯三居',
    price: 1200000, quarterlyRisk: 2,
    effects: { health: 10, energy: 6 }
  },
  house_school: {
    kind: 'house', tier: 'school', icon: '🏡',
    name: '文庙巷顶级学区房',
    price: 2400000, quarterlyRisk: 4,
    effects: { health: 14, popularity: 8 }
  },
  house_river: {
    kind: 'house', tier: 'river', icon: '🏙️',
    name: '御景湾一线江景大平层',
    price: 4500000, quarterlyRisk: 6,
    effects: { health: 18, mgmt: 6 }
  },
  house_villa: {
    kind: 'house', tier: 'villa', icon: '🏰',
    name: '翠屏山半山独栋别墅',
    price: 9000000, quarterlyRisk: 9,
    effects: { health: 24, mgmt: 12 }
  }
}

/** 旧大类 kind（car / house）→ 默认档 id。事件里只写 kind 时走这里 */
export const DEFAULT_ASSET_BY_KIND = {
  car: 'car_audi',
  house: 'house_fine'
}

/** 亲友代持的额外操作费比例：借别人的名字走账，中间是要花钱的 */
export const PROXY_FEE_RATE = 0.2

/** 代持资产的季度风险折扣。减半——藏起来了，但没藏干净 */
export const PROXY_RISK_RATE = 0.5

/**
 * 财产申报。
 *
 * 每 DECLARE_EVERY_QUARTERS 个季度申报一次，算的是
 *   `家产 + 名下资产 -（累计合法收入 - 退赃起算点）`
 * 也就是"你手上这些家当，有多少是你的工资解释不了的"。
 *
 * ── 三档，不是一条线 ────────────────────────────────────────
 * 原先只有一条红线（差额 >= 50 万就移交纪委），后果是差额 51 万和 5000 万
 * 走的是同一个流程、看到的是同一份决定书。贪腐流因此只有两种状态：
 * "还没越线"和"已经死了"——中间没有可玩的空间，玩家攒到 50 万就只剩等死。
 *
 * 现在按差额分三档，**每一档的刻度随职级走**（见下方 DECLARE_CASE_BY_BAND）：
 *   约谈线以下        正常申报
 *   约谈线 ~ 立案线   约谈        没立案，但被叫去谈话，风险记账
 *   立案线 ~ 三倍线   立案
 *   >= 三倍线         直接立案
 *
 * 档位只管**措辞和提示**，不再决定给不给退赃——退赃改成"一辈子一次"，
 * 由 gameStatus.usedRetreat 说了算（见 gameConfig 里那段说明）。
 * 早先这里的规则是"300 万以上退赃无门"，但实测那条规则会把贪腐流逼成
 * "要么一次都不退、要么一次就死"的双稳态，落马率只能在 0% 和 65% 之间跳。
 *
 * ── 为什么是"按职级分档"而不是一条线 ────────────────────────
 * 门槛和金额是配套的两个刻度：单笔贪腐金额已经按职级封顶
 * （见 ILLICIT_CAP_BY_BAND，科级一笔最多 10 万），立案线却卡在同一个数上，
 * 结果就是科级干部收 10 万块购物卡被立案、厅级干部收 300 万反倒"没到线"。
 * 金额和门槛必须一起走。
 */
export const DECLARE_EVERY_QUARTERS = 5

/**
 * 立案红线**按职级分档**。基层查得严但金额小，高层金额大但门槛也高——
 * 这条曲线同时是现实感和节奏器：
 *
 *   乡科级     150 万
 *   县处级     300 万
 *   厅局级+    900 万
 *
 * 为什么必须分档：原先一条 100 万的线卡在所有职级上，配上"事件金额也分职级"
 * 之后就会出现两种荒唐——科级干部收了 10 万块购物卡就被立案，
 * 而厅级干部收 300 万反倒"还没到线"。金额和门槛得一起走。
 *
 * 约谈线取立案线的一半、直接立案线取三倍，与旧的 50/100/300 比例一致：
 * 档位之间的相对轻重不变，变的只是刻度。
 *
 * ── 2.2.0：整条线 ×3 ──────────────────────────────────────
 * 原先 50/100/300 配上抽取出口的单笔封顶，见钱就收的玩法落马率 96.7%、
 * 平均 33.4 岁——伸手即死，玩家没有"越陷越深"的体感就被带走了。
 * 这条线是整个曲线上**唯一能把落马年龄往后推**的旋钮：
 * 降线（减半）和扩事件池（加钱）都是踩油门，落马率反而升到 100%、年龄掉到 30。
 * 抬线让赃款得攒更久才够着，年龄才推得上去。
 * 与单笔封顶 ×0.4 配套，见钱就收落到 45% / 51.9 岁。
 */
export const DECLARE_CASE_BY_BAND = {
  科级: 1500000,
  处级: 3000000,
  厅级: 9000000,
  省部级: 9000000
}

/**
 * 单笔贪腐金额的职级上限（元）。
 *
 *   乡科级       4 万    购物卡、烟酒、小额红包
 *   县处级      20 万    工程回扣、项目审批
 *   厅局级+    120 万    土地、股权、大额利益输送
 *
 * ── 2.2.0：整体 ×0.4 ──────────────────────────────────────
 * 光抬立案线不够。封顶不收紧的话，厅级一条 300 万的干股就能顶掉半条线，
 * 攒够还是太快，落马年龄推不过 45。封顶和立案线是**一对**：
 * 线决定"攒多久算够"，封顶决定"一笔能攒多少"，
 * 只动一个，另一个会把效果吃掉。
 *
 * ── 它解决的问题：节奏 ──────────────────────────────────────
 * 事件池里的收钱事件带着 bands，但抽取链有"放宽职级"的兜底档，
 * 一个乡科级副职是**抽得到**厅级那几条的（800 万的地块干股）。
 * 抽到就是一步登天：一局里落马年龄被这种偶发的大额事件拽到 28~31 岁，
 * 曲线整个塌掉——玩家还没建立起"越陷越深"的体感，人已经进去了。
 *
 * 所以上限在**抽取出口**兜一道，而不是去改事件本身：
 * 事件里的金额是"这件事本身值多少"，与玩家级别无关；
 * 该不该让他碰见、碰见多少，是抽取层的事。
 * 写进事件里等于把两件事焊死，改一处就得改十条。
 */
export const ILLICIT_CAP_BY_BAND = {
  科级: 40000,
  处级: 200000,
  厅级: 1200000,
  省部级: 1200000
}

/**
 * 「养鱼期」：头 N 个季度只谈不查。
 *
 * 前两年（8 个季度）就算差额已经过线，也只走约谈、记一笔风险，
 * 不立案、不下决定书。玩家在这一段里收到的信号是"组织上还没收网"——
 * 这正是设计想要的错觉：**他以为自己还有时间**。
 *
 * 没有这一段的话，第一笔大钱和第一份决定书之间只隔一个申报周期，
 * 玩家的体感是"伸手即死"，那不是反腐，那是踩地雷。
 */
export const DECLARE_GRACE_QUARTERS = 8

/**
 * 差额公式：**家产减去"退赃之后"的合法收入**。
 *
 *     gap = max(0, 家产 + 名下资产 − (累计合法收入 − 退赃起算点))
 *
 * ── 三种写法，前两种各自错在哪（都有实测） ────────────────────
 * 1）减**一辈子**的累计合法收入。
 *    分母随工龄一路涨，干到四十来岁它就大到能盖住任何一笔钱。
 *    实测退过赃的人，往后二十年里 554 次申报中只有 12 次算出 100 万以上
 *    （2%）——差额被永久压死，第二次立案几乎不可能发生，
 *    而"退赃限一次"整个设计就是建立在"第二次立案会发生"之上的。
 *
 * 2）减**最近几个季度**的收入。
 *    被减数是**存量**（一辈子攒的家产），减数是**流量**（一年的工资），
 *    两者不是一个量纲。后果是**清廉流被打死**：一个只靠工资、
 *    一分钱外快都不拿的干部，攒到四十来岁手上总有一两百万，
 *    而近一年工资只有十几万，差额赫然过线。实测同一颗种子下，
 *    "严格不贪"画像落马率 65%，被抓走的是全场最干净的那个人。
 *
 * 3）只减**退赃之后**的收入（现在的写法）。
 *    清官的家产 = 合法收入 − 支出 + 利息，差额是**负的**，夹在 0 之后恒为 0，
 *    一辈子攒多少都不会越线；贪官的家产多出一块赃款，差额就是那块赃款，
 *    而且**逐期累积**——细水长流也终会越线，这正是"越陷越深"该有的样子。
 *    退赃时把起算点推高到当时的收入，交出去的旧账不再替他打掩护，
 *    新收的每一笔都重新算数。
 *
 * 起算点由 gameStatus 的 retreatLegalBaseline 记着，只在退赃时改写一次。
 */
/**
 * 约谈带来的廉政风险增量。
 *
 * 约谈本身不立案、不终结本局，所以它必须留下**记账**，
 * 否则"差额 60 万被叫去谈话"就成了一句没有后果的台词——
 * 玩家会很快学会"50 万到 100 万这一段随便贪"。
 * 这 8 点是留给下一次提任裁定的：风险一旦顶过 riskMax，提任就暂缓了。
 */
export const DECLARE_TALK_RISK = 8

/**
 * 代持资产每次申报被翻出来的概率。
 *
 * 这是代持唯一的漏洞：本人名下当场就进总数，代持则每年赌一次。
 * 0.25 的意思是平均四年左右还是会被翻出来——够玩家赌几轮，
 * 但不足以让"代持"变成一劳永逸的答案。
 */
export const PROXY_EXPOSE_ODDS = 0.25

/**
 * 取资产目录项。参数可以是具体资产 id（car_compact）或旧大类 kind（car）。
 * 大类 kind 会映射到默认档（见 DEFAULT_ASSET_BY_KIND）；取不到返回 null，绝不猜。
 */
export function assetSpecOf(kind) {
  if (ASSET_CATALOG[kind]) return ASSET_CATALOG[kind]
  const defaultId = DEFAULT_ASSET_BY_KIND[kind]
  return defaultId ? ASSET_CATALOG[defaultId] : null
}

/** 某大类（car / house）下的全部资产 id，按价格从低到高排。商城货架用 */
export function assetIdsOfKind(kind) {
  return Object.keys(ASSET_CATALOG)
    .filter((id) => ASSET_CATALOG[id].kind === kind)
    .sort((a, b) => ASSET_CATALOG[a].price - ASSET_CATALOG[b].price)
}

/** 全部资产 id，供商城「安居与座驾」整架遍历 */
export function allAssetIds() {
  return Object.keys(ASSET_CATALOG)
}

/**
 * 算一件资产的**实际购入价**（含代持手续费）。
 * 事件里不写价格，界面与引擎都来问这里——这是唯一的价目来源。
 */
export function assetCostOf(kind, holder) {
  const spec = assetSpecOf(kind)
  if (!spec) return 0
  const fee = holder === 'proxy' ? 1 + PROXY_FEE_RATE : 1
  return Math.round(spec.price * fee)
}

/**
 * 城市线级的资产价格系数。房车跟着城市走：一线贵、四线便宜。
 * 这是**商城明码标价**的浮动，事件里的机会价（assetCostOf）不浮动——
 * 门缝里递来的那张单子，价格是别人定的，不是按你住哪定的。
 */
export const ASSET_CITY_PRICE_FACTOR = {
  一线: 2.2,
  二线: 1.4,
  三线: 1.0,
  四线: 0.75
}

/** 算一件资产在**某城市线级**的商城实付价（含代持手续费 + 城市浮动） */
export function assetCostInCity(kind, holder, cityTier) {
  const spec = assetSpecOf(kind)
  if (!spec) return 0
  const fee = holder === 'proxy' ? 1 + PROXY_FEE_RATE : 1
  const city = ASSET_CITY_PRICE_FACTOR[cityTier] || 1
  return Math.round(spec.price * fee * city)
}

/** 算一件资产的季度廉政风险（代持减半，向上取整，至少 1 点） */
export function assetQuarterlyRiskOf(kind, holder) {
  const spec = assetSpecOf(kind)
  if (!spec) return 0
  if (holder !== 'proxy') return spec.quarterlyRisk
  return Math.max(1, Math.round(spec.quarterlyRisk * PROXY_RISK_RATE))
}

/**
 * 职级 → 本档的三条红线（元）。
 *
 * 约谈线 = 立案线的一半，直接立案线 = 立案线的三倍，全部由立案线派生。
 * **不单独给约谈线和三倍线各写一张表**：三张表迟早对不上，
 * 而"约谈线比立案线还高"这种错不会报错，只会让玩家收到一份自相矛盾的通报。
 *
 * 认不出的职级按最低档兜底：宁可对一个厅级干部用科级的线（他被查得更早），
 * 也不要因为查不到档位就让他永远安全。
 */
export function declareLinesOf(level) {
  const band = bandOfLevel(level)
  const caseLine = DECLARE_CASE_BY_BAND[band] || DECLARE_CASE_BY_BAND.科级
  return { talk: Math.round(caseLine / 2), caseLine, severe: caseLine * 3 }
}

/** 职级 → 单笔贪腐金额上限（元）。认不出的职级按最低档兜底，理由同上 */
export function illicitCapOf(level) {
  const band = bandOfLevel(level)
  return ILLICIT_CAP_BY_BAND[band] || ILLICIT_CAP_BY_BAND.科级
}

/**
 * 「走动关系」的家底门槛（元），按职级档递增。
 *
 * ── 为什么按职级走 ──────────────────────────────────────────
 * 原先一律 ¥10,000。科级干部一季净攒五千出头，一万块要攒两个月，
 * 是笔要掂量的钱；可到了厅级，一季净攒上万，十万也只是几季的积蓄，
 * 走动等于免费——**同一道选择题在不同职级上难度天差地别**，
 * 而"这季度走不走动"本该是一道贯穿全局的取舍。
 *
 * 倍率 1 : 2 : 5 : 10 比薪水的涨幅陡：位置越高，走动越贵。
 * 这不是为了平衡才编的曲线，是实情——越往上，人情往来的规格本身就不一样。
 *
 * ── 它为什么放在 assets.js 而不是 money.js ──────────────────
 * 家产的其余数值（安家费、薪级表、危机公关）都在 money.js，只有这一张在
 * 这里，因为它得**按职级分档**，而 bandOfLevel 就在本文件上面一行。
 * 让 money.js 去引 promotion.js 会把依赖方向倒过来。
 * 价钱只写这一处，BALANCE 里不再留 moneyCost 那个副本。
 */
export const BALANCE_COST_BY_BAND = {
  科级: 10000,
  处级: 20000,
  厅级: 50000,
  省部级: 100000
}

/**
 * 有案底的加价倍率。
 *
 * 「有案底」= 这辈子收过任何一笔钱（player.hasIllicitRecord）。
 *
 * ── 这道倍率要绞的是什么 ────────────────────────────────────
 * 收过钱的人，走动关系要花五倍。他的钱来得容易，可是**能走的场合变少了**——
 * 一个身上带着事的人去走动，本身就是多一分风险，价钱自然更贵。
 *
 * 数值上它**不是**绞索，这一点已经实测过了。原本的设想是：
 * 贪腐流的现金看着多，但退赃一次就被清空（见 engine 的 surrender：
 * 现金扣光、资产全部上交），重新起手的本钱得从干净的账上出，
 * 而干净的账只有一个来源——工资，于是他维持同样强度的走动就得再伸手，
 * 再伸手差额又涨。
 *
 * 这条推理不成立。×2 时 20 局，贪腐流想走 296 次、只被家产拦下 1 次；
 * 加到 ×5 之后，60 局里落马率反而从 20% **降到 11.7%**——涨价把贪腐流
 * 变更安全了。原因不在倍率本身，而在当时走动关系只扣钱、不记累计支出，
 * 价钱越贵、从申报差额上洗掉的越多（见 engine.js 的 spendMoney()）。
 * 漏洞修掉之后，这个倍率才回到它本来的位置：一道价钱，决定"走一趟肉不肉疼"，
 * 不决定结局。**别再指望调它来治贪腐流。**
 *
 * 清廉流永远碰不到这个倍率：一分钱没收过，hasIllicitRecord 恒为 false。
 */
export const ILLICIT_RECORD_MARKUP = 5

/**
 * 有案底的人**每季度**最多走动几次。清廉流不受此限。
 *
 * ── 为什么必须有这道次数上限 ────────────────────────────────
 * 只涨价是拦不住的，这是实测结论而不是推断：把倍率从 1 提到 2，
 * 20 局模拟里贪腐流想走 296 次、**只被家产拦下 1 次**，落马率反而从
 * 45% 掉到 20%——他每个季度都把风险走下来，立案线永远够不着。
 * 一个手上不缺钱的人，"贵"对他不是约束。
 *
 * 能拦住"每季度刷满"的只有次数。1 次的意思是：走动重新变回
 * **一道每季度只能做一次的选择题**，而不是一台可以连续按的降压机。
 *
 * ── 为什么只卡有案底的人 ────────────────────────────────────
 * 这不是数值上的偏心，是处境不同：一个被组织上盯过的人，
 * 频繁出入饭局、托人说情，本身就是新的问题；
 * 而一身干净的人正常的人情往来，没有理由限制他。
 *
 * 与上面的倍率同理，**它也不是那个能治贪腐流的阀门**：60 局实测里
 * 它拦下 517 次尝试，落马率照样停在 10%。真正拦下贪腐流的是记账，不是限次。
 */
export const BALANCE_RECORD_QUARTERLY_CAP = 1

/**
 * 有案底的加价，最高只能吃掉当前家产的这一成数。
 *
 * ── 这道封顶解决的是什么 ────────────────────────────────────
 * 加价是**按职级**算的（厅级基准 5 万 × 5 = 25 万），可退赃之后的人
 * 是**按家产**活的：现金先抵赃款、扣不动的拿资产顶上，出来时账上
 * 常常只剩十来万。于是出现一个死结——他需要走动来压风险，
 * 走动却按"厅级"收他 25 万，而他有 12 万。这道选择题在他这儿根本不是选择题，
 * 是一堵墙：**越是刚认过罪、越需要重新做人的人，越走不动**。
 * 而"退赃之后还能重新做人"正是退赃那条路存在的全部意义。
 *
 * 封顶取 0.5 而不是 0.8 或 0.9：走动是要花钱的事，但上限得让他走完之后
 * 还剩得下家底，否则每走一次就等于把裤兜掏空，下一季度的固定支出
 * （见 gameConfig 的 QUARTERLY_EXPENSE）立刻接不上。
 * 走一趟掏一半，是"肉疼但走得动"。
 *
 * ── 它不改变加价的性质 ──────────────────────────────────────
 * 家底厚的时候这道封顶根本不生效（厅级得有 50 万才够得着 25 万的上限），
 * 所以"有案底走动贵五倍"这件事在绝大多数时候原样成立。
 * 它只在那条死结上兜个底。
 */
export const RECORD_MARKUP_WALLET_CAP = 0.5

/**
 * 走动关系的实际价钱（元）。
 *
 * 认不出的职级按最低档兜底，与 declareLinesOf / illicitCapOf 同一套规矩：
 * 宁可让一个厅级干部按科级的价走动（他走得起），
 * 也不要因为查不到档位就让走动变成免费。
 *
 * @param {string} level       玩家当前职级
 * @param {boolean} hasRecord  是否有案底（收过钱）
 * @param {number} [money]     当前家产，用来给案底加价封顶。
 *                             不传（或传不出有限数）时按不封顶算——
 *                             界面与引擎**必须**传，不传的那一方会算出一个
 *                             比另一方贵的价签，而钱的事不会报错。
 * @returns {number} 元
 */
export function balanceMoneyCostOf(level, hasRecord, money) {
  const band = bandOfLevel(level)
  const base = BALANCE_COST_BY_BAND[band] || BALANCE_COST_BY_BAND.科级
  if (!hasRecord) return base

  const full = base * ILLICIT_RECORD_MARKUP
  const wallet = Number(money)
  if (!Number.isFinite(wallet) || wallet <= 0) return full

  // 封顶算的是**整笔价钱**，不是"加价那一段"。
  // 两种读法都说得通，取这一种是因为它才真的解得开上面那个死结：
  // 只压加价那一段的话，厅级、家产 12 万的人仍要掏 11 万，
  // 走完只剩 1 万——名义上"走得动"，实际上走一步就破产。
  const capped = Math.floor(wallet * RECORD_MARKUP_WALLET_CAP)
  // 不低于基准价：封顶是兜底，不是给有案底的人打折
  return Math.max(base, Math.min(full, capped))
}

/** 资产在界面上的名字：带图标，如「🚙 商务轿车」 */
export function assetLabelOf(asset) {
  // 优先用具体档次 id 取图标（car_compact 是 🚗，car_business 是 🚙）；
  // 老存档的资产只有 kind（car / house），退回到大类默认档。
  const spec = assetSpecOf((asset && asset.assetId) || (asset && asset.kind))
  const icon = (spec && spec.icon) || '📦'
  const name = (asset && asset.name) || (spec && spec.name) || '资产'
  return `${icon} ${name}`
}
