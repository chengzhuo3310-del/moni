/**
 * 区县类型的纯字符串工具。
 *
 * 单独成文件是为了**躲开循环依赖**：geo.js 依赖 positions.js（取 tierOf），
 * 而 positions.js 又需要"职务里的「县」按区县类型改写"这个能力——
 * 让 positions.js 反过来 import geo.js 就会绕成环。三个纯函数放这里，
 * 谁都不依赖谁。
 *
 * 语境：处级（县层级）的职务、单位，前缀跟着区县类型走——
 *   落在「天河区」→ 区委办公室、副区长、区财政局
 *   落在「博罗县」→ 县委办公室、副县长、县财政局
 * 职务池只写县域默认表述，读的时候按区县类型把那个「县」字改掉。
 */

/** 区县名 → 类型。'区' / '县' / '市'，认不出按 '县' 兜底（县域是基层最常见的表述） */
export function countyKindOf(name) {
  const s = String(name || '')
  if (/区$/.test(s)) return '区'
  if (/市$/.test(s)) return '市'
  return '县'
}

/**
 * 区县名 → 拼职务/单位要用的那一个字（区 / 县）。
 * 县级市一律按 '县' 处理：它本就是处级行政区，且地名池里已不收县级市。
 */
export function countySuffixOf(name) {
  return countyKindOf(name) === '区' ? '区' : '县'
}

/**
 * 把职务里的「县」按区县类型改写。
 *
 * 处级职务池写的是县域默认表述（副县长、县委书记、县财政局），
 * 但玩家落在「区」里时该叫「副区长、区委书记、区财政局」。
 * 只把「县」换成「区」这一条规则就够了——处级职务里唯一随区县类型变的
 * 就是这个字。传进来的 district 不是「区」时原样返回。
 *
 * 必须在**处级（县层级）**职务上调用。乡镇级职务（副镇长）不含「县」，
 * 市/省/国家级职务也不含，误调无害但没必要。
 */
export function localizeCounty(text, district) {
  const s = String(text || '')
  if (!s || countyKindOf(district) !== '区') return s
  return s.replace(/县/g, '区')
}
