/**
 * 生活与社交商城目录（2.2.0 新增）。
 *
 * 三个货架：
 *   · 安居与座驾（assets）——复用 constants/assets.js 的资产目录，
 *     买车买房是**看得见的财产**，直接进财产申报，与风控深度绑定。
 *   · 健康与进修（health）——合法自我投资，花干净钱，有冷却期防刷满。
 *   · 人情与门路（social）——灰色社交，见效快，但每次都在廉政风险上记账。
 *
 * asset 类商品不在这里重复定义价格——价格与季度风险都在 assets.js 的
 * ASSET_CATALOG 里（商城按城市线级浮动，见 assetCostInCity）。这里只放
 * health / social 两类一次性消费品。
 */

/**
 * 货架顺序与展示信息。asset 货架的品目由 assets.js 的 allAssetIds() 现取。
 */
export const SHOP_SHELVES = [
  {
    id: 'assets',
    title: '安居与座驾',
    hint: '房子车子看得见，买得起还得说得清来路'
  },
  {
    id: 'health',
    title: '健康与进修',
    hint: '花干净钱投资自己，本事和身子都是真的'
  },
  {
    id: 'social',
    title: '人情与门路',
    hint: '见效快，但每一笔都记在廉政风险那本账上'
  }
]

/**
 * 一次性消费品目录（health / social）。
 *
 *   price      基础价（元），不随城市线级浮动
 *   cooldown   冷却几个季度（绝对季度号记在 player.shopCooldowns）
 *   costAp     需要消耗的行动力（进修这类"花时间"的消费）
 *   needIllicit 需要有非法所得（灰色资金）才解锁
 *   effects    对八项资源的即时效果
 *   setFlag    购买后置位的分支标记（给后续事件/走向留口子）
 */
export const SHOP_ITEMS = [
  // ── 健康与进修 ──
  {
    id: 'checkup',
    shelf: 'health',
    icon: '🩺',
    name: '高端体检疗养',
    price: 80000,
    cooldown: 16,          // 约一个任期（16 季 = 4 年），每任期只该做一次
    perTenure: true,
    desc: '住进疗养院休整一段，把透支的身子补回来。每任期仅此一次。',
    effects: { health: 30, energy: 30 }
  },
  {
    id: 'training',
    shelf: 'health',
    icon: '📚',
    name: '党校在职研修',
    price: 60000,
    cooldown: 16,
    perTenure: true,
    costAp: 1,
    desc: '脱产进修一期，学点真本事，履历上也好看。每任期仅此一次。',
    effects: { ability: 8, kpi: 5 }
  },
  {
    id: 'donation',
    shelf: 'health',
    icon: '🎗️',
    name: '匿名公益捐赠',
    price: 50000,
    cooldown: 4,
    desc: '把钱捐出去，图一个口碑，也图一份心安。',
    effects: { risk: -6, popularity: 4 }
  },

  // ── 人情与门路 ──
  {
    id: 'gift_tea',
    shelf: 'social',
    icon: '🍵',
    name: '烟酒茶礼盒',
    price: 30000,
    cooldown: 2,
    desc: '打点走动少不了的东西。礼到，话才递得进去。',
    effects: { mgmt: 6, popularity: 4, risk: 3 }
  },
  {
    id: 'gift_local',
    shelf: 'social',
    icon: '🎁',
    name: '乡土特产礼包',
    price: 20000,
    cooldown: 2,
    desc: '不算贵重，胜在有心。走动起来不扎眼。',
    effects: { popularity: 8, mgmt: 2, risk: 2 }
  },
  {
    id: 'antique',
    shelf: 'social',
    icon: '🖼️',
    name: '字画玉石流转',
    price: 120000,
    cooldown: 6,
    needIllicit: true,
    desc: '有些钱见不得光，换个说法才走得通。暂时压一压账面，但终究要还。',
    effects: { risk: -10, mgmt: 5 },
    setFlag: { covert: true }
  },

  // ── 高阶消耗出口（2.8.0）：给厅级以上的钱找一个花出去的正经去处 ──
  {
    id: 'kids_education',
    shelf: 'health',
    icon: '🎓',
    name: '子女海外教育基金',
    price: 150000,
    cooldown: 16,
    perTenure: true,
    desc: '给子女铺一条出国深造的路。圈子里的体面，有时就是下一代站的位置。',
    effects: { popularity: 6, authority: 3, mgmt: 2 }
  },
  {
    id: 'family_trust',
    shelf: 'social',
    icon: '🏦',
    name: '家族信托',
    price: 250000,
    cooldown: 24,
    needIllicit: true,
    desc: '把一些说不清来路的沉淀进信托，账面能好看一阵。钱还在，只是换了副面孔。',
    effects: { risk: -8 },
    setFlag: { trust: true }
  }
]

/** 按货架 id 取消费品清单（不含 asset 类） */
export function shopItemsOf(shelfId) {
  return SHOP_ITEMS.filter((item) => item.shelf === shelfId)
}

/** 按 id 取一件消费品，取不到返回 null */
export function shopItemOf(id) {
  return SHOP_ITEMS.find((item) => item.id === id) || null
}
