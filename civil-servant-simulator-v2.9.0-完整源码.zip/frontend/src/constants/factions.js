/**
 * 派系与上下级人事（2.4.0 新增）。
 *
 * ── 为什么要有派系 ──────────────────────────────────────────
 * 干部不是孤立地在官场里走。现实里每一个位置背后都有人、有山头：
 * 谁是本地提拔的、谁是上面空降的、谁是谁的人。派系把这层关系落到数值上——
 * 站对了队，晋升调动有人替你说话；靠山倒了，你也跟着被边缘化。
 *
 * 四大派系（player.faction）：
 *   · 本土实干派   基层磨上来的，靠政绩说话，晋升稳但天花板来得晚
 *   · 空降学院派   高学历引进/上级下派，起步有人提携，但根基浅、易被本土排挤
 *   · 元老稳健派   资历老、求稳，关键时刻能保你，但不会为你的激进背书
 *   · 无派系/孤臣  不站队，少是非也少靠山，全凭自己
 *
 * ── 上级关系（player.mentors）──
 * 维护 1~2 位直接上级，各自带派系、好感度（0~100）与隐藏廉政度。
 * 好感度高了能在危机公关里"保一把"，但若上级本人贪腐被查，
 * 你绑得越深，越容易被"拔出萝卜带出泥"（见 game/personnel.js 的连带审查）。
 *
 * ── 下属（player.subordinates）──
 * 副科级及以上解锁，最多 4 名核心下属。下属有 能力/忠诚/派系/野心贪腐 四个属性，
 * 培养与任命的走向见 game/personnel.js：任人唯贤、任人唯亲、外放布子。
 */

import { localizeCounty, countyKindOf } from './county'

/** 派系中文名。player.faction 只存 key，展示用 player.factionLabel */
export const FACTION_NAMES = {
  local: '本土实干派',
  parachute: '空降学院派',
  veteran: '元老稳健派',
  independent: '无派系'
}

/** 派系说明，界面与事件文案共用 */
export const FACTION_DESC = {
  local: '基层磨上来的，政绩说话。晋升稳，但越往上越要熬资历。',
  parachute: '高学历引进或上级下派，起步有人提携，根基浅、易被本土排挤。',
  veteran: '资历老、求稳。关键时刻能保你一把，但不会为激进背书。',
  independent: '不站队。少是非、也少靠山，全凭自己。'
}

/** 直接上级的姓池。称谓按玩家职级动态配（见 MENTOR_TITLE_BY_LEVEL） */
export const SURNAME_POOL = [
  '周', '李', '王', '陈', '赵', '钱', '孙', '吴', '郑', '冯', '蒋', '沈', '韩', '杨', '朱'
]

/**
 * 职级 → 直接上级的合理称谓池（上级严格比本人高一级）。
 *
 * 一个乡镇科员的上司是副镇长/镇党委副书记，一个副处级（副县长）的上司
 * 是县长/县委书记——不该是"部长""厅长"，基层干部摸不着部级领导的门。
 * 称谓跟着玩家职级走，才不会出现"科员给王部长汇报"这种越级错位。
 *
 * 落在「区」里的玩家，处级称谓里的「县」会按区县类型改写成「区」
 * （见 makeMentor / refreshMentor 的 localizeCounty）——
 * 区委副书记的上级是区委书记，而不是隔着行政类型的"县长"。
 */
const MENTOR_TITLE_BY_LEVEL = {
  科员: ['副镇长', '镇党委副书记', '组织委员'],   // 上级：副科级（乡镇）
  副科级: ['镇长', '镇党委书记'],                  // 上级：正科级（乡镇）
  正科级: ['副县长', '县委副书记', '县纪委书记'], // 上级：副处级（县/区）
  副处级: ['县长', '县委书记'],                    // 上级：正处级（县/区）
  正处级: ['副市长', '市委常委'],                  // 上级：副厅局级（市）
  副厅局级: ['市长', '市委书记'],                  // 上级：正厅局级（市）
  正厅局级: ['副省长', '省委常委'],                // 上级：副省部级（省）
  副省部级: ['省长', '省委书记'],                  // 上级：正省部级（省）
  正省部级: ['中央领导'],                          // 上级：副国级
  副国级: ['中央领导']                             // 顶点，无实际上级
}

/**
 * 政法序列的上级称谓表（2.6.0 新增）。与 MENTOR_TITLE_BY_LEVEL 同构：
 * 上级严格比本人高一级，且必须在**同一条政法线**里——
 * 民警的上级是派出所副所长，检察员的上级是副检察长，不能串到隔壁单位。
 * 处级及以下县职位只写县域默认表述，「县→区」由 makeMentor/refreshMentor
 * 里的 localizeCounty 改写。
 */
const MENTOR_TITLE_BY_UNIT = {
  公安系统: {
    科员: ['派出所副所长', '刑侦中队中队长'],
    副科级: ['派出所所长', '刑侦大队大队长'],
    正科级: ['县公安局副局长', '市局支队副支队长'],
    副处级: ['县公安局局长', '市局支队支队长'],
    正处级: ['市公安局副局长'],
    副厅局级: ['市公安局局长'],
    正厅局级: ['省公安厅厅长'],
    副省部级: ['公安部常务副部长'],
    正省部级: ['中央领导'],
    副国级: ['中央领导']
  },
  检察系统: {
    科员: ['县检察院检察员'],
    副科级: ['县检察院科长'],
    正科级: ['县检察院副检察长'],
    副处级: ['县检察院检察长'],
    正处级: ['市检察院副检察长'],
    副厅局级: ['市检察院检察长'],
    正厅局级: ['省检察院检察长'],
    副省部级: ['最高人民检察院常务副检察长'],
    正省部级: ['中央领导'],
    副国级: ['中央领导']
  },
  法院系统: {
    科员: ['县法院副庭长'],
    副科级: ['县法院庭长'],
    正科级: ['县法院副院长'],
    副处级: ['县法院院长'],
    正处级: ['市中级人民法院副院长'],
    副厅局级: ['市中级人民法院院长'],
    正厅局级: ['省高级人民法院院长'],
    副省部级: ['最高人民法院常务副院长'],
    正省部级: ['中央领导'],
    副国级: ['中央领导']
  },
  司法行政: {
    科员: ['司法所副所长'],
    副科级: ['司法所所长'],
    正科级: ['县司法局副局长'],
    副处级: ['县司法局局长'],
    正处级: ['市司法局副局长'],
    副厅局级: ['市司法局局长'],
    正厅局级: ['省司法厅厅长'],
    副省部级: ['司法部常务副部长'],
    正省部级: ['中央领导'],
    副国级: ['中央领导']
  },
  纪检监察: {
    科员: ['派驻纪检监察组副组长'],
    副科级: ['派驻纪检监察组组长'],
    正科级: ['县纪委副书记'],
    副处级: ['县纪委书记'],
    正处级: ['市纪委副书记'],
    副厅局级: ['市纪委书记'],
    正厅局级: ['省纪委书记'],
    副省部级: ['中央纪委副书记'],
    正省部级: ['中央领导'],
    副国级: ['中央领导']
  }
}

/**
 * 政法序列的下属职位表（2.6.0 新增）。与 SUBORDINATE_POSITION_BY_LEVEL 同构，
 * 只写县域默认表述，「县→区」由 makeSubordinate/levelUpSubordinate 改写。
 */
const SUBORDINATE_POSITION_BY_UNIT = {
  公安系统: {
    科员: ['民警', '派出所科员', '一级警员'],
    副科级: ['派出所副所长', '刑侦中队中队长'],
    正科级: ['派出所所长', '刑侦大队大队长'],
    副处级: ['县公安局副局长', '市局支队副支队长'],
    正处级: ['县公安局局长', '市局支队支队长'],
    副厅局级: ['市公安局副局长'],
    正厅局级: ['市公安局局长', '省厅总队总队长'],
    副省部级: ['省公安厅厅长'],
    正省部级: ['公安部常务副部长']
  },
  检察系统: {
    科员: ['检察官助理', '书记员'],
    副科级: ['助理检察员', '县检察院检察员'],
    正科级: ['检察员', '县检察院科长'],
    副处级: ['县检察院副检察长'],
    正处级: ['县检察院检察长'],
    副厅局级: ['市检察院副检察长'],
    正厅局级: ['市检察院检察长'],
    副省部级: ['省检察院检察长'],
    正省部级: ['最高人民检察院常务副检察长']
  },
  法院系统: {
    科员: ['法官助理', '书记员'],
    副科级: ['助理审判员', '县法院副庭长'],
    正科级: ['审判员', '县法院庭长'],
    副处级: ['县法院副院长'],
    正处级: ['县法院院长'],
    副厅局级: ['市中级人民法院副院长'],
    正厅局级: ['市中级人民法院院长'],
    副省部级: ['省高级人民法院院长'],
    正省部级: ['最高人民法院常务副院长']
  },
  司法行政: {
    科员: ['司法局科员', '司法所助理员'],
    副科级: ['司法所副所长', '法律援助中心副主任'],
    正科级: ['司法所所长', '法律援助中心主任'],
    副处级: ['县司法局副局长', '监狱副监狱长'],
    正处级: ['县司法局局长', '监狱长'],
    副厅局级: ['市司法局副局长'],
    正厅局级: ['市司法局局长'],
    副省部级: ['省司法厅厅长'],
    正省部级: ['司法部常务副部长']
  },
  纪检监察: {
    科员: ['纪检监察员', '县纪委监委科员'],
    副科级: ['派驻纪检监察组副组长', '县纪委监委室副主任'],
    正科级: ['派驻纪检监察组组长', '县纪委监委室主任'],
    副处级: ['县纪委副书记', '县监委副主任'],
    正处级: ['县纪委书记', '县监委主任'],
    副厅局级: ['市纪委副书记', '市监委副主任'],
    正厅局级: ['市纪委书记', '市监委主任'],
    副省部级: ['省纪委书记', '省监委主任'],
    正省部级: ['中央纪委副书记', '国家监委副主任']
  }
}

function pick(list) {
  return list[Math.floor(Math.random() * list.length)]
}

/** 政法序列「县公安局」在区里的规范叫法是「区公安分局」（非「区公安局」） */
function localizeLegalTitle(text, district, unitType) {
  const localized = localizeCounty(text, district)
  if (unitType === '公安系统' && countyKindOf(district) === '区') {
    return localized.split('区公安局').join('区公安分局')
  }
  return localized
}

/**
 * 生成一位直接上级（按玩家当前职级 + 所在区县类型 + 单位流派配称谓）。
 * 好感度给一个中等起点（组织安排的，谈不上多亲），
 * 隐藏廉政度随机——这个值玩家看不到，只有当上级被查时才翻出来，
 * 决定你要不要被牵连（见 game/personnel.js）。
 *
 * 政法序列走 MENTOR_TITLE_BY_UNIT（同一条线里的上级：民警→副所长、检察员→副检察长），
 * 党政序列走 MENTOR_TITLE_BY_LEVEL。
 *
 * @param {string} [level] 玩家当前职级，用于配上级称谓
 * @param {string} [district] 所在区县名，用于「区/县」称谓改写
 * @param {string} [unitType] 玩家单位流派（政法系统时配同线称谓）
 */
export function makeMentor(level, district, unitType) {
  const table = MENTOR_TITLE_BY_UNIT[unitType] || MENTOR_TITLE_BY_LEVEL
  const titles = table[level] || MENTOR_TITLE_BY_LEVEL.科员
  const title = localizeLegalTitle(pick(titles), district, unitType)
  const name = title.startsWith('中央')
    ? title
    : `${pick(SURNAME_POOL)}${title}`
  return {
    id: `mentor_${Date.now() % 100000}_${Math.floor(Math.random() * 1000)}`,
    name,
    level: title,
    faction: pick(['local', 'parachute', 'veteran']),
    favor: 40 + Math.floor(Math.random() * 20),       // 好感度 40~59
    hiddenRisk: Math.random() < 0.4                   // 隐藏廉政度：四成上级本身有风险
  }
}

/** 核心下属姓名池 */
export const SUBORDINATE_NAMES = [
  '小刘', '小张', '小陈', '小李', '小王', '小赵', '小孙', '小周',
  '小吴', '小郑', '小马', '小徐', '小何', '小高', '小郭', '小林'
]

/** 下属的派系倾向（可能与玩家不同，形成"布子"的空间） */
export const SUBORDINATE_FACTIONS = ['local', 'parachute', 'veteran', 'independent']

/** 职级阶梯（从低到高），用于给下属配"比本人低一两级"的级别职称 */
const LEVEL_ORDER = [
  '科员', '副科级', '正科级', '副处级', '正处级',
  '副厅局级', '正厅局级', '副省部级', '正省部级', '副国级'
]

/**
 * 下属的职务池（按级别职级取）。比本人低一两级，够不着副处以上就落到科员。
 * 每个级别给多个可选项，配合"已占职位去重"，避免一个班子冒出两个"办公室主任"。
 */
const SUBORDINATE_POSITION_BY_LEVEL = {
  科员: ['科员', '办事员', '一级科员', '二级科员'],
  副科级: ['副科长', '股室负责人', '副所长', '副主任科员'],
  正科级: ['科长', '办公室主任', '所长', '主任科员', '镇长助理'],
  副处级: ['副局长', '副处长', '副县长', '副调研员'],
  正处级: ['局长', '处长', '县长', '调研员'],
  副厅局级: ['副厅长', '副市长', '副巡视员'],
  正厅局级: ['厅长', '市长', '巡视员'],
  副省部级: ['副省长', '省委常委', '副部长'],
  正省部级: ['省长', '省委书记', '部长']
}

/**
 * 取某职级的下属职位池：政法序列走同线专属表，其余走通用党政表。
 * 政法表里没有该级时回落到通用表（数据兜底，宁可给个通用职位也不给空）。
 */
function subordinatePositionsOf(level, unitType) {
  const unitTable = SUBORDINATE_POSITION_BY_UNIT[unitType]
  if (unitTable && Array.isArray(unitTable[level]) && unitTable[level].length) {
    return unitTable[level]
  }
  return SUBORDINATE_POSITION_BY_LEVEL[level] || ['科员']
}

/**
 * 生成一名核心下属。能力/忠诚给中等起点，野心（贪腐倾向）随机。
 * 下属的级别职称为"比本人低一到两级"——一个正处级干部带的是科级/副处级，
 * 不会带出一个跟自己平级的"同级下属"。
 *
 * 自己"培养"的下属（cultivated=true）起点更低，固定比本人低两级——
 * 新人要一步步带出来；系统随晋升自动配的下属则低一到两级随机。
 * 每位下属都带一个"阶段任务"（taskProgress/taskDone）：完成任务才能
 * 名正言顺地提拔，没完成就提属于"冒风险提拔"（见 game/personnel.js）。
 *
 * 政法序列（公安/检察/法院/司法/纪检）的下属职位走 SUBORDINATE_POSITION_BY_UNIT，
 * 与玩家同一条线——公安带民警，检察带书记员，不会串到隔壁单位。
 *
 * @param {string} [playerLevel] 玩家当前职级，用于配下属级别职称
 * @param {{cultivated?: boolean, district?: string, exclude?: string[], unitType?: string}} [opts]
 *        cultivated 自己培养；district 用于县职位区/县改写；exclude 已占职位去重；
 *        unitType 玩家单位流派（政法系统时配同线下属）
 */
export function makeSubordinate(playerLevel, opts = {}) {
  const idx = LEVEL_ORDER.indexOf(playerLevel)
  // 自己培养的固定低两级（新人），系统配的低一到两级随机
  const gap = opts.cultivated ? 2 : (1 + Math.floor(Math.random() * 2))
  const lowIdx = idx >= 0 ? Math.max(0, idx - gap) : 0
  const level = LEVEL_ORDER[lowIdx] || '科员'
  let positions = subordinatePositionsOf(level, opts.unitType)
  // 排除已有下属占用的职位，避免"两个办公室主任"（班子位置是稀缺的）
  if (Array.isArray(opts.exclude) && opts.exclude.length) {
    const free = positions.filter((p) => !opts.exclude.includes(p))
    if (free.length) positions = free
  }
  const rawPosition = pick(positions)
  // 「县」按区县类型改写成「区」，公安另有「公安局→公安分局」专项
  const position = localizeLegalTitle(rawPosition, opts.district, opts.unitType)
  return {
    id: `sub_${Date.now() % 100000}_${Math.floor(Math.random() * 1000)}`,
    name: pick(SUBORDINATE_NAMES),
    level,
    position,
    ability: 40 + Math.floor(Math.random() * 30),     // 能力 40~69
    loyalty: 40 + Math.floor(Math.random() * 30),     // 忠诚 40~69
    faction: pick(SUBORDINATE_FACTIONS),
    ambition: 10 + Math.floor(Math.random() * 60),    // 野心/贪腐倾向 10~69
    outpost: false,
    cultivated: Boolean(opts.cultivated),
    // 阶段任务：progress 攒满即 taskDone，名正言顺提拔的前置（2.5.0）
    taskProgress: 0,
    taskDone: false
  }
}

/**
 * 下属升一级（级别 + 职务一起更新）。
 * 已到正省部级（再往上就是副国级，属本人级别）则返回 null。
 * @param {string} [district] 所在区县名，县职位按区/县改写
 * @param {string} [unitType] 玩家单位流派（政法系统时取同线职位）
 * @returns {string|null} 晋升后的级别，无法再升返回 null
 */
export function levelUpSubordinate(sub, district, unitType) {
  const idx = LEVEL_ORDER.indexOf(sub.level)
  if (idx < 0 || idx >= LEVEL_ORDER.length - 1) return null
  const next = LEVEL_ORDER[idx + 1]
  const positions = subordinatePositionsOf(next, unitType)
  const rawPosition = pick(positions)
  sub.level = next
  sub.position = localizeLegalTitle(rawPosition, district, unitType)
  return next
}

/**
 * 把"系统自动配"的下属同步到"比本人低一到两级"。
 * 只在晋升时调用；只升不降。返回是否发生了变化。
 */
export function syncSubordinateToPlayer(sub, playerLevel, district, unitType) {
  const idx = LEVEL_ORDER.indexOf(playerLevel)
  const gap = 1 + Math.floor(Math.random() * 2)
  const lowIdx = idx >= 0 ? Math.max(0, idx - gap) : 0
  const newLevel = LEVEL_ORDER[lowIdx] || '科员'
  if (LEVEL_ORDER.indexOf(newLevel) > LEVEL_ORDER.indexOf(sub.level)) {
    const positions = subordinatePositionsOf(newLevel, unitType)
    const rawPosition = pick(positions)
    sub.level = newLevel
    sub.position = localizeLegalTitle(rawPosition, district, unitType)
    return true
  }
  return false
}

/**
 * 下属是否还能被提拔：级别须低于"本人低一级"（不能提到跟自己平级）。
 */
export function canLevelUpSubordinate(playerLevel, sub) {
  const playerIdx = LEVEL_ORDER.indexOf(playerLevel)
  const subIdx = LEVEL_ORDER.indexOf(sub.level)
  return subIdx >= 0 && playerIdx >= 0 && subIdx < playerIdx - 1
}

/** 从名字里取姓（"李组织委员"→"李"）；"中央领导"这类无姓称谓返回 null */
function surnameOf(name) {
  if (!name) return null
  if (name.startsWith('中央')) return null
  const m = String(name).match(/^([\u4e00-\u9fa5])/)
  return m ? m[1] : null
}

/**
 * 玩家晋升后刷新上级的称谓与名字，使其永远比本人高一级。
 * 只改"称谓/名字"，保留好感度、派系与隐藏廉政度——关系是跟人走的，
 * 你进步了，组织会给你换一位配得上你职级的直接上级（姓保留，更像同一人挪了岗位）。
 * 落在「区」里的处级称谓会按区县类型改写（县长→区长）；政法序列按同线称谓。
 */
export function refreshMentor(mentor, level, district, unitType) {
  const table = MENTOR_TITLE_BY_UNIT[unitType] || MENTOR_TITLE_BY_LEVEL
  const titles = table[level] || MENTOR_TITLE_BY_LEVEL.科员
  const title = localizeLegalTitle(pick(titles), district, unitType)
  const surname = surnameOf(mentor.name)
  mentor.name = title.startsWith('中央')
    ? title
    : `${surname || pick(SURNAME_POOL)}${title}`
  mentor.level = title
  return mentor
}

/** 派系 key → 中文名，取不到退回"无派系" */
export function factionLabelOf(key) {
  return FACTION_NAMES[key] || FACTION_NAMES.independent
}
