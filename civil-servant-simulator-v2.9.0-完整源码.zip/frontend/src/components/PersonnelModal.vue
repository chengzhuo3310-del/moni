<template>
  <el-dialog
    :visible="visible"
    width="min(760px, 92vw)"
    custom-class="personnel-dialog"
    :close-on-click-modal="true"
    @update:visible="$emit('update:visible', $event)"
  >
    <div slot="title" class="pn-head">
      <p class="pn-secret">内部人事 · 阅后即焚</p>
      <h2 class="pn-title">派系与上下级</h2>
    </div>

    <div class="pn-body">
      <!-- 派系 -->
      <div class="pn-section">
        <h3 class="pn-sec-title">
          所属派系
          <el-tag size="mini" type="warning">{{ player.factionLabel || player.faction }}</el-tag>
        </h3>
        <p class="pn-sec-desc">{{ factionDesc }}</p>
      </div>

      <!-- 直接上级 -->
      <div class="pn-section">
        <h3 class="pn-sec-title">直接上级</h3>
        <div v-if="!mentors.length" class="pn-empty">暂无直接上级。</div>
        <div v-for="m in mentors" :key="m.id" class="pn-card">
          <div class="pn-card-head">
            <span class="pn-card-name">{{ m.name }}</span>
            <el-tag size="mini" effect="plain">{{ factionLabelOf(m.faction) }}</el-tag>
            <el-tag v-if="m.legacy" size="mini" type="success">门生故旧</el-tag>
            <span class="pn-card-stat">好感度 {{ m.favor }}/100</span>
          </div>
          <p v-if="m.legacyNote" class="pn-legacy-note">{{ m.legacyNote }}</p>
          <div class="pn-card-actions">
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'report', id: m.id })">
              专题汇报（+6）
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!canGift" @click="$emit('act', { action: 'gift', id: m.id })">
              节日走动（¥{{ giftCostText }}）
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'cover', id: m.id })">
              替领导解围（+20）
            </el-button>
          </div>
        </div>
      </div>

      <!-- 核心下属 -->
      <div class="pn-section">
        <h3 class="pn-sec-title">核心下属 <span class="pn-sec-hint">（副科级及以上解锁，最多 6 名）</span></h3>
        <div v-if="!subordinates.length" class="pn-empty">还没有带出核心下属，先往上走一级。</div>
        <div v-for="s in subordinates" :key="s.id" class="pn-card">
          <div class="pn-card-head">
            <span class="pn-card-name">{{ s.name }}</span>
            <el-tag size="mini" type="info">{{ s.level }}</el-tag>
            <span v-if="s.position !== s.level" class="pn-card-pos">{{ s.position }}</span>
            <el-tag v-if="s.cultivated" size="mini" type="warning">自培</el-tag>
            <el-tag v-if="s.outpost" size="mini" type="success">已外放</el-tag>
            <span class="pn-card-stat">
              能力 {{ s.ability }} · 忠诚 {{ s.loyalty }}
            </span>
          </div>
          <div v-if="!s.outpost" class="pn-task-row" :class="{ done: s.taskDone }">
            {{ taskText(s) }}
          </div>
          <div class="pn-card-actions">
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp || !canAppoint(s)" @click="$emit('act', { action: 'appoint', id: s.id })">
              {{ s.taskDone ? '任命提拔' : '冒风险提拔' }}
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'train', id: s.id })">
              带教压担子
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'praise', id: s.id })">
              推荐评优
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'merit', id: s.id })">
              任人唯贤
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'loyal', id: s.id })">
              任人唯亲
            </el-button>
            <el-button size="mini" class="gov-btn--outline" :disabled="s.outpost || !canOutpost(s)" @click="$emit('act', { action: 'outpost', id: s.id })">
              外放布子
            </el-button>
          </div>
        </div>
        <div class="pn-recruit">
          <el-button size="mini" class="gov-btn--outline" :disabled="!canRecruit" @click="$emit('act', { action: 'recruit' })">
            培养新下属（耗 1 行动力）
          </el-button>
          <span v-if="!canRecruit" class="pn-empty pn-recruit-hint">{{ recruitHint }}</span>
        </div>
      </div>

      <!-- 本地企业家（2.7.0）：正科/副处级起刷出，亲清交往 / 利益输送 / 白手套代持 -->
      <div class="pn-section">
        <h3 class="pn-sec-title">本地企业家 <span class="pn-sec-hint">（政商关系）</span></h3>
        <div v-if="!patrons.length" class="pn-empty">还没结识本地企业家。等你手里有了审批权、发包权，他们自然会找上门。</div>
        <div v-for="patron in patrons" :key="patron.id" class="pn-card">
          <div class="pn-card-head">
            <span class="pn-card-name">{{ patron.name }}</span>
            <el-tag size="mini" effect="plain">{{ patron.type }}</el-tag>
            <span class="pn-card-stat">好感度 {{ patron.favor }}/100</span>
          </div>
          <div class="pn-card-actions">
            <el-button size="mini" class="gov-btn--outline" :disabled="!hasAp" @click="$emit('act', { action: 'patron_invest', id: patron.id })">
              亲清交往·招商
            </el-button>
            <el-button size="mini" class="gov-btn--outline" @click="$emit('act', { action: 'patron_borrow', id: patron.id })">
              利益输送·拆借
            </el-button>
          </div>
          <div class="pn-card-actions pn-glove-actions">
            <template v-for="aid in gloveAssets">
              <el-button
                :key="aid"
                size="mini"
                class="gov-btn--outline"
                :disabled="!canGlove(patron, aid)"
                @click="$emit('act', { action: 'patron_whiteglove', id: patron.id, assetId: aid })"
              >
                白手套代持·{{ gloveName(aid) }}（¥{{ glovePrice(aid) }}）
              </el-button>
            </template>
          </div>
          <p v-if="patron.favor < 80" class="pn-glove-hint">白手套需好感 ≥80（代持超标豪宅豪车）</p>
          <!-- 白手套关联暴露度（2.8.0）：代持/利益输送会累积，预警期可止损 -->
          <div v-if="exposure > 0" class="pn-exposure">
            <div class="pn-exposure-head">
              <span>关联暴露度</span>
              <span :class="['pn-exposure-val', { 'is-warn': exposure >= 60 }]">{{ exposure }}/100</span>
            </div>
            <el-progress
              :percentage="exposure"
              :show-text="false"
              :stroke-width="8"
              :color="exposure >= 60 ? '#e6a23c' : '#909399'"
            />
            <p v-if="exposure >= 60" class="pn-exposure-tip">
              关联太深，已有延伸调查的风声——尽早切割或抛售止损，别等暴雷。
            </p>
          </div>
          <div v-if="patronHasGlove(patron)" class="pn-card-actions pn-stop-loss">
            <el-button size="mini" class="gov-btn--outline" @click="$emit('act', { action: 'patron_cut', id: patron.id })">
              切割关系（资产转回名下）
            </el-button>
            <el-button size="mini" class="gov-btn--outline gov-btn--danger" @click="$emit('act', { action: 'patron_dump', id: patron.id })">
              抛售套现·止损
            </el-button>
          </div>
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { FACTION_DESC, factionLabelOf, canLevelUpSubordinate } from '@/constants/factions'
import { mentorGiftCostOf } from '@/game/personnel'
import { WHITE_GLOVE_ASSETS, patronExposureOf } from '@/game/patrons'
import { assetSpecOf, assetCostInCity } from '@/constants/assets'
import { formatMoney } from '@/constants/money'

export default {
  name: 'PersonnelModal',

  props: {
    visible: { type: Boolean, default: false },
    player: { type: Object, required: true }
  },

  computed: {
    factionDesc() {
      return FACTION_DESC[this.player.faction] || FACTION_DESC.independent
    },
    mentors() {
      return Array.isArray(this.player.mentors) ? this.player.mentors : []
    },
    subordinates() {
      return Array.isArray(this.player.subordinates) ? this.player.subordinates : []
    },
    patrons() {
      return Array.isArray(this.player.patrons) ? this.player.patrons : []
    },
    gloveAssets() {
      return WHITE_GLOVE_ASSETS
    },
    /** 白手套关联暴露度（2.8.0） */
    exposure() {
      return patronExposureOf({ player: this.player })
    },
    hasAp() {
      return (Number(this.player.ap) || 0) >= 1
    },
    giftCost() {
      return mentorGiftCostOf(this.player.level)
    },
    giftCostText() {
      const v = this.giftCost
      return v >= 10000 ? `${(v / 10000).toFixed(v % 10000 === 0 ? 0 : 1)}万` : v.toLocaleString('zh-CN')
    },
    canGift() {
      return (Number(this.player.money) || 0) >= this.giftCost
    },
    /** 能否培养新下属：副科级及以上、班子未满、有行动力 */
    canRecruit() {
      const band = this.player.level
      const canHave = band === '副科级' || band === '正科级'
        || /处级|厅局级|省部级|副国级/.test(band)
      return canHave && this.subordinates.length < 6 && this.hasAp
    },
    recruitHint() {
      const band = this.player.level
      const canHave = band === '副科级' || band === '正科级'
        || /处级|厅局级|省部级|副国级/.test(band)
      if (!canHave) return '副科级及以上才能培养自己的班子'
      if (this.subordinates.length >= 6) return '班子已满员'
      if (!this.hasAp) return '行动力不足'
      return ''
    }
  },

  methods: {
    factionLabelOf,
    canOutpost(s) {
      return (Number(s.loyalty) || 0) >= 70
    },
    /** 白手套代持资产名 */
    gloveName(assetId) {
      const spec = assetSpecOf(assetId)
      return spec ? spec.name : assetId
    },
    /** 白手套代持实付价（代持价，随城市线级浮动） */
    glovePrice(assetId) {
      const price = assetCostInCity(assetId, 'proxy', this.player.cityTier)
      return price >= 10000 ? `${(price / 10000).toFixed(price % 10000 === 0 ? 0 : 1)}万` : formatMoney(price)
    },
    /** 能否白手套代持：好感够、钱够 */
    canGlove(patron, assetId) {
      if ((Number(patron.favor) || 0) < 80) return false
      return (Number(this.player.money) || 0) >= assetCostInCity(assetId, 'proxy', this.player.cityTier)
    },
    /** 该老板是否还有代持资产（有才给止损按钮） */
    patronHasGlove(patron) {
      return (this.player.assets || []).some(
        (a) => a.patronBacked && a.patronId === patron.id
      )
    },
    /** 能否给该下属任命提拔：未外放，且级别还没到"比本人低一级" */
    canAppoint(s) {
      if (s.outpost) return false
      return canLevelUpSubordinate(this.player.level, s)
    },
    /** 下属任务状态文案 */
    taskText(s) {
      if (s.taskDone) return '阶段任务已完成，可名正言顺提拔'
      return `阶段任务进行中 ${Math.round(Number(s.taskProgress) || 0)}/100`
    }
  }
}
</script>

<style scoped>
.pn-head {
  padding: 16px 24px 12px;
  border-bottom: 2px solid var(--gov-red);
  text-align: center;
}

.pn-secret {
  margin: 0 0 6px;
  font-size: 12px;
  letter-spacing: 2px;
  color: var(--gov-red);
}

.pn-title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  color: var(--gov-red-deep);
}

.pn-body {
  padding: 14px 22px 20px;
  max-height: 68vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.pn-section {
  margin-bottom: 16px;
  padding-bottom: 14px;
  border-bottom: 1px dashed var(--line-warm);
}

.pn-section:last-child {
  border-bottom: none;
  margin-bottom: 0;
}

.pn-sec-title {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 0 0 6px;
  font-size: 15px;
  font-weight: 700;
  color: var(--ink-title);
}

.pn-sec-hint {
  font-size: 12px;
  font-weight: 400;
  color: var(--ink-faint);
}

.pn-sec-desc {
  margin: 0;
  font-size: 13px;
  line-height: 1.7;
  color: var(--ink-sub);
}

.pn-empty {
  padding: 8px 0;
  font-size: 13px;
  color: var(--ink-faint);
}

.pn-card {
  margin-top: 8px;
  padding: 10px 12px;
  background-color: var(--paper-edge);
  border: 1px solid var(--line-warm);
}

.pn-card-head {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.pn-card-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--ink);
}

.pn-card-pos {
  font-size: 12px;
  color: var(--ink-sub);
}

.pn-task-row {
  margin-top: 6px;
  font-size: 12px;
  color: var(--ink-faint);
}

.pn-task-row.done {
  color: var(--gov-olive-text);
  font-weight: 600;
}

.pn-legacy-note {
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 1.6;
  color: var(--gov-olive-text);
}

.pn-recruit {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 10px;
}

.pn-recruit-hint {
  padding: 0;
}

.pn-card-stat {
  margin-left: auto;
  font-size: 12px;
  color: var(--ink-sub);
  font-variant-numeric: tabular-nums;
}

.pn-card-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.pn-card-actions .el-button + .el-button {
  margin-left: 0;
}

.pn-glove-actions {
  margin-top: 4px;
}

.pn-glove-hint {
  margin: 6px 0 0;
  font-size: 12px;
  color: var(--ink-faint);
}

/* 白手套关联暴露度（2.8.0） */
.pn-exposure {
  margin-top: 10px;
  padding: 8px 10px;
  background: var(--gov-paper, #f7f5ef);
  border-radius: 8px;
}

.pn-exposure-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 12px;
  color: var(--ink-sub);
  margin-bottom: 4px;
}

.pn-exposure-val {
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}

.pn-exposure-val.is-warn {
  color: #e6a23c;
}

.pn-exposure-tip {
  margin: 6px 0 0;
  font-size: 12px;
  color: #e6a23c;
}

.pn-stop-loss {
  margin-top: 6px;
}

@media (max-width: 768px) {
  .pn-head {
    padding: 14px 14px 10px;
  }

  .pn-body {
    padding: 12px 14px 16px;
  }

  .pn-card-actions .el-button {
    flex: 1;
    min-height: 38px;
    margin-left: 0;
  }
}
</style>
