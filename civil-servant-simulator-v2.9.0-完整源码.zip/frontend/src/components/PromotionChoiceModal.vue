<template>
  <el-dialog
    :visible="visible"
    width="min(720px, 92vw)"
    custom-class="promotion-choice-dialog"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    @update:visible="$emit('update:visible', $event)"
  >
    <div slot="title" class="pc-head" :class="{ 'is-breakthrough': breakthrough }">
      <p class="pc-secret">内部文件 · 注意保存</p>
      <h2 class="pc-title">{{ breakthrough ? '拟破格提拔任用方案（志愿征求）' : '拟提拔任用方案（志愿征求）' }}</h2>
      <p class="pc-docno">组人字〔2026〕第 {{ docNo }} 号</p>
    </div>

    <div class="pc-body">
      <p v-if="breakthrough" class="pc-breakthrough-tip">
        破格提拔：组织上破例一次，跳过剩余任职年限。新岗位人缘将有所折损，
        且下任不得再破格——这种机会，一辈子碰不上几次。
      </p>
      <p class="pc-preface">
        经组织研究，拟提拔任用你为「<strong>{{ nextLevel }}</strong>」。
        现提出以下任用去向，请结合个人意愿斟酌选择。
      </p>

      <div class="pc-options">
        <button
          v-for="option in options"
          :key="option.id"
          class="pc-option"
          :class="{ 'is-selected': selectedId === option.id }"
          @click="selectedId = option.id"
        >
          <div class="pc-option-head">
            <span class="pc-option-title">{{ option.title }}</span>
            <el-tag size="mini" type="info">{{ option.tag }}</el-tag>
          </div>
          <p class="pc-option-desc">{{ option.desc }}</p>
          <div class="pc-option-meta">
            <span class="pc-meta-unit">{{ option.unit }}</span>
            <span class="pc-meta-pos">{{ option.position }}</span>
          </div>
          <p class="pc-option-bonus" v-if="bonusTextOf(option.bonus)">
            履新：{{ bonusTextOf(option.bonus) }}
          </p>
          <span class="pc-check" v-if="selectedId === option.id">✓</span>
        </button>
      </div>
    </div>

    <span slot="footer" class="pc-footer">
      <el-button class="gov-btn" :disabled="!selectedId" @click="onConfirm">
        确定，服从组织安排
      </el-button>
    </span>
  </el-dialog>
</template>

<script>
import { bonusTextOf } from '@/game/placement'

export default {
  name: 'PromotionChoiceModal',

  props: {
    visible: { type: Boolean, default: false },
    options: { type: Array, default: () => [] },
    nextLevel: { type: String, default: '' },
    /** 是否破格提拔。破格时标题与提示都换金色语气 */
    breakthrough: { type: Boolean, default: false }
  },

  data() {
    return {
      selectedId: '',
      docNo: String(Math.floor(1000 + Math.random() * 9000))
    }
  },

  watch: {
    // 每次打开重置选择：上次选过的不能带进这次
    visible(next) {
      if (next) this.selectedId = ''
    }
  },

  methods: {
    bonusTextOf,

    onConfirm() {
      const option = this.options.find((o) => o.id === this.selectedId)
      if (!option) return
      this.$emit('choose', option)
    }
  }
}
</script>

<style scoped>
/* ══════════════ 红头 ══════════════ */
.pc-head {
  padding: 18px 28px 14px;
  border-bottom: 2px solid var(--gov-red);
  text-align: center;
}

.pc-secret {
  margin: 0 0 8px;
  font-size: 12px;
  letter-spacing: 2px;
  color: var(--gov-red);
}

.pc-title {
  margin: 0;
  font-size: 20px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--gov-red-deep);
}

.pc-docno {
  margin: 8px 0 0;
  font-size: 12px;
  letter-spacing: 1px;
  color: var(--ink-sub);
}

/* ══════════════ 正文 ══════════════ */
.pc-body {
  padding: 16px 28px 8px;
  max-height: 64vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.pc-preface {
  margin: 0 0 14px;
  font-size: 13px;
  line-height: 1.9;
  color: var(--ink-sub);
  text-indent: 2em;
}

.pc-preface strong {
  color: var(--gov-red);
}

/* 破格提拔的提示条。金色，与常规红头区分开——破格是"奖励"，不是"处分"。 */
.pc-breakthrough-tip {
  margin: 0 0 12px;
  padding: 8px 12px;
  border-left: 3px solid #c9a227;
  background-color: rgba(201, 162, 39, 0.12);
  font-size: 13px;
  line-height: 1.8;
  color: #8a6d16;
}

/* 破格时标题栏也换成金色底衬，一眼看出这是"破格"那一档 */
.pc-head.is-breakthrough {
  border-bottom-color: #c9a227;
}

.pc-head.is-breakthrough .pc-title {
  color: #9a7a12;
}

.pc-options {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.pc-option {
  position: relative;
  display: block;
  width: 100%;
  padding: 12px 14px;
  text-align: left;
  background-color: var(--paper-card);
  border: 1px solid var(--line-warm);
  border-radius: 0;
  cursor: pointer;
  transition: border-color 0.2s ease, background-color 0.2s ease;
  font-family: inherit;
}

.pc-option:hover,
.pc-option.is-selected {
  border-color: var(--gov-red);
  background-color: rgba(192, 57, 43, 0.04);
}

.pc-option-head {
  display: flex;
  align-items: center;
  gap: 8px;
}

.pc-option-title {
  font-size: 15px;
  font-weight: 700;
  color: var(--ink-title);
}

.pc-option-desc {
  margin: 6px 0 8px;
  font-size: 13px;
  line-height: 1.8;
  color: var(--ink-sub);
}

.pc-option-meta {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--ink-faint);
}

.pc-meta-unit {
  color: var(--ink-sub);
}

.pc-meta-pos {
  color: var(--gov-red);
}

.pc-option-bonus {
  margin: 6px 0 0;
  font-size: 12px;
  color: var(--gov-amber-text);
}

.pc-check {
  position: absolute;
  top: 12px;
  right: 14px;
  width: 20px;
  height: 20px;
  line-height: 20px;
  text-align: center;
  font-size: 14px;
  color: #fff;
  background-color: var(--gov-red);
  border-radius: 50%;
}

.pc-footer {
  display: block;
  text-align: center;
}

.pc-footer .el-button {
  min-width: 200px;
}

/* ══════════════ 窄屏 ══════════════ */
@media (max-width: 768px) {
  .pc-head {
    padding: 14px 14px 10px;
  }

  .pc-title {
    font-size: 17px;
  }

  .pc-body {
    padding: 12px 14px 6px;
    max-height: 66vh;
  }

  .pc-footer .el-button {
    width: 100%;
    min-height: 44px;
  }
}
</style>
