<template>
  <el-dialog
    :visible="visible"
    width="min(720px, 92vw)"
    custom-class="shop-dialog"
    :close-on-click-modal="true"
    @update:visible="$emit('update:visible', $event)"
  >
    <div slot="title" class="shop-head">
      <p class="shop-secret">内部服务 · 概不赊账</p>
      <h2 class="shop-title">生活与社交商城</h2>
    </div>

    <div class="shop-body">
      <div class="shop-wallet">
        家产 <strong>¥{{ moneyText }}</strong>
        <span class="shop-wallet-tip">商城不赊账，付不起就不卖</span>
      </div>

      <div v-if="riskWarning" class="shop-risk" :class="'is-' + riskWarning.level">
        {{ riskWarning.text }}
      </div>

      <div v-for="shelf in shelves" :key="shelf.id" class="shelf">
        <div class="shelf-head">
          <h3 class="shelf-title">{{ shelf.title }}</h3>
          <p class="shelf-hint">{{ shelf.hint }}</p>
        </div>

        <!-- 安居与座驾：从资产目录现取，价格随城市线级浮动 -->
        <template v-if="shelf.id === 'assets'">
          <div v-for="id in assetIds" :key="id" class="shop-item">
            <div class="shop-item-info">
              <span class="shop-item-icon">{{ assetSpecOf(id).icon }}</span>
              <div class="shop-item-text">
                <div class="shop-item-name">{{ assetSpecOf(id).name }}</div>
                <div class="shop-item-desc">
                  季度廉政风险 +{{ assetSpecOf(id).quarterlyRisk }}
                  <template v-if="effectTextOf(assetSpecOf(id).effects)">
                    · 置办即 {{ effectTextOf(assetSpecOf(id).effects) }}
                  </template>
                </div>
              </div>
            </div>
            <div class="shop-item-actions">
              <el-button
                class="gov-btn--outline"
                size="mini"
                :disabled="!canAfford(assetCostInCity(id, 'self', player.cityTier))"
                @click="$emit('buy', { id, holder: 'self' })"
              >
                本人 ¥{{ formatMoney(assetCostInCity(id, 'self', player.cityTier)) }}
              </el-button>
              <el-button
                class="gov-btn--outline"
                size="mini"
                :disabled="!canAfford(assetCostInCity(id, 'proxy', player.cityTier))"
                @click="$emit('buy', { id, holder: 'proxy' })"
              >
                代持 ¥{{ formatMoney(assetCostInCity(id, 'proxy', player.cityTier)) }}
              </el-button>
            </div>
          </div>
        </template>

        <!-- 消费品：健康进修 / 人情门路 -->
        <template v-else>
          <div v-for="item in itemsOf(shelf.id)" :key="item.id" class="shop-item">
            <div class="shop-item-info">
              <span class="shop-item-icon">{{ item.icon }}</span>
              <div class="shop-item-text">
                <div class="shop-item-name">{{ item.name }}</div>
                <div class="shop-item-desc">{{ item.desc }}</div>
                <div class="shop-item-meta">
                  效果：{{ effectTextOf(item.effects) }}
                  <template v-if="item.costAp"> · 耗 {{ item.costAp }} 行动力</template>
                  <template v-if="item.needIllicit"> · 需灰色资金</template>
                </div>
              </div>
            </div>
            <div class="shop-item-actions">
              <el-button
                class="gov-btn--outline"
                size="mini"
                :disabled="!canBuy(item)"
                @click="$emit('buy', { id: item.id, holder: 'self' })"
              >
                <template v-if="cooldownLeftOf(item) > 0">冷却 {{ cooldownLeftOf(item) }} 季</template>
                <template v-else>购买 ¥{{ formatMoney(item.price) }}</template>
              </el-button>
            </div>
          </div>
        </template>
      </div>
    </div>
  </el-dialog>
</template>

<script>
import { SHOP_SHELVES, shopItemsOf } from '@/constants/shop'
import { allAssetIds, assetSpecOf, assetCostInCity } from '@/constants/assets'
import { absQuarterOf } from '@/game/engine'
import { propertyRiskOf, DECLARE_TIER } from '@/game/wealth'
import { RESOURCE_LABELS } from '@/constants/gameConfig'
import { formatMoney } from '@/constants/money'

export default {
  name: 'ShopModal',

  props: {
    visible: { type: Boolean, default: false },
    player: { type: Object, required: true },
    gameStatus: { type: Object, default: () => ({}) }
  },

  data() {
    return {
      shelves: SHOP_SHELVES,
      assetIds: allAssetIds()
    }
  },

  computed: {
    moneyText() {
      return formatMoney(this.player.money)
    },

    /** 商城风控比对：当前可见财产相对合法收入的"说不清"程度（2.4.0） */
    propertyRisk() {
      try {
        return propertyRiskOf({ player: this.player, gameStatus: this.gameStatus })
      } catch (err) {
        return { gap: 0, tier: DECLARE_TIER.NONE }
      }
    },

    riskWarning() {
      const tier = this.propertyRisk.tier
      if (tier === DECLARE_TIER.SEVERE || tier === DECLARE_TIER.CASE) {
        return { level: 'danger', text: '你的家底已超出合法收入的合理范围，再购置恐被立案审查。' }
      }
      if (tier === DECLARE_TIER.TALK) {
        return { level: 'warn', text: '家底已进入约谈范围，量入为出，别在申报前把数字顶得太高。' }
      }
      return null
    }
  },

  methods: {
    assetSpecOf,
    assetCostInCity,
    formatMoney,
    itemsOf: shopItemsOf,

    canAfford(price) {
      return (Number(this.player.money) || 0) >= price
    },

    /** 消费品是否可买：钱够、冷却到、AP 够、门路到 */
    canBuy(item) {
      if (!this.canAfford(item.price)) return false
      if (this.cooldownLeftOf(item) > 0) return false
      if (item.costAp && (Number(this.player.ap) || 0) < item.costAp) return false
      if (item.needIllicit && !(Number(this.player.illicitWealth) > 0)) return false
      return true
    },

    /** 还差几个季度才过冷却（0 表示可用） */
    cooldownLeftOf(item) {
      if (!item.cooldown) return 0
      const until = Number((this.player.shopCooldowns || {})[item.id]) || 0
      return Math.max(0, until - absQuarterOf({ player: this.player }))
    },

    /** 把资源效果说成人话 */
    effectTextOf(effects) {
      const parts = []
      Object.keys(effects || {}).forEach((key) => {
        const delta = Number(effects[key]) || 0
        if (!delta) return
        const label = RESOURCE_LABELS[key] || key
        parts.push(`${label} ${delta > 0 ? '+' : ''}${delta}`)
      })
      return parts.join('、')
    }
  }
}
</script>

<style scoped>
.shop-head {
  padding: 16px 24px 12px;
  border-bottom: 2px solid var(--gov-red);
  text-align: center;
}

.shop-secret {
  margin: 0 0 6px;
  font-size: 12px;
  letter-spacing: 2px;
  color: var(--gov-red);
}

.shop-title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  letter-spacing: 1px;
  color: var(--gov-red-deep);
}

.shop-body {
  padding: 14px 22px 20px;
  max-height: 68vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.shop-wallet {
  margin-bottom: 14px;
  padding: 10px 12px;
  font-size: 13px;
  color: var(--ink-sub);
  background-color: var(--paper-edge);
  border: 1px solid var(--line-warm);
}

.shop-wallet strong {
  margin: 0 4px;
  font-size: 17px;
  color: var(--gov-red);
}

.shop-wallet-tip {
  float: right;
  font-size: 12px;
  color: var(--ink-faint);
}

.shop-risk {
  margin: -6px 0 14px;
  padding: 8px 12px;
  font-size: 12px;
  line-height: 1.6;
  border: 1px solid var(--gov-amber);
  background-color: var(--paper-edge);
  color: var(--gov-amber-text);
}

.shop-risk.is-danger {
  border-color: var(--gov-red);
  color: var(--gov-red-deep);
  background-color: rgba(196, 43, 40, 0.06);
}

.shelf {
  margin-bottom: 18px;
}

.shelf-head {
  margin-bottom: 8px;
  padding-bottom: 6px;
  border-bottom: 1px dashed var(--line-warm);
}

.shelf-title {
  display: inline-block;
  margin: 0 8px 0 0;
  font-size: 15px;
  font-weight: 700;
  color: var(--ink-title);
}

.shelf-hint {
  display: inline;
  font-size: 12px;
  color: var(--ink-faint);
}

.shop-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 10px 0;
  border-bottom: 1px solid var(--line-warm);
}

.shop-item:last-child {
  border-bottom: none;
}

.shop-item-info {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}

.shop-item-icon {
  flex-shrink: 0;
  font-size: 22px;
  line-height: 1.2;
}

.shop-item-text {
  min-width: 0;
}

.shop-item-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--ink);
}

.shop-item-desc {
  margin-top: 2px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--ink-sub);
}

.shop-item-meta {
  margin-top: 2px;
  font-size: 12px;
  color: var(--gov-amber-text);
}

.shop-item-actions {
  display: flex;
  flex-direction: column;
  gap: 6px;
  flex-shrink: 0;
}

.shop-item-actions .el-button + .el-button {
  margin-left: 0;
}

@media (max-width: 768px) {
  .shop-head {
    padding: 14px 14px 10px;
  }

  .shop-body {
    padding: 12px 14px 16px;
  }

  .shop-item {
    flex-direction: column;
    align-items: stretch;
    gap: 8px;
  }

  .shop-item-actions {
    flex-direction: row;
  }

  .shop-item-actions .el-button {
    flex: 1;
    min-height: 38px;
    margin-left: 0;
  }

  .shop-item-actions .el-button + .el-button {
    margin-left: 8px;
  }
}
</style>
