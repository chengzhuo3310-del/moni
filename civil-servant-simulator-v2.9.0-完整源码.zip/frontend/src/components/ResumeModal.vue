<template>
  <el-dialog
    :visible="visible"
    width="min(640px, 92vw)"
    custom-class="resume-dialog"
    :close-on-click-modal="true"
    @update:visible="$emit('update:visible', $event)"
  >
    <div slot="title" class="rs-head">
      <p class="rs-secret">干部任免审批表 · 个人履历</p>
      <h2 class="rs-title">{{ player.name || '（未署名）' }}同志履历</h2>
    </div>

    <div class="rs-body">
      <div class="rs-meta">
        <span>职级：{{ player.level }}</span>
        <span>现职：{{ player.position }}</span>
        <span>单位：{{ player.unit }}</span>
      </div>

      <el-timeline class="rs-timeline">
        <el-timeline-item
          v-for="(item, idx) in history"
          :key="idx"
          :type="idx === history.length - 1 ? 'primary' : ''"
          :timestamp="item.quarter"
        >
          {{ item.text }}
        </el-timeline-item>
      </el-timeline>

      <p v-if="!history.length" class="rs-empty">尚无履历记录。</p>
    </div>
  </el-dialog>
</template>

<script>
export default {
  name: 'ResumeModal',

  props: {
    visible: { type: Boolean, default: false },
    player: { type: Object, required: true }
  },

  computed: {
    history() {
      return Array.isArray(this.player.historyLog) ? this.player.historyLog : []
    }
  }
}
</script>

<style scoped>
.rs-head {
  padding: 16px 24px 12px;
  border-bottom: 2px solid var(--gov-red);
  text-align: center;
}

.rs-secret {
  margin: 0 0 6px;
  font-size: 12px;
  letter-spacing: 2px;
  color: var(--gov-red);
}

.rs-title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  color: var(--gov-red-deep);
}

.rs-body {
  padding: 14px 22px 20px;
  max-height: 68vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.rs-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 14px;
  padding: 10px 12px;
  font-size: 13px;
  color: var(--ink-sub);
  background-color: var(--paper-edge);
  border: 1px solid var(--line-warm);
}

.rs-timeline {
  padding-left: 4px;
}

.rs-timeline >>> .el-timeline-item__timestamp {
  font-size: 12px;
  color: var(--ink-faint);
}

.rs-timeline >>> .el-timeline-item__content {
  font-size: 13px;
  line-height: 1.7;
  color: var(--ink-sub);
}

.rs-empty {
  padding: 20px 0;
  text-align: center;
  font-size: 13px;
  color: var(--ink-faint);
}
</style>
