<template>
  <el-dialog
    :visible="visible"
    width="min(640px, 92vw)"
    custom-class="archive-dialog"
    :close-on-click-modal="true"
    @update:visible="$emit('update:visible', $event)"
  >
    <div slot="title" class="ar-head">
      <p class="ar-secret">跨局生涯档案 · 永久留存</p>
      <h2 class="ar-title">成就图鉴</h2>
    </div>

    <div class="ar-body">
      <!-- 生涯纪录 -->
      <div class="ar-stats">
        <div class="ar-stat">
          <span class="ar-stat-label">历史最高职级</span>
          <span class="ar-stat-value">{{ archive.highestLevel }}</span>
        </div>
        <div class="ar-stat">
          <span class="ar-stat-label">历史最高政绩</span>
          <span class="ar-stat-value">{{ archive.highestKpi }}</span>
        </div>
        <div class="ar-stat">
          <span class="ar-stat-label">最清廉通关</span>
          <span class="ar-stat-value">{{ archive.cleanRetire ? '已达成' : '未达成' }}</span>
        </div>
      </div>

      <!-- 趣味纪录榜（2.8.0）：多周目刷纪录的钩子 -->
      <div class="ar-section">
        <h3 class="ar-sec-title">趣味纪录榜</h3>
        <div class="ar-stats">
          <div class="ar-stat">
            <span class="ar-stat-label">最年轻省部级</span>
            <span class="ar-stat-value">{{ youngestSeniorText }}</span>
          </div>
          <div class="ar-stat">
            <span class="ar-stat-label">单局最高合法积累</span>
            <span class="ar-stat-value">{{ highestLegalWealthText }}</span>
          </div>
          <div class="ar-stat">
            <span class="ar-stat-label">单局最高涉案金额</span>
            <span class="ar-stat-value">{{ highestIllicitText }}</span>
          </div>
        </div>
      </div>

      <!-- 结局图鉴 -->
      <div class="ar-section">
        <h3 class="ar-sec-title">七大结局图鉴</h3>
        <div class="ar-album">
          <div v-for="e in endingAlbum" :key="e.id" class="ar-ending" :class="{ 'is-locked': !unlocked(e.id) }">
            <span class="ar-ending-name">{{ unlocked(e.id) ? e.label : '？？？' }}</span>
            <span class="ar-ending-count" v-if="unlocked(e.id)">×{{ archive.endings[e.id] }}</span>
            <span class="ar-ending-desc">{{ unlocked(e.id) ? e.desc : '尚未解锁' }}</span>
          </div>
        </div>
      </div>

      <!-- 成就徽章 -->
      <div class="ar-section">
        <h3 class="ar-sec-title">成就徽章</h3>
        <div class="ar-badges">
          <div v-for="a in achievementList" :key="a.id" class="ar-badge" :class="{ 'is-earned': hasBadge(a.id) }">
            <span class="ar-badge-icon">{{ hasBadge(a.id) ? '🏅' : '🔒' }}</span>
            <span class="ar-badge-name">{{ a.name }}</span>
            <span class="ar-badge-desc">{{ a.desc }}</span>
          </div>
        </div>
      </div>

      <p class="ar-note">每解锁一个结局，下局考公获得微弱的初始属性加成。</p>
    </div>
  </el-dialog>
</template>

<script>
import { loadArchive, ACHIEVEMENTS, ENDING_ALBUM } from '@/game/archive'

export default {
  name: 'ArchiveModal',

  props: {
    visible: { type: Boolean, default: false }
  },

  data() {
    return {
      endingAlbum: ENDING_ALBUM,
      achievementList: ACHIEVEMENTS
    }
  },

  computed: {
    archive() {
      return loadArchive()
    },
    youngestSeniorText() {
      const rec = this.archive.records && this.archive.records.youngestSenior
      return rec ? `${rec.age} 岁 · ${rec.level}` : '尚未达成'
    },
    highestLegalWealthText() {
      const v = Number((this.archive.records && this.archive.records.highestLegalWealth) || 0)
      return v > 0 ? `¥${v.toLocaleString('zh-CN')}` : '尚无'
    },
    highestIllicitText() {
      const v = Number((this.archive.records && this.archive.records.highestIllicit) || 0)
      return v > 0 ? `¥${v.toLocaleString('zh-CN')}` : '清廉至今'
    }
  },

  methods: {
    unlocked(id) {
      return Boolean(this.archive.endings && this.archive.endings[id])
    },
    hasBadge(id) {
      return (this.archive.achievements || []).indexOf(id) >= 0
    }
  }
}
</script>

<style scoped>
.ar-head {
  padding: 16px 24px 12px;
  border-bottom: 2px solid var(--gov-red);
  text-align: center;
}

.ar-secret {
  margin: 0 0 6px;
  font-size: 12px;
  letter-spacing: 2px;
  color: var(--gov-red);
}

.ar-title {
  margin: 0;
  font-size: 19px;
  font-weight: 700;
  color: var(--gov-red-deep);
}

.ar-body {
  padding: 14px 22px 20px;
  max-height: 68vh;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}

.ar-stats {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 10px;
  margin-bottom: 16px;
}

.ar-stat {
  padding: 10px 12px;
  text-align: center;
  background-color: var(--paper-edge);
  border: 1px solid var(--line-warm);
}

.ar-stat-label {
  display: block;
  font-size: 12px;
  color: var(--ink-faint);
}

.ar-stat-value {
  display: block;
  margin-top: 4px;
  font-size: 16px;
  font-weight: 700;
  color: var(--gov-red);
}

.ar-section {
  margin-bottom: 16px;
}

.ar-sec-title {
  margin: 0 0 10px;
  font-size: 15px;
  font-weight: 700;
  color: var(--ink-title);
}

.ar-album {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
}

.ar-ending {
  padding: 10px 12px;
  border: 1px solid var(--line-warm);
  background-color: var(--paper-edge);
}

.ar-ending.is-locked {
  opacity: 0.55;
}

.ar-ending-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--ink);
}

.ar-ending-count {
  margin-left: 6px;
  font-size: 12px;
  color: var(--gov-amber-text);
}

.ar-ending-desc {
  display: block;
  margin-top: 4px;
  font-size: 12px;
  color: var(--ink-sub);
}

.ar-badges {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
}

.ar-badge {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border: 1px solid var(--line-warm);
  background-color: var(--paper-edge);
}

.ar-badge.is-earned {
  border-color: rgba(201, 162, 39, 0.5);
  background-color: rgba(201, 162, 39, 0.08);
}

.ar-badge-icon {
  font-size: 20px;
}

.ar-badge-name {
  font-size: 14px;
  font-weight: 600;
  color: var(--ink);
}

.ar-badge-desc {
  font-size: 12px;
  color: var(--ink-sub);
}

.ar-note {
  margin: 12px 0 0;
  padding-top: 10px;
  border-top: 1px dashed var(--line-warm);
  font-size: 12px;
  color: var(--ink-faint);
}

@media (max-width: 768px) {
  .ar-stats,
  .ar-album,
  .ar-badges {
    grid-template-columns: 1fr;
  }
}
</style>
