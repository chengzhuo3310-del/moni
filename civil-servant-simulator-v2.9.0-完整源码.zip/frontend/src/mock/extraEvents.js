/**
 * 扩充事件库（2.1.0 新增，人手维护）。
 *
 * 把池子从约 138 条补到 200 条：覆盖 4 单位 × 各职级档 × 日常/廉政/健康，
 * 并引入一批"选择 → 标记 → 后续解锁"的分支事件（见 option.setFlag / needFlag）。
 * 字段契约与 localEvents.js 的 SEED_EVENTS 完全一致，校验规则见 validatePool。
 */

const EXTRA_EVENTS = [
  // ═══════════════ 核心部门 ═══════════════
  {
    id: 'evt_extra_core_k_midnight_material',
    title: '又要改的材料',
    npcName: '分管副主任 老陈',
    unitType: '核心部门',
    bands: ['科级'],
    theme: 'daily',
    description: '周五晚上九点，老陈把你叫住：周一的汇报材料书记批了八个字——"立意不新、站得不高"。稿子明天就要，你还没吃晚饭。',
    options: [
      { id: 'opt_a', text: '连夜重写，往"两个大局"上靠', costAp: 1, effects: { energy: -15, health: -5, mgmt: 8, ability: 4 } },
      { id: 'opt_b', text: '先打电话问老陈到底哪里不满意', costAp: 1, effects: { mgmt: 6, popularity: 2, energy: -6 } },
      { id: 'opt_c', text: '原样交上去，反正也不是第一次', costAp: 0, effects: { mgmt: -6, risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_core_k_leader_choice',
    title: '书记与市长的两难',
    npcName: '老领导 王书记',
    unitType: '核心部门',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '王书记和市长在对一份改革方案上意见相左，两边都私下找你，让你"表个态"。你夹在中间，知道这一步选错，后面几年都不好走。',
    options: [
      { id: 'opt_a', text: '站书记这一边', costAp: 1, effects: { authority: 8, mgmt: 6, popularity: -4 }, setFlag: { faction: 'secretary' } },
      { id: 'opt_b', text: '站市长这一边', costAp: 1, effects: { authority: 8, mgmt: 6, popularity: -4 }, setFlag: { faction: 'mayor' } },
      { id: 'opt_c', text: '两头都不得罪，先拖着', costAp: 0, effects: { authority: -4, kpi: -2 }, setFlag: { faction: 'neutral' } }
    ]
  },
  {
    id: 'evt_extra_core_c_speech_draft',
    title: '全会的发言稿',
    npcName: '市委秘书长',
    unitType: '核心部门',
    bands: ['处级'],
    theme: 'daily',
    description: '秘书长把全会主报告的起草交给你牵头。这是露脸的机会，也是掉层皮的机会。',
    options: [
      { id: 'opt_a', text: '亲自操刀，通宵成稿', costAp: 1, effects: { ability: 6, kpi: 8, energy: -18, health: -4 } },
      { id: 'opt_b', text: '分给下面几个笔杆子，你把关', costAp: 1, effects: { mgmt: 8, kpi: 4, popularity: 2 } },
      { id: 'opt_c', text: '按往年的框架改一改', costAp: 0, effects: { kpi: -4, ability: -2 } }
    ]
  },
  {
    id: 'evt_extra_core_c_insider_tip',
    title: '会前的风声',
    npcName: '老同事 赵哥',
    unitType: '核心部门',
    bands: ['处级'],
    theme: 'risk',
    description: '赵哥神神秘秘地凑过来：市里马上要启动一轮干部调整，你这次"很有希望"，但名单还没定死。他说可以帮你"递句话"。',
    options: [
      { id: 'opt_a', text: '让赵哥帮忙递话', costAp: 1, effects: { mgmt: 8, risk: 10, authority: 2 }, costMoney: 50000 },
      { id: 'opt_b', text: '靠自己，谢绝好意', costAp: 0, effects: { risk: -4 } },
      { id: 'opt_c', text: '打探一下名单到底有谁', costAp: 1, effects: { mgmt: 4, risk: 4, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_core_t_party_committee',
    title: '常委会的分工',
    npcName: '市委书记',
    unitType: '核心部门',
    bands: ['厅级'],
    theme: 'daily',
    description: '书记找你谈分工，问你愿不愿意接一块"最难啃的硬骨头"。啃下来就是实打实的政绩，啃不下来就是污点。',
    options: [
      { id: 'opt_a', text: '主动请缨接硬活', costAp: 1, effects: { kpi: 12, authority: 6, risk: 4, energy: -10 } },
      { id: 'opt_b', text: '挑个稳妥的条线', costAp: 1, effects: { kpi: 4, risk: -4, popularity: 2 } },
      { id: 'opt_c', text: '说听组织安排', costAp: 0, effects: { mgmt: 2, kpi: -4 } }
    ]
  },
  {
    id: 'evt_extra_core_t_faction_reward',
    title: '当初那一票',
    npcName: '王书记',
    unitType: '核心部门',
    bands: ['厅级'],
    theme: 'daily',
    description: '当年你在书记与市长之间做过选择。如今风向明朗了，当年站对的人，正等着分果子。',
    options: [
      { id: 'opt_a', text: '顺势表功，要个好位置', costAp: 1, effects: { mgmt: 10, authority: 6 }, needFlag: { faction: 'secretary' }, needFlagText: '你当年没站到这一边' },
      { id: 'opt_b', text: '低调做人，不争', costAp: 0, effects: { popularity: 4, kpi: -8 } },
      { id: 'opt_c', text: '提醒书记别落人口实', costAp: 1, effects: { authority: 8, risk: -2, popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_core_s_provincial_report',
    title: '向省委述职',
    npcName: '省委组织部',
    unitType: '核心部门',
    bands: ['省部级'],
    theme: 'daily',
    description: '一年一度的述职评议。台下坐着的都是能决定你下一步的人。',
    options: [
      { id: 'opt_a', text: '讲实绩，也讲问题', costAp: 1, effects: { authority: 8, kpi: 6, risk: -2 } },
      { id: 'opt_b', text: '重点讲亮点，回避短板', costAp: 1, effects: { authority: 6, kpi: 2, risk: 3 } },
      { id: 'opt_c', text: '照稿念，不求有功', costAp: 0, effects: { authority: -4 } }
    ]
  },
  {
    id: 'evt_extra_core_s_top_secret',
    title: '绝密件',
    npcName: '机要员',
    unitType: '核心部门',
    bands: ['省部级'],
    theme: 'risk',
    description: '一份涉及重大项目调整的绝密件送到你案头。你知道，有人在出高价买这个信。',
    options: [
      { id: 'opt_a', text: '按规定流程办，不越雷池', costAp: 0, effects: { risk: -5 } },
      { id: 'opt_b', text: '给中间人透个口风', costAp: 1, effects: { risk: 30, popularity: -5 }, gainIllicit: 800000 },
      { id: 'opt_c', text: '提醒机要室加强管理', costAp: 1, effects: { authority: 4, kpi: 2, risk: -2 } }
    ]
  },

  // ═══════════════ 基层乡镇 ═══════════════
  {
    id: 'evt_extra_town_k_flood',
    title: '台风前的值守',
    npcName: '镇党委书记',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '台风红色预警，镇里要求全员到岗。水库、危房、低洼点，每一处都要有人盯。',
    options: [
      { id: 'opt_a', text: '冲在第一线巡堤', costAp: 1, effects: { popularity: 8, kpi: 6, energy: -15, health: -4 } },
      { id: 'opt_b', text: '坐镇指挥部统筹', costAp: 1, effects: { mgmt: 6, kpi: 4, energy: -8 } },
      { id: 'opt_c', text: '让别人顶，自己留守办公室', costAp: 0, effects: { popularity: -6, risk: 3 } }
    ]
  },
  {
    id: 'evt_extra_town_k_village_dispute',
    title: '两户人家的界墙',
    npcName: '村支书 老刘',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '两户村民为了一堵界墙闹了三年，如今动了手。老刘说，这事再压不住，就要闹到县里去了。',
    options: [
      { id: 'opt_a', text: '亲自下村，坐在两家人中间调解', costAp: 1, effects: { popularity: 8, kpi: 4, energy: -10 } },
      { id: 'opt_b', text: '让村支书先稳住，按程序上报', costAp: 0, effects: { kpi: -2, risk: 2 } },
      { id: 'opt_c', text: '把两家人叫到镇里谈', costAp: 1, effects: { mgmt: 4, popularity: 4, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_town_k_subsidy',
    title: '惠农补贴的过路费',
    npcName: '熟人 老钱',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'risk',
    description: '一笔惠农补贴要从你手上过。老钱找上门，说只要你在名单上"通融"一下，少不了你的那份。',
    options: [
      { id: 'opt_a', text: '严格审核，一分不少发到位', costAp: 0, effects: { risk: -4 } },
      { id: 'opt_b', text: '给老钱"通融"一下', costAp: 1, effects: { risk: 18, popularity: -4 }, gainIllicit: 60000 },
      { id: 'opt_c', text: '把这事公开走流程', costAp: 1, effects: { kpi: 4, authority: 2, risk: -2 } }
    ]
  },
  {
    id: 'evt_extra_town_c_land_requisition',
    title: '征地拆迁',
    npcName: '拆迁办 老孙',
    unitType: '基层乡镇',
    bands: ['处级'],
    theme: 'risk',
    description: '一片城中村要拆，补偿标准有两套说法。老孙说，按"另一套"标准，能省下一大笔，还能给几个钉子户"特殊照顾"。',
    options: [
      { id: 'opt_a', text: '坚决按公示标准来', costAp: 0, effects: { popularity: 6, risk: -5, kpi: -12 } },
      { id: 'opt_b', text: '默许老孙的操作', costAp: 1, effects: { risk: 25, kpi: 5 }, gainIllicit: 300000 },
      { id: 'opt_c', text: '把补偿方案再复核一遍', costAp: 1, effects: { kpi: 4, authority: 2, energy: -8 } }
    ]
  },
  {
    id: 'evt_extra_town_c_industrial_park',
    title: '招商引资',
    npcName: '县长',
    unitType: '基层乡镇',
    bands: ['处级'],
    theme: 'daily',
    description: '一个外地客商想来投建产业园，条件是要县里给足政策。县长让你去对接，务必要谈成。',
    options: [
      { id: 'opt_a', text: '给出诚意最大的政策包', costAp: 1, effects: { kpi: 10, mgmt: 6, risk: 5 } },
      { id: 'opt_b', text: '守住底线，分批谈', costAp: 1, effects: { kpi: 5, risk: -3, energy: -6 } },
      { id: 'opt_c', text: '先晾一晾，压对方价', costAp: 0, effects: { kpi: -4, mgmt: -2 } }
    ]
  },
  {
    id: 'evt_extra_town_t_city_planning',
    title: '城市规划的分歧',
    npcName: '市长',
    unitType: '基层乡镇',
    bands: ['厅级'],
    theme: 'daily',
    description: '新城规划摆上会，有人要大拆大建，有人要留旧城肌理。市长问你意见。',
    options: [
      { id: 'opt_a', text: '支持大拆大建，快出政绩', costAp: 1, effects: { kpi: 10, risk: 5, popularity: -4 } },
      { id: 'opt_b', text: '主张保留旧城，兼顾民生', costAp: 1, effects: { popularity: 8, kpi: 3, risk: -3 } },
      { id: 'opt_c', text: '不表态', costAp: 0, effects: { authority: -4 } }
    ]
  },
  {
    id: 'evt_extra_town_t_corruption_case',
    title: '窝案牵连',
    npcName: '纪委书记',
    unitType: '基层乡镇',
    bands: ['厅级'],
    theme: 'risk',
    description: '你曾共事的一位老部下被查，交代材料里提到了你。纪委书记找你"核实情况"。',
    options: [
      { id: 'opt_a', text: '主动把当年的事说清楚', costAp: 0, effects: { risk: -8, authority: -2 }, setFlag: { honest: true } },
      { id: 'opt_b', text: '能拖就拖，看对方掌握多少', costAp: 1, effects: { risk: 12, energy: -6 } },
      { id: 'opt_c', text: '找人说情压一压', costAp: 1, grayBoost: true, effects: { risk: 15, mgmt: 3 }, costMoney: 100000 }
    ]
  },
  {
    id: 'evt_extra_town_s_provincial_governor',
    title: '省府的岗位',
    npcName: '省委组织部',
    unitType: '基层乡镇',
    bands: ['省部级'],
    theme: 'daily',
    description: '从基层一路干到省部级，如今组织上要你在省府挑一摊子。',
    options: [
      { id: 'opt_a', text: '挑最重的摊子', costAp: 1, effects: { kpi: 12, authority: 6, risk: 4 } },
      { id: 'opt_b', text: '挑自己熟的领域', costAp: 1, effects: { kpi: 6, risk: -3 } },
      { id: 'opt_c', text: '听组织安排', costAp: 0, effects: { mgmt: 3, kpi: -6 } }
    ]
  },

  // ═══════════════ 常规局委 ═══════════════
  {
    id: 'evt_extra_bureau_k_budget',
    title: '预算分配',
    npcName: '科长 老周',
    unitType: '常规局委',
    bands: ['科级'],
    theme: 'daily',
    description: '年底预算盘子要分，各科室都来争。老周让你拟一个方案。',
    options: [
      { id: 'opt_a', text: '按绩效分配，动真格', costAp: 1, effects: { ability: 6, kpi: 4, popularity: -4 } },
      { id: 'opt_b', text: '雨露均沾，谁都不得罪', costAp: 1, effects: { popularity: 6, mgmt: 4 } },
      { id: 'opt_c', text: '照去年的方案来', costAp: 0, effects: { kpi: -2 } }
    ]
  },
  {
    id: 'evt_extra_bureau_k_license',
    title: '办证的加急费',
    npcName: '中介 小马',
    unitType: '常规局委',
    bands: ['科级'],
    theme: 'risk',
    description: '一个企业来办证，材料差一项。中介小马说，加急的话，材料可以"后补"。',
    options: [
      { id: 'opt_a', text: '按规矩来，缺一项就补一项', costAp: 0, effects: { risk: -3 } },
      { id: 'opt_b', text: '收下"加急费"，先发证', costAp: 1, effects: { risk: 15 }, gainIllicit: 40000 },
      { id: 'opt_c', text: '让他走绿色通道，但不收钱', costAp: 1, effects: { popularity: 3, kpi: 2, risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_bureau_c_project_bid',
    title: '项目招标',
    npcName: '老板 陈总',
    unitType: '常规局委',
    bands: ['处级'],
    theme: 'risk',
    description: '一个上亿的项目要招标。陈总约你吃饭，暗示"合作共赢"。',
    options: [
      { id: 'opt_a', text: '婉拒饭局', costAp: 0, effects: { risk: -5 } },
      { id: 'opt_b', text: '赴约，先听听条件', costAp: 1, effects: { risk: 20 }, gainIllicit: 400000 },
      { id: 'opt_c', text: '让招标全程留痕、公开透明', costAp: 1, effects: { kpi: 6, risk: -3, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_bureau_c_inspection',
    title: '上级检查',
    npcName: '局长',
    unitType: '常规局委',
    bands: ['处级'],
    theme: 'daily',
    description: '上级要来检查，局里问题不少。局长让你牵头迎检。',
    options: [
      { id: 'opt_a', text: '老老实实整改', costAp: 1, effects: { kpi: 6, risk: -4, energy: -8 } },
      { id: 'opt_b', text: '做足表面功夫', costAp: 1, effects: { mgmt: 6, kpi: 2, risk: 4 } },
      { id: 'opt_c', text: '让各科室自行准备', costAp: 0, effects: { kpi: -3, risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_bureau_t_provincial_bureau',
    title: '省厅的位子',
    npcName: '省委组织部',
    unitType: '常规局委',
    bands: ['厅级'],
    theme: 'daily',
    description: '省厅一个副厅长位置空出，你在考察名单上。',
    options: [
      { id: 'opt_a', text: '积极争取', costAp: 1, effects: { mgmt: 10, authority: 6, risk: 3 } },
      { id: 'opt_b', text: '顺其自然', costAp: 0, effects: { popularity: 2, kpi: -4 } },
      { id: 'opt_c', text: '找人打听考察口径', costAp: 1, effects: { mgmt: 6, risk: 4, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_bureau_t_big_bribe',
    title: '一笔大数',
    npcName: '老关系 吴总',
    unitType: '常规局委',
    bands: ['厅级'],
    theme: 'risk',
    description: '吴总登门，直接开出一个让你手抖的数字，只为一个大项目的批文。',
    options: [
      { id: 'opt_a', text: '断然拒绝', costAp: 0, effects: { risk: -6 } },
      { id: 'opt_b', text: '收了这笔', costAp: 1, effects: { risk: 40, popularity: -6 }, gainIllicit: 2000000 },
      { id: 'opt_c', text: '让他走正规渠道，公事公办', costAp: 1, effects: { kpi: 4, risk: -3 } }
    ]
  },
  {
    id: 'evt_extra_bureau_s_national_commission',
    title: '部委的台阶',
    npcName: '中央某部',
    unitType: '常规局委',
    bands: ['省部级'],
    theme: 'daily',
    description: '中央部委伸来橄榄枝，要调你进京。这意味着离开经营多年的地方。',
    options: [
      { id: 'opt_a', text: '进京，接受更大平台', costAp: 1, effects: { mgmt: 10, authority: 8, popularity: -4 } },
      { id: 'opt_b', text: '留在地方', costAp: 1, effects: { popularity: 6, kpi: 4 } },
      { id: 'opt_c', text: '先观望', costAp: 0, effects: { authority: -3 } }
    ]
  },

  // ═══════════════ 边缘部门 ═══════════════
  {
    id: 'evt_extra_marg_k_archive',
    title: '档案室的钉子',
    npcName: '老档案员 孙姨',
    unitType: '边缘部门',
    bands: ['科级'],
    theme: 'daily',
    description: '单位要数字化档案，孙姨守着几十年的老规矩不放，说"电脑靠不住"。',
    options: [
      { id: 'opt_a', text: '耐心做孙姨工作', costAp: 1, effects: { popularity: 6, kpi: 3, energy: -6 } },
      { id: 'opt_b', text: '先试点一批，让数据说话', costAp: 1, effects: { ability: 6, kpi: 4 } },
      { id: 'opt_c', text: '搁置，以后再说', costAp: 0, effects: { kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_marg_k_local_gazetteer',
    title: '地方志的编纂',
    npcName: '方志办 老钱',
    unitType: '边缘部门',
    bands: ['科级'],
    theme: 'daily',
    description: '新一卷地方志要定稿，老钱请你去把把关。',
    options: [
      { id: 'opt_a', text: '认真通读，逐条校对', costAp: 1, effects: { ability: 6, kpi: 4, energy: -10 } },
      { id: 'opt_b', text: '大致翻一遍', costAp: 0, effects: { kpi: -2 } },
      { id: 'opt_c', text: '借机梳理一批史料存档', costAp: 1, effects: { kpi: 4, popularity: 2, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_marg_c_exile',
    title: '清水衙门的岁月',
    npcName: '老同事',
    unitType: '边缘部门',
    bands: ['处级'],
    theme: 'daily',
    description: '被放到清水衙门后，日子清闲。老同事劝你：既然没实权，就多读点书、养好身体，等机会。',
    options: [
      { id: 'opt_a', text: '静心充电，厚积薄发', costAp: 1, effects: { ability: 10, health: 4, kpi: -2 } },
      { id: 'opt_b', text: '四处走动，找机会调出去', costAp: 1, effects: { mgmt: 6, popularity: 4, risk: 3 } },
      { id: 'opt_c', text: '就这么混着', costAp: 0, effects: { ability: -3, health: -2 } }
    ]
  },
  {
    id: 'evt_extra_marg_c_transfer_apply',
    title: '遴选的机会',
    npcName: '组织部 小张',
    unitType: '边缘部门',
    bands: ['处级'],
    theme: 'daily',
    description: '市里面向基层公开遴选，小张把报名表放到你桌上："你的条件符合，报不报？"',
    options: [
      { id: 'opt_a', text: '报名遴选，搏一把', costAp: 1, effects: {}, transfer: { unitType: '核心部门', base: 0.15, perAbility: 0.006, perMgmt: 0.006 } },
      { id: 'opt_b', text: '留在原地', costAp: 0, effects: {} },
      { id: 'opt_c', text: '先备考，下次再说', costAp: 1, effects: { ability: 4, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_marg_t_provincial_archive',
    title: '省档案馆',
    npcName: '馆长',
    unitType: '边缘部门',
    bands: ['厅级'],
    theme: 'daily',
    description: '省档案馆要建数字化中心，馆长把这个项目交给你。',
    options: [
      { id: 'opt_a', text: '高标准推进，做成样板', costAp: 1, effects: { kpi: 8, ability: 6, energy: -10 } },
      { id: 'opt_b', text: '按部就班', costAp: 0, effects: { kpi: -2 } },
      { id: 'opt_c', text: '借项目培养一批年轻人', costAp: 1, effects: { popularity: 6, mgmt: 4, kpi: 3 } }
    ]
  },
  {
    id: 'evt_extra_marg_t_old_comrade',
    title: '老同志的来访',
    npcName: '退休老领导',
    unitType: '边缘部门',
    bands: ['厅级'],
    theme: 'daily',
    description: '一位退休多年的老领导专程来看你，聊起当年，也说起了"现在有的年轻人，路走得太急了"。',
    options: [
      { id: 'opt_a', text: '虚心求教', costAp: 1, effects: { authority: 6, popularity: 4 } },
      { id: 'opt_b', text: '寒暄几句送走', costAp: 0, effects: {} },
      { id: 'opt_c', text: '请老领导指点迷津', costAp: 1, effects: { mgmt: 6, authority: 4, energy: -4 } }
    ]
  },

  // ═══════════════ 通用（各流派都抽得到）══════════════
  {
    id: 'evt_extra_common_k_year_end',
    title: '年终考核',
    npcName: '考核组',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '年终考核开始，你的年度表现要过一遍。',
    options: [
      { id: 'opt_a', text: '认真准备述职', costAp: 1, effects: { kpi: 6, ability: 4, energy: -6 } },
      { id: 'opt_b', text: '请同事吃顿饭，拉拉票', costAp: 1, effects: { popularity: 6, mgmt: 2 }, costMoney: 3000 },
      { id: 'opt_c', text: '随便应付', costAp: 0, effects: { kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_common_k_mentor',
    title: '老领导的赏识',
    npcName: '老领导 李书记',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    onceFlag: 'mentorMet',
    description: '一次会上，你的发言被李书记记下了。会后他把你留下，问你想不想跟着他干。',
    options: [
      { id: 'opt_a', text: '答应，拜这位老领导为师', costAp: 1, effects: { mgmt: 8, authority: 6 }, setFlag: { mentor: true } },
      { id: 'opt_b', text: '婉拒，想靠自己', costAp: 0, effects: { authority: 3, kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_common_c_mentor_help',
    title: '破格提拔的风声',
    npcName: '老领导 李书记',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '上面在考虑一批破格提拔的人选，李书记能帮你说上话。',
    options: [
      { id: 'opt_a', text: '请李书记帮忙美言', costAp: 1, effects: { mgmt: 10, authority: 6, risk: 3 }, needFlag: { mentor: true }, needFlagText: '你没有这条人脉' },
      { id: 'opt_b', text: '凭实力上，不打招呼', costAp: 1, effects: { ability: 6, kpi: 4, risk: -2 } },
      { id: 'opt_c', text: '按兵不动', costAp: 0, effects: {} }
    ]
  },
  {
    id: 'evt_extra_common_k_banquet',
    title: '推不掉的饭局',
    npcName: '老同学 阿强',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '老同学阿强组局，说是叙旧，其实是替一个老板牵线。',
    options: [
      { id: 'opt_a', text: '赴约，只吃饭不谈事', costAp: 1, effects: { popularity: 4, risk: 2, energy: -4 } },
      { id: 'opt_b', text: '找个理由推掉', costAp: 0, effects: { popularity: -2, risk: -3 } },
      { id: 'opt_c', text: '去，帮老同学一次', costAp: 1, effects: { popularity: 6, risk: 12 }, gainIllicit: 80000 }
    ]
  },
  {
    id: 'evt_extra_common_k_health_check',
    title: '体检报告',
    npcName: '医生',
    unitType: '通用',
    bands: ['科级', '处级', '厅级', '省部级'],
    theme: 'health',
    description: '年度体检报告出来了，几项指标亮起黄灯。医生说"不能再熬了"。',
    options: [
      { id: 'opt_a', text: '规律作息，坚持锻炼', costAp: 1, effects: { health: 12, energy: 6, kpi: -2 } },
      { id: 'opt_b', text: '先忙完这阵再说', costAp: 0, effects: { health: -6, energy: -2 } },
      { id: 'opt_c', text: '吃点保健品扛着', costAp: 1, effects: { health: 2, energy: 2 }, costMoney: 5000 }
    ]
  },
  {
    id: 'evt_extra_common_c_family',
    title: '家里的事',
    npcName: '妻子',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '妻子说，你很久没陪孩子吃顿饭了。学校老师也来电话，说孩子最近有点情绪。',
    options: [
      { id: 'opt_a', text: '推掉应酬，回家陪家人', costAp: 1, effects: { popularity: -2, health: 6, energy: 4 } },
      { id: 'opt_b', text: '工作要紧，先应付过去', costAp: 0, effects: { health: -4, popularity: -2 } },
      { id: 'opt_c', text: '周末带全家出去走走', costAp: 1, effects: { health: 6, energy: 6, kpi: -2 }, costMoney: 2000 }
    ]
  },
  {
    id: 'evt_extra_common_k_petition',
    title: '上访的群众',
    npcName: '信访办 老郑',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '几个群众来反映问题，情绪激动。老郑问你要不要先"做做工作"。',
    options: [
      { id: 'opt_a', text: '亲自接访，听他们把话说完', costAp: 1, effects: { popularity: 8, kpi: 4, energy: -8 } },
      { id: 'opt_b', text: '让老郑按流程处理', costAp: 0, effects: { kpi: -2, risk: 2 } },
      { id: 'opt_c', text: '先拖一拖，看他们走不走', costAp: 1, effects: { risk: 6, popularity: -4, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_common_c_media',
    title: '媒体的电话',
    npcName: '记者 小林',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '有记者打来电话，想就你们单位的一件争议事件做个采访。',
    options: [
      { id: 'opt_a', text: '正面回应，主动公开', costAp: 1, effects: { authority: 6, risk: -4, energy: -6 } },
      { id: 'opt_b', text: '让宣传口挡回去', costAp: 1, effects: { mgmt: 4, risk: 2 } },
      { id: 'opt_c', text: '不接，冷处理', costAp: 0, effects: { risk: 4, popularity: -3 } }
    ]
  },
  {
    id: 'evt_extra_common_t_audit',
    title: '审计进场',
    npcName: '审计组',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'risk',
    description: '审计组进驻，要查近三年的账。',
    options: [
      { id: 'opt_a', text: '全力配合，主动说明问题', costAp: 1, effects: { risk: -8, authority: 2 } },
      { id: 'opt_b', text: '想办法遮掩', costAp: 1, effects: { risk: 15, energy: -8 } },
      { id: 'opt_c', text: '让财务去应付', costAp: 0, effects: { risk: 4, mgmt: -2 } }
    ]
  },
  {
    id: 'evt_extra_common_k_gift',
    title: '节日的礼盒',
    npcName: '下属 小王',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'risk',
    description: '小王拎着一个"土特产"礼盒上门，说是老家带来的。盒子有点重。',
    options: [
      { id: 'opt_a', text: '拆开看看再说', costAp: 0, effects: {} },
      { id: 'opt_b', text: '收下', costAp: 1, effects: { risk: 8, popularity: 2 }, gainIllicit: 20000 },
      { id: 'opt_c', text: '坚决不收，让他带回去', costAp: 0, effects: { risk: -3 } }
    ]
  },
  {
    id: 'evt_extra_common_c_study',
    title: '党校培训',
    npcName: '党校 陈教授',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '组织上安排你到党校脱产学习一段时间。',
    options: [
      { id: 'opt_a', text: '认真学，多结识同窗', costAp: 1, effects: { ability: 8, mgmt: 6, energy: -6 } },
      { id: 'opt_b', text: '当个清闲假期', costAp: 0, effects: { ability: -3, health: 3 } },
      { id: 'opt_c', text: '边学边抓单位的事', costAp: 1, effects: { ability: 4, kpi: 4, energy: -10 } }
    ]
  },
  {
    id: 'evt_extra_common_k_rumor',
    title: '风言风语',
    npcName: '同事',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '单位里忽然传起你的闲话，说得有鼻子有眼。',
    options: [
      { id: 'opt_a', text: '一笑置之，清者自清', costAp: 0, effects: { authority: 2, popularity: -2 } },
      { id: 'opt_b', text: '追查源头，正本清源', costAp: 1, effects: { authority: 4, popularity: 2, energy: -6 } },
      { id: 'opt_c', text: '找人放话压下去', costAp: 1, effects: { mgmt: 4, risk: 4, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_common_c_overtime',
    title: '连轴转',
    npcName: '主任',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'health',
    description: '这段时间任务一个接一个，你已经连续加班大半个月。',
    options: [
      { id: 'opt_a', text: '继续顶住', costAp: 1, effects: { kpi: 6, energy: -15, health: -6 } },
      { id: 'opt_b', text: '请个假歇两天', costAp: 0, effects: { health: 8, energy: 6, kpi: -4 } },
      { id: 'opt_c', text: '把任务分下去', costAp: 1, effects: { mgmt: 4, kpi: 2, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_common_t_temptation',
    title: '深夜的来电',
    npcName: '某老板',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'risk',
    description: '深夜，一个陌生号码打进来，对方自称是"朋友的朋友"，说有一笔"不会有人知道"的买卖。',
    options: [
      { id: 'opt_a', text: '直接挂断', costAp: 0, effects: { risk: -5 } },
      { id: 'opt_b', text: '听对方说完', costAp: 1, effects: { risk: 25 }, gainIllicit: 1000000 },
      { id: 'opt_c', text: '记下号码，报给纪检', costAp: 1, effects: { risk: -6, authority: 3 } }
    ]
  },

  // ── 下面再补一批"选择即后果"的分支事件 ──
  {
    id: 'evt_extra_common_k_charity',
    title: '一笔匿名捐款',
    npcName: '慈善机构',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '有人以你的名义给山区学校捐了一笔钱。你并不知情。',
    options: [
      { id: 'opt_a', text: '查清楚是谁，主动上报', costAp: 1, effects: { authority: 4, risk: -3, energy: -4 }, setFlag: { clean_hand: true } },
      { id: 'opt_b', text: '顺水推舟，落个好名声', costAp: 1, effects: { popularity: 8, risk: 4 } },
      { id: 'opt_c', text: '装作不知道', costAp: 0, effects: { risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_common_c_clean_hand',
    title: '纪委的表扬',
    npcName: '纪委 林主任',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '你主动上报匿名捐款的事，纪委在内部通报表扬。',
    options: [
      { id: 'opt_a', text: '借此树立形象', costAp: 1, effects: { authority: 6, popularity: 4 }, needFlag: { clean_hand: true }, needFlagText: '没有这回事' },
      { id: 'opt_b', text: '低调处理', costAp: 0, effects: {} }
    ]
  },
  {
    id: 'evt_extra_common_k_training_new',
    title: '带新人',
    npcName: '新同事 小刘',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '单位来了个新人小刘，分到你手下。有人提醒你，他是"关系户"。',
    options: [
      { id: 'opt_a', text: '一视同仁，认真带', costAp: 1, effects: { popularity: 6, ability: 4, energy: -6 } },
      { id: 'opt_b', text: '敬而远之，别沾边', costAp: 0, effects: { popularity: -2, risk: -2 } },
      { id: 'opt_c', text: '顺着他，卖个人情', costAp: 1, effects: { mgmt: 6, risk: 4, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_common_c_reform',
    title: '改革的阻力',
    npcName: '班子会',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '你要推动一项触动既得利益的改革，班子会上阻力很大。',
    options: [
      { id: 'opt_a', text: '顶住压力推到底', costAp: 1, effects: { kpi: 10, authority: 6, popularity: -6, risk: 3 } },
      { id: 'opt_b', text: '分步走，先易后难', costAp: 1, effects: { kpi: 5, mgmt: 4, energy: -6 } },
      { id: 'opt_c', text: '暂缓，避免得罪人', costAp: 0, effects: { kpi: -5, mgmt: 2 } }
    ]
  },
  {
    id: 'evt_extra_common_t_legacy',
    title: '身后的评价',
    npcName: '老同事',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '你听说，有人在议论你"将来会留下什么"。',
    options: [
      { id: 'opt_a', text: '多做打基础利长远的事', costAp: 1, effects: { kpi: 6, authority: 4, risk: -2 } },
      { id: 'opt_b', text: '多做见效快的事', costAp: 1, effects: { kpi: 8, risk: 3, energy: -4 } },
      { id: 'opt_c', text: '无所谓', costAp: 0, effects: {} }
    ]
  },

  {
    id: 'evt_extra_town_k_road',
    title: '一条通村路',
    npcName: '村民代表',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '几个村民代表来镇里，说他们村那条路一到雨天就进不去人，孩子上学都成问题。',
    options: [
      { id: 'opt_a', text: '跑上跑下，把修路项目立起来', costAp: 1, effects: { kpi: 8, popularity: 6, energy: -10 } },
      { id: 'opt_b', text: '先登记，等上面拨款', costAp: 0, effects: { kpi: -2, popularity: -2 } },
      { id: 'opt_c', text: '发动群众集资一部分', costAp: 1, effects: { kpi: 5, popularity: 4, risk: 2, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_bureau_k_invoice',
    title: '报销的猫腻',
    npcName: '会计 老许',
    unitType: '常规局委',
    bands: ['科级'],
    theme: 'risk',
    description: '老许递来一沓发票，说"有些话不好明说"，让你签字。你翻了几张，金额对不上。',
    options: [
      { id: 'opt_a', text: '拒签，让他说清楚', costAp: 0, effects: { risk: -4 } },
      { id: 'opt_b', text: '睁只眼闭只眼', costAp: 1, effects: { risk: 10, popularity: 2 }, gainIllicit: 30000 },
      { id: 'opt_c', text: '退回重做', costAp: 1, effects: { kpi: 3, risk: -2, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_core_k_document_leak',
    title: '文件的去向',
    npcName: '机要室 小赵',
    unitType: '核心部门',
    bands: ['科级'],
    theme: 'risk',
    description: '一份内部文件不知去向。小赵急得直哭，说要是查出来是她弄丢的，工作就没了。',
    options: [
      { id: 'opt_a', text: '帮她一起找，按规定上报', costAp: 1, effects: { risk: -4, popularity: 4, energy: -6 } },
      { id: 'opt_b', text: '先压下来，内部处理', costAp: 1, effects: { popularity: 4, risk: 8 } },
      { id: 'opt_c', text: '事不关己', costAp: 0, effects: { popularity: -3, risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_marg_k_archive_digitize',
    title: '档案数字化',
    npcName: '技术员 小周',
    unitType: '边缘部门',
    bands: ['科级'],
    theme: 'daily',
    description: '上级要求限期完成档案数字化。小周说设备老旧、人手不够，根本完不成。',
    options: [
      { id: 'opt_a', text: '争取经费和设备', costAp: 1, effects: { kpi: 6, mgmt: 4, energy: -8 } },
      { id: 'opt_b', text: '如实上报困难', costAp: 0, effects: { risk: -3, kpi: -2 } },
      { id: 'opt_c', text: '赶工，质量先放一边', costAp: 1, effects: { kpi: 4, risk: 4, energy: -10 } }
    ]
  },
  {
    id: 'evt_extra_common_k_old_parents',
    title: '父母的电话',
    npcName: '母亲',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'health',
    description: '母亲打来电话，说你父亲最近身体不好，想让你回家看看。可你手头正忙。',
    options: [
      { id: 'opt_a', text: '请假回家看看', costAp: 1, effects: { health: 6, energy: 4, kpi: -3 } },
      { id: 'opt_b', text: '寄点钱回去，先不回去', costAp: 0, effects: { health: -4, kpi: 2 }, costMoney: 5000 },
      { id: 'opt_c', text: '把父母接来身边', costAp: 1, effects: { health: 8, energy: 4, kpi: -2 }, costMoney: 8000 }
    ]
  },
  {
    id: 'evt_extra_common_c_project_cut',
    title: '被砍的项目',
    npcName: '上级',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '你主抓的一个项目被上级砍了预算，团队士气低落。',
    options: [
      { id: 'opt_a', text: '重新包装，再争取一次', costAp: 1, effects: { kpi: 6, mgmt: 4, energy: -8 } },
      { id: 'opt_b', text: '先稳定军心', costAp: 1, effects: { popularity: 6, mgmt: 3, energy: -6 } },
      { id: 'opt_c', text: '顺其自然', costAp: 0, effects: { kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_common_k_whistleblower',
    title: '匿名举报信',
    npcName: '纪检组',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '一封匿名举报信递到了纪检组，内容与你有关。',
    options: [
      { id: 'opt_a', text: '主动配合，说明情况', costAp: 1, effects: { risk: -8, authority: 2, energy: -6 } },
      { id: 'opt_b', text: '找关系打听是谁写的', costAp: 1, effects: { risk: 10, mgmt: 3 } },
      { id: 'opt_c', text: '不理睬', costAp: 0, effects: { risk: 4 } }
    ]
  },
  {
    id: 'evt_extra_town_c_environment',
    title: '污染企业',
    npcName: '环保办 老吴',
    unitType: '基层乡镇',
    bands: ['处级'],
    theme: 'risk',
    description: '一家纳税大户被群众举报排污，可它是镇里的财神爷。老吴问你怎么办。',
    options: [
      { id: 'opt_a', text: '依法关停整顿', costAp: 0, effects: { popularity: 6, mgmt: -4, kpi: -8 } },
      { id: 'opt_b', text: '先打招呼，让他们整改', costAp: 1, effects: { kpi: 2, risk: 8, mgmt: 4 } },
      { id: 'opt_c', text: '睁只眼闭只眼', costAp: 1, effects: { risk: 15, popularity: -5 }, gainIllicit: 150000 }
    ]
  },
  {
    id: 'evt_extra_bureau_t_policy',
    title: '政策的执行',
    npcName: '厅长',
    unitType: '常规局委',
    bands: ['厅级'],
    theme: 'daily',
    description: '一项新政策落地，各地执行尺度不一。厅长让你拿出一个执行口径。',
    options: [
      { id: 'opt_a', text: '从严执行', costAp: 1, effects: { kpi: 6, risk: -3, popularity: -2 } },
      { id: 'opt_b', text: '从宽执行，保稳定', costAp: 1, effects: { popularity: 5, risk: 3 } },
      { id: 'opt_c', text: '照搬上级文件', costAp: 0, effects: { kpi: -2 } }
    ]
  },
  {
    id: 'evt_extra_common_c_investment',
    title: '亲友的生意',
    npcName: '堂弟',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '堂弟来找你，说想借你的名义参股做生意，收益"五五分"。',
    options: [
      { id: 'opt_a', text: '拒绝，让他自己干', costAp: 0, effects: { risk: -4 } },
      { id: 'opt_b', text: '隐名参股', costAp: 1, effects: { risk: 25 }, gainIllicit: 500000 },
      { id: 'opt_c', text: '帮他介绍正规渠道', costAp: 1, effects: { popularity: 4, risk: -2, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_common_t_thinktank',
    title: '智库的建议',
    npcName: '专家 张教授',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '一份智库报告建议当地产业转型，与现行思路相左。',
    options: [
      { id: 'opt_a', text: '采纳，推动转型', costAp: 1, effects: { kpi: 8, ability: 4, risk: 4 } },
      { id: 'opt_b', text: '搁置，先保增长', costAp: 1, effects: { kpi: 6, risk: 2 } },
      { id: 'opt_c', text: '再论证论证', costAp: 0, effects: { kpi: -2 } }
    ]
  },
  {
    id: 'evt_extra_common_k_snow',
    title: '突发的寒潮',
    npcName: '应急办',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一场罕见寒潮来袭，多地道路结冰，需要有人现场调度。',
    options: [
      { id: 'opt_a', text: '赶赴一线指挥', costAp: 1, effects: { kpi: 6, popularity: 6, energy: -12, health: -3 } },
      { id: 'opt_b', text: '远程调度', costAp: 1, effects: { mgmt: 4, kpi: 3, energy: -6 } },
      { id: 'opt_c', text: '让别人去', costAp: 0, effects: { popularity: -4 } }
    ]
  },
  {
    id: 'evt_extra_common_c_retirement_talk',
    title: '退休前的谈话',
    npcName: '组织部',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '组织上找你谈话，聊聊你退休前的想法和安排。',
    options: [
      { id: 'opt_a', text: '站好最后一班岗', costAp: 1, effects: { authority: 6, kpi: 4, risk: -2 } },
      { id: 'opt_b', text: '开始安排退路', costAp: 1, effects: { risk: 10, popularity: -2 }, gainIllicit: 300000 },
      { id: 'opt_c', text: '顺其自然', costAp: 0, effects: {} }
    ]
  },
  {
    id: 'evt_extra_common_k_commendation',
    title: '一封感谢信',
    npcName: '群众',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '你帮过的一位群众辗转寄来一封感谢信，单位里传开了。',
    options: [
      { id: 'opt_a', text: '低调看待，继续干活', costAp: 0, effects: { authority: 3, kpi: -3 } },
      { id: 'opt_b', text: '借势宣传一下单位形象', costAp: 1, effects: { popularity: 6, authority: 2, energy: -4 } },
      { id: 'opt_c', text: '把功劳记到团队头上', costAp: 1, effects: { popularity: 8, mgmt: 4 } }
    ]
  },

  // ── 破格提拔的三条触发理由（2.3.0）──────────────────────────
  // merit / excellent / elite 三个 flag，是 evaluateBreakthrough 的触发条件。
  // 平时是攒资源还是攒 flag，走的是两条路——这些事件就是"攒 flag"的路。

  {
    id: 'evt_extra_common_merit',
    title: '急难险重任务',
    npcName: '上级指挥部',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '突发险情，上级点将：由你带队上一线处置。',
    options: [
      { id: 'opt_a', text: '带头冲上一线', costAp: 1, effects: { kpi: 15, popularity: 8, energy: -12, health: -6 }, setFlag: { merit: true } },
      { id: 'opt_b', text: '坐镇后方，稳妥调度', costAp: 1, effects: { kpi: 8, mgmt: 6, energy: -4 } },
      { id: 'opt_c', text: '把任务转给别人', costAp: 0, effects: { authority: -6, popularity: -6, risk: -2 } }
    ]
  },

  {
    id: 'evt_extra_common_excellent',
    title: '年度考核评优',
    npcName: '考核组',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '你这一年的工作有目共睹，考核组拟给你评"优秀"。',
    options: [
      { id: 'opt_a', text: '接受评优，再接再厉', costAp: 1, effects: { authority: 6, mgmt: 4 }, setFlag: { excellent: true } },
      { id: 'opt_b', text: '把优秀让给老同志', costAp: 1, effects: { popularity: 8, kpi: -8 } },
      { id: 'opt_c', text: '婉拒，说自己还年轻', costAp: 0, effects: { risk: -2, authority: -2 } }
    ]
  },

  {
    id: 'evt_extra_common_elite',
    title: '上级机关公开遴选',
    npcName: '组织部',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '上级机关面向基层公开遴选，条件你刚好都符合。',
    options: [
      { id: 'opt_a', text: '报名，全力备考', costAp: 1, requires: { ability: 50 }, effects: { ability: 4, energy: -8 }, setFlag: { elite: true } },
      { id: 'opt_b', text: '安心基层，不折腾', costAp: 0, effects: { mgmt: 4, kpi: -8 } },
      { id: 'opt_c', text: '推荐能力强的同事去', costAp: 0, effects: { popularity: 6, kpi: -12 } }
    ]
  },

  // ═══════════════ 家庭生活线（2.4.0 模块 7）═══════════════
  {
    id: 'evt_extra_family_marriage',
    title: '谈婚论嫁',
    npcName: '家人',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '对象家里催着把婚事定了，可房子还没影。在高线城市安个家，不是小数。',
    options: [
      { id: 'opt_a', text: '咬牙凑首付，先安家', costAp: 1, costMoney: 200000, effects: { health: 4, popularity: 4, energy: -6 } },
      { id: 'opt_b', text: '先租房，攒两年再说', costAp: 0, effects: { health: -3, popularity: -2 } },
      { id: 'opt_c', text: '找家里帮衬', costAp: 1, effects: { popularity: 2, risk: 2 } }
    ]
  },
  {
    id: 'evt_extra_family_school',
    title: '子女学区择校',
    npcName: '配偶',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '孩子要上小学了，好学校名额紧。按政策排队，还是找熟人打个招呼？',
    options: [
      { id: 'opt_a', text: '按政策排队，不搞特殊', costAp: 1, effects: { risk: -4, popularity: 3 } },
      { id: 'opt_b', text: '托熟人打个招呼', costAp: 1, effects: { mgmt: 4, risk: 6, popularity: 2 } },
      { id: 'opt_c', text: '顺其自然，能上哪上哪', costAp: 0, effects: { health: -2 } }
    ]
  },
  {
    id: 'evt_extra_family_parent_sick',
    title: '父母重病陪护',
    npcName: '老家电话',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'health',
    description: '老家打来电话，父亲住院了。请假回去陪护，还是请个护工？',
    options: [
      { id: 'opt_a', text: '请假回去陪几天', costAp: 1, effects: { energy: -8, health: 3, popularity: 2, kpi: -6 } },
      { id: 'opt_b', text: '请护工，打钱回去', costAp: 0, costMoney: 30000, effects: { energy: -2, health: 2 } },
      { id: 'opt_c', text: '托亲戚照看', costAp: 0, effects: { popularity: -3, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_family_birthday',
    title: '老人过寿',
    npcName: '家族群',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '老爷子七十大寿，家里人张罗着要大办一场，还想借你的面子请些人来。',
    options: [
      { id: 'opt_a', text: '大操大办，热闹一场', costAp: 1, costMoney: 80000, effects: { popularity: 6, risk: 8, authority: -3 } },
      { id: 'opt_b', text: '简办，家里人吃顿饭', costAp: 1, effects: { risk: -4, popularity: 2 } },
      { id: 'opt_c', text: '不办，工作走不开', costAp: 0, effects: { popularity: -4, health: -2 } }
    ]
  },
  {
    id: 'evt_extra_family_spouse_biz',
    title: '家属想做生意',
    npcName: '配偶',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'risk',
    description: '配偶看中一个项目，想借着你的关系做点生意。你心里清楚，这买卖不好沾。',
    options: [
      { id: 'opt_a', text: '明确反对，划清界限', costAp: 0, effects: { risk: -5, popularity: -2, mgmt: -2 } },
      { id: 'opt_b', text: '睁一只眼闭一只眼', costAp: 0, effects: { risk: 12, popularity: 3 }, gainIllicit: 100000 },
      { id: 'opt_c', text: '帮她找份正经工作', costAp: 1, effects: { popularity: 3, energy: -4, risk: -2 } }
    ]
  },
  {
    id: 'evt_extra_family_second_child',
    title: '要不要二孩',
    npcName: '家人',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '家里商量着再要一个孩子，可带娃、开销、精力都是实打实的账。',
    options: [
      { id: 'opt_a', text: '要，家里再添一口', costAp: 1, effects: { health: -5, energy: -5, popularity: 3 } },
      { id: 'opt_b', text: '先不要，事业要紧', costAp: 0, effects: { mgmt: 2, popularity: -4 } },
      { id: 'opt_c', text: '听伴侣的', costAp: 1, effects: { popularity: 3, energy: -2 } }
    ]
  },

  // ═══════════════ 派系与空降（2.4.0 模块 3）═══════════════
  {
    id: 'evt_extra_faction_airborne_arrival',
    title: '空降新领导',
    npcName: '组织部',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '单位来了位空降的一把手，本地老班底和新来的领导已经暗暗较上了劲。你站哪边？',
    options: [
      { id: 'opt_a', text: '支持新政，向新领导靠拢', costAp: 1, effects: { mgmt: 8, popularity: -5 }, setFlag: { faction: 'parachute' } },
      { id: 'opt_b', text: '跟着本土老班底', costAp: 1, effects: { popularity: 8, mgmt: -5 }, setFlag: { faction: 'local' } },
      { id: 'opt_c', text: '两头不沾，专心干事', costAp: 0, effects: { risk: -4, energy: -4 }, setFlag: { faction: 'independent' } }
    ]
  },
  {
    id: 'evt_extra_faction_hazing',
    title: '本土派的下马威',
    npcName: '老资格',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '你空降过来，本地的几个老资格明里暗里给你使绊子：材料拖着不报，会上阴阳怪气。',
    options: [
      { id: 'opt_a', text: '硬碰硬，立规矩', costAp: 1, effects: { authority: 8, popularity: -6, risk: 3 } },
      { id: 'opt_b', text: '主动示好，慢慢磨合', costAp: 1, effects: { popularity: 8, authority: -4, energy: -4 } },
      { id: 'opt_c', text: '忍一时，用业绩说话', costAp: 0, effects: { kpi: 3, popularity: -6, energy: -6, health: -3 } }
    ]
  },
  {
    id: 'evt_extra_faction_mentor_fall',
    title: '靠山倒台',
    npcName: '纪委通报',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'risk',
    description: '你过去的老领导被查了，通报里点了几个他"带出来的人"。你与他过往甚密。',
    options: [
      { id: 'opt_a', text: '主动向组织说明情况', costAp: 1, effects: { risk: -5, authority: -4 }, setFlag: { faction_fallen: true } },
      { id: 'opt_b', text: '静观其变，装不知道', costAp: 0, effects: { risk: 10, popularity: -3 }, setFlag: { faction_fallen: true } },
      { id: 'opt_c', text: '公开划清界限', costAp: 1, effects: { popularity: -5, risk: -2, authority: 2 } }
    ]
  },
  {
    id: 'evt_extra_faction_reshuffle',
    title: '换届站队',
    npcName: '老同事',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '换届在即，几个派系都在拉人。站对边，往后的路顺；站错边，一凉凉五年。',
    options: [
      { id: 'opt_a', text: '押注势头最盛的那位', costAp: 1, effects: { mgmt: 10, risk: 5, popularity: -3 } },
      { id: 'opt_b', text: '保持中立，不掺和', costAp: 0, effects: { risk: -4, mgmt: -4 } },
      { id: 'opt_c', text: '看谁踏实干事就跟谁', costAp: 1, effects: { kpi: 6, authority: 4 } }
    ]
  },

  // ═══════════════ 下属联动（2.4.0 模块 3）═══════════════
  {
    id: 'evt_extra_sub_merit',
    title: '下属立功受奖',
    npcName: '办公室',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '你带的下属在急难险重任务里立了功，上级点名表扬。这功劳怎么算？',
    options: [
      { id: 'opt_a', text: '如实上报，功劳归团队', costAp: 1, effects: { popularity: 6, kpi: 6, authority: 3 } },
      { id: 'opt_b', text: '把功劳记到自己头上', costAp: 0, effects: { authority: 6, popularity: -8, mgmt: -4 } },
      { id: 'opt_c', text: '重点培养，压更重的担子', costAp: 1, effects: { kpi: 8, energy: -4 }, setFlag: { mentor: true } }
    ]
  },
  {
    id: 'evt_extra_sub_corrupt',
    title: '下属贪腐被查',
    npcName: '纪委',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'risk',
    description: '你重用的一个下属出事了，涉案金额不小。上面问你：当初是怎么把他提上来的？',
    options: [
      { id: 'opt_a', text: '主动担责，检讨用人失察', costAp: 1, effects: { authority: -8, risk: 6, popularity: 2 } },
      { id: 'opt_b', text: '推说不知情', costAp: 0, effects: { risk: 12, mgmt: -6 } },
      { id: 'opt_c', text: '配合调查，如实说明', costAp: 1, effects: { risk: 4, authority: -3, popularity: 3 } }
    ]
  },
  {
    id: 'evt_extra_sub_tip',
    title: '心腹报信',
    npcName: '外放心腹',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'daily',
    description: '你外放出去的心腹悄悄递来一句话：最近上面在查一批账，风向不对，让你早做准备。',
    options: [
      { id: 'opt_a', text: '赶紧把账面捋干净', costAp: 1, effects: { risk: -8, energy: -4 } },
      { id: 'opt_b', text: '先按兵不动', costAp: 0, effects: { risk: 4 } },
      { id: 'opt_c', text: '问问还有没有别的风声', costAp: 1, effects: { mgmt: 4, energy: -2 } }
    ]
  },

  // ═══════════════ 舆情危机（2.4.0 模块 5）═══════════════
  {
    id: 'evt_extra_opinion_demolish',
    title: '强拆风波',
    npcName: '基层',
    unitType: '基层乡镇',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '辖区里一处征迁出了事，视频被传到网上，评论炸了锅。',
    options: [
      { id: 'opt_a', text: '现场办公，当面回应', costAp: 1, effects: { kpi: 4, energy: -6, health: -3 }, addSentiment: -8 },
      { id: 'opt_b', text: '压热度，先拖一拖', costAp: 0, effects: { risk: 6, mgmt: 2, popularity: -4 }, addSentiment: 12 },
      { id: 'opt_c', text: '依法依规，该赔赔该改改', costAp: 1, effects: { popularity: 6, risk: -3, kpi: -4 }, addSentiment: -5 }
    ]
  },
  {
    id: 'evt_extra_opinion_petition',
    title: '敷衍信访',
    npcName: '信访办',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '一位老上访户的事拖了三年，今天又堵在门口。围观的人举着手机拍。',
    options: [
      { id: 'opt_a', text: '亲自接待，承诺限期解决', costAp: 1, effects: { popularity: 6, kpi: 4, energy: -5 }, addSentiment: -6 },
      { id: 'opt_b', text: '让信访办照旧答复', costAp: 0, effects: { risk: 4 }, addSentiment: 8 },
      { id: 'opt_c', text: '协调相关部门联合接访', costAp: 1, coord: true, effects: { kpi: 6, popularity: 4, energy: -4 }, addSentiment: -4 }
    ]
  },
  {
    id: 'evt_extra_opinion_accident',
    title: '安全事故',
    npcName: '应急办',
    unitType: '常规局委',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '辖区一家企业出了安全事故，有人员伤亡。媒体已经在现场了。',
    options: [
      { id: 'opt_a', text: '第一时间到场，如实通报', costAp: 1, effects: { authority: 6, kpi: 4, risk: -3 }, addSentiment: -8 },
      { id: 'opt_b', text: '先内部捂一捂', costAp: 0, effects: { risk: 10, mgmt: 2 }, addSentiment: 15 },
      { id: 'opt_c', text: '责成企业担责，从严整改', costAp: 1, effects: { popularity: 6, kpi: 6, mgmt: -4 }, addSentiment: -5 }
    ]
  },
  {
    id: 'evt_extra_opinion_rumor',
    title: '网络谣言',
    npcName: '网信办',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '网上突然传你"包庇亲属经商"，传得有鼻子有眼。明明是无中生有。',
    options: [
      { id: 'opt_a', text: '公开澄清，主动回应', costAp: 1, effects: { authority: 4, popularity: 4 }, addSentiment: -10 },
      { id: 'opt_b', text: '冷处理，等热度过去', costAp: 0, effects: { health: -3 }, addSentiment: 4 },
      { id: 'opt_c', text: '报案，追究造谣者', costAp: 1, effects: { authority: 6, risk: -2, popularity: -2 }, addSentiment: -6 }
    ]
  },

  // ═══════════════ 面子工程 vs 民生实事（2.4.0 模块 6）═══════════════
  {
    id: 'evt_extra_project_vanity',
    title: '亮化工程',
    npcName: '分管领导',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '上面要出"看得见的成绩"，亮化工程工期短、见效快，可那钱本来要修村里断头路的。',
    options: [
      { id: 'opt_a', text: '上亮化工程，出成绩', costAp: 1, effects: { kpi: 15, authority: 5, risk: 3 }, setFlag: { vanity: true } },
      { id: 'opt_b', text: '把钱投给民生实事', costAp: 1, effects: { kpi: 4, popularity: 10, mgmt: -4 }, setFlag: { livelihood: true } },
      { id: 'opt_c', text: '两边都做，量力而行', costAp: 0, effects: { kpi: 3, popularity: -6, energy: -6, risk: -2 } }
    ]
  },
  {
    id: 'evt_extra_project_boom',
    title: '面子工程的善后',
    npcName: '审计',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'risk',
    needFlag: { vanity_boom: true },
    description: '当年那个"面子工程"已经爆雷，追责的会开过了，如今要你拿出一个善后方案。',
    options: [
      { id: 'opt_a', text: '承认决策失误，主动整改', costAp: 1, effects: { risk: -6, authority: -4, popularity: 3 } },
      { id: 'opt_b', text: '推给客观原因', costAp: 0, effects: { risk: 6, popularity: -4 } },
      { id: 'opt_c', text: '自掏腰包把窟窿补上', costAp: 1, costMoney: 200000, effects: { risk: -4, kpi: 2, energy: -6 } }
    ]
  },
  {
    id: 'evt_extra_project_harvest',
    title: '民生工程见成效',
    npcName: '群众',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'daily',
    needFlag: { livelihood: true },
    description: '当年打基础、不显山露水的民生工程，如今持续出成效，群众口碑一点点攒起来了。',
    options: [
      { id: 'opt_a', text: '趁势再推进一批', costAp: 1, effects: { kpi: 10, popularity: 8, energy: -6 } },
      { id: 'opt_b', text: '见好就收，稳一稳', costAp: 0, effects: { risk: -3, energy: -2 } },
      { id: 'opt_c', text: '总结经验，向上汇报', costAp: 1, effects: { mgmt: 6, authority: 4 } }
    ]
  },

  // ═══════════════ 立功与荣誉（2.4.0 破格触发理由补充）═══════════════
  {
    id: 'evt_extra_merit_commendation',
    title: '重大任务立功',
    npcName: '组织',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '你牵头的一项急难险重任务圆满完成，上级拟给你记功。',
    options: [
      { id: 'opt_a', text: '接受表彰，再接再厉', costAp: 1, effects: { authority: 8, mgmt: 6, popularity: 3 }, setFlag: { merit: true } },
      { id: 'opt_b', text: '把荣誉让给一线', costAp: 1, effects: { popularity: 10, authority: -2 } },
      { id: 'opt_c', text: '婉拒，说都是分内事', costAp: 0, effects: { risk: -3, energy: -2 } }
    ]
  },
  {
    id: 'evt_extra_merit_national',
    title: '国家级表彰',
    npcName: '省里',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '你主抓的一项工作获得国家级表彰，这在你的履历上是重重的一笔。',
    options: [
      { id: 'opt_a', text: '以此为契机，再上台阶', costAp: 1, effects: { authority: 10, mgmt: 8, kpi: 6 }, setFlag: { merit: true } },
      { id: 'opt_b', text: '归功于集体', costAp: 1, effects: { popularity: 8, mgmt: 2 } },
      { id: 'opt_c', text: '低调处理', costAp: 0, effects: { risk: -2, energy: -2 } }
    ]
  },
  {
    id: 'evt_extra_excellent_year',
    title: '连续评优',
    npcName: '考核组',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'daily',
    description: '你已经连续两年年度考核"优秀"，这在单位里很少见。',
    options: [
      { id: 'opt_a', text: '保持这股劲头', costAp: 1, effects: { authority: 6, kpi: 6 }, setFlag: { excellent: true } },
      { id: 'opt_b', text: '把机会留给别人', costAp: 1, effects: { popularity: 8, kpi: -6 } },
      { id: 'opt_c', text: '平常心看待', costAp: 0, effects: { risk: -2, energy: -2 } }
    ]
  },

  // ═══════════════ 出身专属（2.5.0）═══════════════
  // 出身决定起点，也决定这一局能遇见什么。needBackground 卡出身，
  // 只有对应的起跑线才抽得到——选调生有组织重点关注的戏码，
  // 军转干部有转业安置的戏码，事业编有基层转岗的戏码。
  {
    id: 'evt_extra_bg_xuandiao_talk',
    title: '组织部的谈心谈话',
    npcName: '组织科长 老周',
    unitType: '通用',
    bands: ['科级'],
    theme: 'daily',
    needBackground: 'xuandiao',
    description: '作为定向选调生，组织部定期找你谈心。老周问了你的工作、生活，末了补一句："组织上在重点观察你，别松劲。"',
    options: [
      { id: 'opt_a', text: '如实汇报，表明决心', costAp: 1, effects: { mgmt: 8, ability: 3, energy: -4 } },
      { id: 'opt_b', text: '报喜不报忧', costAp: 0, effects: { mgmt: 3, risk: 8 } },
      { id: 'opt_c', text: '趁机打听下一步安排', costAp: 0, effects: { mgmt: -3, popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_bg_shengkao_rival',
    title: '考场上的老对手',
    npcName: '同事 老周',
    unitType: '通用',
    bands: ['科级'],
    theme: 'daily',
    needBackground: 'shengkao',
    description: '当年省考跟你同一批进来的老周，如今也在这个系统里。他私下约你吃饭，说想"多走动走动"。',
    options: [
      { id: 'opt_a', text: '去，多交个朋友', costAp: 1, effects: { popularity: 6, risk: 2, energy: -4 } },
      { id: 'opt_b', text: '保持君子之交', costAp: 0, effects: { risk: -3, popularity: -2 } },
      { id: 'opt_c', text: '婉拒，埋头工作', costAp: 0, effects: { kpi: 1, popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_bg_shiyebian_roots',
    title: '站所老同事找上门',
    npcName: '老同事 阿强',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needBackground: 'shiyebian',
    description: '你在基层站所时的老同事阿强找上门，为亲戚办低保的事想让你"打个招呼"。',
    options: [
      { id: 'opt_a', text: '按政策讲清楚，帮他把材料理顺', costAp: 1, effects: { popularity: 6, kpi: 3, energy: -5 } },
      { id: 'opt_b', text: '打个电话问问情况', costAp: 0, effects: { popularity: 3, risk: 8 } },
      { id: 'opt_c', text: '一口回绝', costAp: 0, effects: { popularity: -4, authority: 3 } }
    ]
  },
  {
    id: 'evt_extra_bg_rencai_apartment',
    title: '人才公寓的账',
    npcName: '引进办 小许',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needBackground: 'rencai',
    description: '当年引进你时承诺的人才公寓和安家补贴，还有一部分没兑现。小许说"正在走程序"，让你再等等。',
    options: [
      { id: 'opt_a', text: '按合同催办', costAp: 1, effects: { authority: 4, kpi: 2, popularity: -2 } },
      { id: 'opt_b', text: '咽下这口气，息事宁人', costAp: 0, effects: { popularity: -2, energy: -3 } },
      { id: 'opt_c', text: '找分管领导反映', costAp: 1, effects: { mgmt: 4, risk: 3 } }
    ]
  },
  {
    id: 'evt_extra_bg_junzhuan_adapt',
    title: '转业干部的坎',
    npcName: '安置办 老韩',
    unitType: '通用',
    bands: ['科级'],
    theme: 'daily',
    needBackground: 'junzhuan',
    description: '转业到地方，机关里那套文牍你还在适应。老韩好心提醒："你在部队的资历在这儿不算数，得重新熬。"',
    options: [
      { id: 'opt_a', text: '沉下心学业务', costAp: 2, effects: { ability: 8, kpi: 4, energy: -10, health: -3 } },
      { id: 'opt_b', text: '发挥军事化管理长处', costAp: 1, effects: { authority: 5, kpi: 3, popularity: -3 } },
      { id: 'opt_c', text: '心里憋屈，嘴上不说', costAp: 0, effects: { energy: -5, health: -2 } }
    ]
  },

  // ═══════════════ 职级档专属（2.5.0）═══════════════
  {
    id: 'evt_extra_band_k_town_change',
    title: '乡镇换届的风',
    npcName: '镇党委书记 老周',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '乡镇换届临近，班子里人心浮动。书记把你叫去，问你对下一步有什么想法。',
    options: [
      { id: 'opt_a', text: '表态服从组织安排', costAp: 1, effects: { mgmt: 8, popularity: 2, energy: -3 } },
      { id: 'opt_b', text: '说出真实想法', costAp: 0, effects: { authority: 2, mgmt: 2, risk: 8, popularity: -2 } },
      { id: 'opt_c', text: '先观望', costAp: 0, effects: { mgmt: -2, popularity: -1 } }
    ]
  },
  {
    id: 'evt_extra_band_c_county_meeting',
    title: '县委常委会上的分歧',
    npcName: '县委办 主任',
    unitType: '常规局委',
    bands: ['处级'],
    theme: 'daily',
    description: '一次县委常委会上，两位常委为一个项目的选址争了起来，气氛很僵。轮到你发言时，大家都看着你。',
    options: [
      { id: 'opt_a', text: '摆数据，只谈利弊', costAp: 1, effects: { authority: 6, kpi: 4, energy: -5 } },
      { id: 'opt_b', text: '顺着主要领导的意思说', costAp: 0, effects: { mgmt: 6, risk: 8, popularity: -2 } },
      { id: 'opt_c', text: '和稀泥，说再研究', costAp: 0, effects: { popularity: 1, kpi: -2 } }
    ]
  },
  {
    id: 'evt_extra_band_t_city_mayor',
    title: '市长交办的急件',
    npcName: '市政府办 副主任',
    unitType: '常规局委',
    bands: ['厅级'],
    theme: 'daily',
    description: '市长交办了一件急件，限期三天。分管副秘书长催得紧，可下面报上来的数据明显有水分。',
    options: [
      { id: 'opt_a', text: '退回重报，宁可慢一点', costAp: 1, effects: { authority: 5, kpi: -3, risk: -4 } },
      { id: 'opt_b', text: '先按原样报上去', costAp: 0, effects: { mgmt: 4, risk: 8, kpi: 2 } },
      { id: 'opt_c', text: '亲自下去核一遍', costAp: 2, effects: { ability: 5, kpi: 5, energy: -12, health: -4 } }
    ]
  },
  {
    id: 'evt_extra_band_p_province_meeting',
    title: '省政府常务会议',
    npcName: '省政府办 处长',
    unitType: '核心部门',
    bands: ['省部级'],
    theme: 'daily',
    description: '你分管的工作要上省政府常务会议审议。会前，办公厅送来一份汇报稿，让你把关签字。',
    options: [
      { id: 'opt_a', text: '逐字逐句改到满意', costAp: 2, effects: { authority: 6, kpi: 4, energy: -10, health: -3 } },
      { id: 'opt_b', text: '签了，相信下面', costAp: 0, effects: { mgmt: 2, risk: 8 } },
      { id: 'opt_c', text: '把风险点标出来再签', costAp: 1, effects: { ability: 4, authority: 3, energy: -4 } }
    ]
  },

  // ═══════════════ 下属联动（2.5.0）═══════════════
  {
    id: 'evt_extra_sub_promoted',
    title: '下属有了出息',
    npcName: '组织部',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    minGates: { popularity: 40 },
    description: '你培养的一名下属被组织看中，拟提拔到更重要的岗位。消息传来，他第一个来谢你。',
    options: [
      { id: 'opt_a', text: '真心替他高兴，叮嘱两句', costAp: 1, effects: { popularity: 6, mgmt: 4, energy: -2 } },
      { id: 'opt_b', text: '借机给他说说下一步', costAp: 1, effects: { mgmt: 6, risk: 2 } },
      { id: 'opt_c', text: '不动声色，公事公办', costAp: 0, effects: { authority: 3, popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_sub_outpost_info',
    title: '外面的眼睛来报信',
    npcName: '外放心腹',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'risk',
    minGates: { popularity: 50 },
    description: '你外放的心腹深夜打来电话："有人把一份材料递到了纪检，涉及你经手的一个项目，你早做准备。"',
    options: [
      { id: 'opt_a', text: '连夜把材料补齐全', costAp: 1, effects: { risk: -8, energy: -8, kpi: -3 } },
      { id: 'opt_b', text: '先按兵不动，看看风声', costAp: 0, effects: { risk: 4, energy: -2 } },
      { id: 'opt_c', text: '托人去打听来龙去脉', costAp: 1, effects: { risk: -3, popularity: -3 }, costMoney: 30000 }
    ]
  },
  {
    id: 'evt_extra_sub_trouble',
    title: '下属捅了娄子',
    npcName: '纪委 老韩',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '你提携过的一名下属出事了，纪委找你了解情况。有人提醒：他是你提拔的，你脱不了干系。',
    options: [
      { id: 'opt_a', text: '主动说明，配合调查', costAp: 1, effects: { risk: -5, popularity: -3, authority: -2 } },
      { id: 'opt_b', text: '强调与自己无关', costAp: 0, effects: { risk: 6, popularity: -4 } },
      { id: 'opt_c', text: '私下找他说清楚', costAp: 1, effects: { risk: 8, mgmt: -3 } }
    ]
  },

  // ═══════════════ 拓展玩法：家庭/健康/人情/危机（2.5.0）═══════════════
  {
    id: 'evt_extra_life_child_school',
    title: '孩子的升学',
    npcName: '爱人',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '孩子到了升学的节骨眼，爱人打来电话："别人家都托人问了好学校，你就不能上点心？"',
    options: [
      { id: 'opt_a', text: '按学区正常入学', costAp: 1, effects: { risk: -4, popularity: 2, energy: -3 } },
      { id: 'opt_b', text: '托关系找好学校', costAp: 1, effects: { popularity: 4, risk: 8 }, costMoney: 50000 },
      { id: 'opt_c', text: '让爱人去张罗', costAp: 0, effects: { popularity: -2, energy: -2 } }
    ]
  },
  {
    id: 'evt_extra_life_parent_sick',
    title: '父母的身体',
    npcName: '妹妹',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'health',
    description: '妹妹打来电话，说父亲住院了，需要人照顾。你手上正压着好几个急件。',
    options: [
      { id: 'opt_a', text: '请假回去照顾几天', costAp: 1, effects: { health: 8, kpi: -3, mgmt: -2, energy: -4 } },
      { id: 'opt_b', text: '托妹妹多辛苦，自己汇款', costAp: 1, effects: { health: 2, popularity: 2, energy: -2 }, costMoney: 30000 },
      { id: 'opt_c', text: '等忙完这阵再说', costAp: 0, effects: { health: -5, popularity: -3 } }
    ]
  },
  {
    id: 'evt_extra_life_checkup',
    title: '体检单上的箭头',
    npcName: '体检医生',
    unitType: '通用',
    bands: ['科级', '处级', '厅级'],
    theme: 'health',
    description: '体检报告出来了，几项指标标了向上的箭头。医生建议你少熬夜、多运动。',
    options: [
      { id: 'opt_a', text: '从今天起早睡早起', costAp: 1, effects: { health: 10, energy: 4, kpi: -2 } },
      { id: 'opt_b', text: '办张健身卡，周末锻炼', costAp: 1, effects: { health: 6, energy: 3 }, costMoney: 8000 },
      { id: 'opt_c', text: '老毛病了，先扛着', costAp: 0, effects: { health: -6, energy: -3 } }
    ]
  },
  {
    id: 'evt_extra_life_overtime',
    title: '又熬到凌晨',
    npcName: '同事 老周',
    unitType: '核心部门',
    bands: ['科级'],
    theme: 'health',
    description: '这已经是本周第三个通宵。老周劝你："材料明天也能改，命是自己的。"',
    options: [
      { id: 'opt_a', text: '再撑一撑，把材料改完', costAp: 1, effects: { kpi: 6, mgmt: 4, health: -8, energy: -10 } },
      { id: 'opt_b', text: '听劝，回家睡觉', costAp: 0, effects: { health: 5, kpi: -3 } },
      { id: 'opt_c', text: '转给办公室，自己先撤', costAp: 0, effects: { energy: 3, mgmt: -3, kpi: -2 } }
    ]
  },
  {
    id: 'evt_extra_life_wedding',
    title: '同事的喜事',
    npcName: '办公室 小许',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '科室的小许要结婚了，喜帖发到了你桌上。礼金随多少，是个学问。',
    options: [
      { id: 'opt_a', text: '随个正常份子，人到礼到', costAp: 1, effects: { popularity: 5, energy: -3 }, costMoney: 2000 },
      { id: 'opt_b', text: '包个大红包', costAp: 0, effects: { popularity: 6, risk: 4 }, costMoney: 10000 },
      { id: 'opt_c', text: '礼到人不到', costAp: 0, effects: { popularity: -2 }, costMoney: 1000 }
    ]
  },
  {
    id: 'evt_extra_life_mentor_retire',
    title: '老领导的退休宴',
    npcName: '老领导 陈厅',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '带你入行的老领导要退了，退休宴上他拉着你的手："以后的路，自己走稳。"',
    options: [
      { id: 'opt_a', text: '认真敬杯酒，说几句心里话', costAp: 1, effects: { popularity: 6, mgmt: 3, energy: -4 } },
      { id: 'opt_b', text: '趁他还在位，多走动走动', costAp: 1, effects: { mgmt: 6, risk: 3, energy: -3 } },
      { id: 'opt_c', text: '礼数到了就行', costAp: 0, effects: { popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_merit_brave',
    title: '突发险情的处置',
    npcName: '应急办',
    unitType: '基层乡镇',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '辖区突发险情，你在现场组织处置，处置得当，避免了更大的损失。上级要给你记功。',
    options: [
      { id: 'opt_a', text: '接受记功，继续坚守', costAp: 1, effects: { authority: 8, kpi: 6, health: -5, energy: -6 } },
      { id: 'opt_b', text: '把功劳让给一线同志', costAp: 1, effects: { popularity: 10, authority: -2 } },
      { id: 'opt_c', text: '低调处理', costAp: 0, effects: { risk: -2, authority: -1 } }
    ]
  },
  {
    id: 'evt_extra_crisis_mass',
    title: '群体性事件的苗头',
    npcName: '信访办',
    unitType: '基层乡镇',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '一起征地补偿纠纷有激化的苗头，几十号人聚集在镇政府门口。有人主张先拖一拖。',
    options: [
      { id: 'opt_a', text: '亲自到场，当面回应诉求', costAp: 2, effects: { popularity: 8, kpi: 4, authority: 3, energy: -12, risk: -3 } },
      { id: 'opt_b', text: '先拖一拖，等人散了再说', costAp: 0, effects: { risk: 8, popularity: -4 }, addSentiment: 10 },
      { id: 'opt_c', text: '让下面的人去劝返', costAp: 1, effects: { risk: 4, popularity: -2, energy: -4 } }
    ]
  },
  {
    id: 'evt_extra_crisis_safety',
    title: '安全生产的隐患',
    npcName: '应急管理局',
    unitType: '常规局委',
    bands: ['厅级', '省部级'],
    theme: 'risk',
    description: '辖区一家重点企业的安全隐患被督查组点名。企业是纳税大户，地方上有人想保。',
    options: [
      { id: 'opt_a', text: '坚决整改，不留情面', costAp: 2, effects: { authority: 8, kpi: 4, popularity: -4, risk: -5, energy: -8 } },
      { id: 'opt_b', text: '给个缓冲期', costAp: 0, effects: { risk: 8, popularity: 2, kpi: -2 } },
      { id: 'opt_c', text: '派人驻厂督改', costAp: 2, effects: { ability: 5, kpi: 4, energy: -10, risk: -2 } }
    ]
  },
  {
    id: 'evt_extra_work_core_material',
    title: '领导的讲话稿',
    npcName: '秘书长',
    unitType: '核心部门',
    bands: ['科级'],
    theme: 'daily',
    description: '秘书长把一份讲话稿打回三次了，说"高度不够"。离领导开讲还有一夜。',
    options: [
      { id: 'opt_a', text: '通宵打磨第四稿', costAp: 2, effects: { ability: 8, mgmt: 6, health: -8, energy: -15 } },
      { id: 'opt_b', text: '请教老笔杆子', costAp: 1, effects: { ability: 5, popularity: 3, energy: -5 } },
      { id: 'opt_c', text: '把上一稿稍作修改交上去', costAp: 0, effects: { mgmt: -4, kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_work_town_flood',
    title: '汛期的值班',
    npcName: '镇长',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '汛期到了，镇长排班，你被排在夜里巡查水库。连续三天了，人困马乏。',
    options: [
      { id: 'opt_a', text: '坚守岗位，认真巡查', costAp: 2, effects: { kpi: 6, authority: 4, health: -6, energy: -12, popularity: 2 } },
      { id: 'opt_b', text: '跟同事换个班', costAp: 1, effects: { popularity: 2, energy: -2 } },
      { id: 'opt_c', text: '打个卡就回', costAp: 0, effects: { risk: 6, kpi: -3 } }
    ]
  },
  {
    id: 'evt_extra_work_bureau_approve',
    title: '审批窗口的为难',
    npcName: '企业老板 老周',
    unitType: '常规局委',
    bands: ['处级'],
    theme: 'daily',
    description: '一个项目的审批卡在你这里。企业老板托人递话，说"手续齐了，就差您一句话"。',
    options: [
      { id: 'opt_a', text: '照章办事，符合就批', costAp: 1, effects: { authority: 5, kpi: 3, energy: -4 } },
      { id: 'opt_b', text: '先压一压，看看态度', costAp: 0, effects: { risk: 8, mgmt: 2, kpi: -2 } },
      { id: 'opt_c', text: '帮忙加快流程', costAp: 1, effects: { popularity: 4, risk: 5, mgmt: 2 } }
    ]
  },
  {
    id: 'evt_extra_work_archive_tidy',
    title: '档案室的旧账',
    npcName: '档案管理员 老韩',
    unitType: '边缘部门',
    bands: ['科级'],
    theme: 'daily',
    description: '上级要查一批历史档案，可档案室里积压多年，乱得不成样子。老韩愁得直叹气。',
    options: [
      { id: 'opt_a', text: '带头梳理，建个台账', costAp: 2, effects: { ability: 6, kpi: 5, energy: -10, health: -3 } },
      { id: 'opt_b', text: '能应付就应付', costAp: 0, effects: { risk: 5, kpi: -2 } },
      { id: 'opt_c', text: '向上反映人手不够', costAp: 1, effects: { mgmt: 3, popularity: -2 } }
    ]
  },
  {
    id: 'evt_extra_work_attract_invest',
    title: '招商的指标',
    npcName: '招商局 老周',
    unitType: '常规局委',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '季度招商到位资金还差一截。老周递来一个方案：先跟一家企业签个框架协议，把数凑上去。',
    options: [
      { id: 'opt_a', text: '签真的，抓落地', costAp: 2, effects: { kpi: 8, ability: 4, energy: -12, health: -3 } },
      { id: 'opt_b', text: '先签框架，年底再兑现', costAp: 0, effects: { kpi: 4, risk: 8 } },
      { id: 'opt_c', text: '如实上报，不凑数', costAp: 1, effects: { authority: 5, kpi: -4, risk: -4 } }
    ]
  },
  {
    id: 'evt_extra_work_aid',
    title: '对口支援的名单',
    npcName: '组织部',
    unitType: '核心部门',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '组织上要选一批干部到艰苦地区对口支援，你的名字在考虑名单里。',
    options: [
      { id: 'opt_a', text: '主动请缨', costAp: 2, effects: { authority: 10, mgmt: 6, kpi: 4, popularity: -3, health: -5 } },
      { id: 'opt_b', text: '服从组织安排', costAp: 1, effects: { mgmt: 6, popularity: 2 } },
      { id: 'opt_c', text: '以家庭困难为由推辞', costAp: 0, effects: { mgmt: -4, popularity: -3 } }
    ]
  },

  // ══════════════ 政法序列（2.6.0 新增）══════════════
  // 公安办案 / 检察监督 / 法院审判 / 司法矫正 / 纪检监察 五条线的专属事件。
  {
    id: 'evt_legal_police_case',
    title: '挂牌督办的积案',
    npcName: '刑侦队 老张',
    unitType: '公安系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '上面挂牌督办一起积案，限期破案。刑侦队熬了几个通宵，就等你拍板怎么打。',
    options: [
      { id: 'opt_a', text: '亲自坐镇，全力攻坚', costAp: 2, effects: { kpi: 8, authority: 6, energy: -12, health: -3 } },
      { id: 'opt_b', text: '加派人手，按部就班', costAp: 1, effects: { kpi: 4, energy: -6 } },
      { id: 'opt_c', text: '先应付督导组', costAp: 0, effects: { risk: 6, kpi: -2 } }
    ]
  },
  {
    id: 'evt_legal_police_favor',
    title: '说情的电话',
    npcName: '老领导',
    unitType: '公安系统',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '一起案子刚立案，就有老领导打来电话，说涉案的是他一个亲戚，让你"依法办事、手下留情"。',
    options: [
      { id: 'opt_a', text: '顶住压力，公事公办', costAp: 1, effects: { authority: 8, mgmt: -4, risk: -3 } },
      { id: 'opt_b', text: '按老领导意思，轻拿轻放', costAp: 0, effects: { risk: 10, mgmt: 4, popularity: -3 } },
      { id: 'opt_c', text: '拖一拖，看风向', costAp: 0, effects: { risk: 4, kpi: -3 } }
    ]
  },
  {
    id: 'evt_legal_police_stability',
    title: '维稳的任务',
    npcName: '综治办 老李',
    unitType: '公安系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '辖区有群体性事件苗头，上面要求"稳控"。群众的诉求确有合理之处，但维稳指标压着。',
    options: [
      { id: 'opt_a', text: '上门走访，化解矛盾', costAp: 2, effects: { kpi: 6, popularity: 8, energy: -10, health: -3 } },
      { id: 'opt_b', text: '依法处置，守住底线', costAp: 1, effects: { authority: 6, kpi: 3, popularity: -4 } },
      { id: 'opt_c', text: '先把人带回去再说', costAp: 0, effects: { risk: 8, popularity: -4 } }
    ]
  },
  {
    id: 'evt_legal_procurator_approval',
    title: '批捕的请示',
    npcName: '公安 移送组',
    unitType: '检察系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一起影响较大的案子，公安机关报请批捕，但证据还有瑕疵。上面有人打了招呼"尽快办"。',
    options: [
      { id: 'opt_a', text: '顶住压力，退回补侦', costAp: 1, effects: { authority: 8, risk: -3, kpi: -3 } },
      { id: 'opt_b', text: '就现有证据批捕', costAp: 0, effects: { risk: 9, kpi: 3 } },
      { id: 'opt_c', text: '再研究研究', costAp: 0, effects: { kpi: -2, risk: 2 } }
    ]
  },
  {
    id: 'evt_legal_procurator_protest',
    title: '抗诉的决定',
    npcName: '检委会',
    unitType: '检察系统',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '一起判决明显畸轻，群众议论纷纷。要不要抗诉？抗诉可能得罪法院，不抗诉良心过不去。',
    options: [
      { id: 'opt_a', text: '坚决抗诉，维护公正', costAp: 2, effects: { authority: 10, kpi: 5, popularity: 6, mgmt: -4 } },
      { id: 'opt_b', text: '与法院沟通，协调处理', costAp: 1, coord: true, effects: { mgmt: 5, kpi: 2 } },
      { id: 'opt_c', text: '多一事不如少一事', costAp: 0, effects: { risk: 6, authority: -3, popularity: -3 } }
    ]
  },
  {
    id: 'evt_legal_procurator_suggestion',
    title: '检察建议',
    npcName: '被监督单位',
    unitType: '检察系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '你发现某单位监管漏洞，可以发一份检察建议。对方是强势部门，发了可能得罪人。',
    options: [
      { id: 'opt_a', text: '发，盯整改', costAp: 2, effects: { authority: 8, kpi: 6, mgmt: -3 } },
      { id: 'opt_b', text: '发个温和版', costAp: 1, effects: { kpi: 3, popularity: 2 } },
      { id: 'opt_c', text: '算了，别惹麻烦', costAp: 0, effects: { risk: 5, kpi: -2 } }
    ]
  },
  {
    id: 'evt_legal_court_case',
    title: '舆论关注的案子',
    npcName: '合议庭',
    unitType: '法院系统',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '一起案件上了热搜，舆论一边倒。判轻了挨骂，判重了怕上诉，左右为难。',
    options: [
      { id: 'opt_a', text: '依法独立审判', costAp: 2, effects: { authority: 10, kpi: 6, risk: -4 } },
      { id: 'opt_b', text: '兼顾舆情，稳妥处理', costAp: 1, effects: { popularity: 5, kpi: 2, authority: -3 } },
      { id: 'opt_c', text: '请示上级定调', costAp: 0, effects: { mgmt: 2, authority: -6, popularity: -4 } }
    ]
  },
  {
    id: 'evt_legal_court_execute',
    title: '执行难',
    npcName: '申请人 老赵',
    unitType: '法院系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一起判决的执行拖了两年，被执行人"老赖"态度强硬。申请人情绪激动，扬言上访。',
    options: [
      { id: 'opt_a', text: '组织集中执行，啃硬骨头', costAp: 2, effects: { kpi: 8, authority: 6, energy: -10, health: -3 } },
      { id: 'opt_b', text: '调解分期履行', costAp: 1, effects: { popularity: 5, kpi: 3 } },
      { id: 'opt_c', text: '先把申请人安抚住', costAp: 0, effects: { risk: 4, kpi: -3 } }
    ]
  },
  {
    id: 'evt_legal_court_mediate',
    title: '司法调解',
    npcName: '村委会',
    unitType: '法院系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一起邻里纠纷闹到法院，判了案结事不了。你主张多调解，化解矛盾。',
    options: [
      { id: 'opt_a', text: '亲自下村调解', costAp: 2, effects: { popularity: 10, kpi: 5, energy: -8 } },
      { id: 'opt_b', text: '交给调解员', costAp: 1, effects: { popularity: 4, kpi: 2 } },
      { id: 'opt_c', text: '依法判决了事', costAp: 0, effects: { authority: 2, popularity: -4, kpi: -2 } }
    ]
  },
  {
    id: 'evt_legal_justice_correction',
    title: '社区矫正',
    npcName: '司法所',
    unitType: '司法行政',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '社区矫正对象里有几个重点人员，监管人手不够。出了事你要担责，不出事要投入。',
    options: [
      { id: 'opt_a', text: '亲自包干，逐个走访', costAp: 2, effects: { kpi: 6, popularity: 6, energy: -10, health: -3 } },
      { id: 'opt_b', text: '申请增加人手', costAp: 1, effects: { mgmt: 3, kpi: 3 } },
      { id: 'opt_c', text: '签个责任状，层层压下去', costAp: 0, effects: { risk: 6, kpi: -2 } }
    ]
  },
  {
    id: 'evt_legal_justice_aid',
    title: '法律援助',
    npcName: '农民工 老王',
    unitType: '司法行政',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一批农民工讨薪来求助，符合法律援助条件，但经费紧张、律师也少。',
    options: [
      { id: 'opt_a', text: '亲自协调，特事特办', costAp: 2, coord: true, effects: { popularity: 10, kpi: 5, energy: -8 } },
      { id: 'opt_b', text: '按程序办理', costAp: 1, effects: { kpi: 3 } },
      { id: 'opt_c', text: '让他们自己去法院', costAp: 0, effects: { popularity: -5, risk: 3 } }
    ]
  },
  {
    id: 'evt_legal_justice_prison',
    title: '监狱改革',
    npcName: '监狱管理局',
    unitType: '司法行政',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '监狱管理要改革，推行规范化。老干警抵触情绪大，改革阻力不小。',
    options: [
      { id: 'opt_a', text: '亲自抓，稳步推进', costAp: 2, effects: { kpi: 8, authority: 6, energy: -10, mgmt: -3 } },
      { id: 'opt_b', text: '先试点再推开', costAp: 1, effects: { kpi: 4 } },
      { id: 'opt_c', text: '维持现状，不出事就好', costAp: 0, effects: { risk: 6, kpi: -2 } }
    ]
  },
  {
    id: 'evt_legal_discipline_report',
    title: '匿名举报',
    npcName: '信访室',
    unitType: '纪检监察',
    bands: ['科级', '处级'],
    theme: 'risk',
    description: '一封匿名举报信摆上案头，指向你分管领域的一个"能人"干部。查，可能查出问题；不查，可能被追责。',
    options: [
      { id: 'opt_a', text: '立案初核，一查到底', costAp: 2, effects: { authority: 8, kpi: 5, mgmt: -4 } },
      { id: 'opt_b', text: '先谈话提醒', costAp: 1, effects: { kpi: 3, popularity: 2 } },
      { id: 'opt_c', text: '压下来，冷处理', costAp: 0, effects: { risk: 9, mgmt: 2 } }
    ]
  },
  {
    id: 'evt_legal_discipline_talk',
    title: '谈话函询',
    npcName: '老熟人',
    unitType: '纪检监察',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一名干部的函询材料需要你签字。材料里的说法含糊其辞，但对方是老熟人。',
    options: [
      { id: 'opt_a', text: '退回重写，要求说明白', costAp: 1, effects: { authority: 6, risk: -3, popularity: -2 } },
      { id: 'opt_b', text: '按规矩办，一视同仁', costAp: 1, effects: { kpi: 4, authority: 3 } },
      { id: 'opt_c', text: '睁一只眼闭一只眼', costAp: 0, effects: { risk: 8, popularity: -3 } }
    ]
  },
  {
    id: 'evt_legal_discipline_inspect',
    title: '专项巡察',
    npcName: '巡察组',
    unitType: '纪检监察',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '上面布置专项巡察，你带队下去。被巡察单位有的打招呼、有的托关系。',
    options: [
      { id: 'opt_a', text: '顶住说情，如实报告', costAp: 2, effects: { authority: 10, kpi: 6, mgmt: -4 } },
      { id: 'opt_b', text: '抓几个典型，点到为止', costAp: 1, effects: { kpi: 4, risk: 3 } },
      { id: 'opt_c', text: '走走过场', costAp: 0, effects: { risk: 7, kpi: -2 } }
    ]
  },

  // ═══════════════ 2.7.0 政法特权 / 政商 / 督导 / 晋升进度叙事 ═══════════════
  {
    id: 'evt_27_perk_police_duty',
    title: '又一轮值班备勤',
    npcName: '值班室 老王',
    unitType: '公安系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '重大活动安保，全警停休。你的「治安维稳专班」名单上还有几个点位没落实到人。',
    options: [
      { id: 'opt_a', text: '亲自带队顶到最吃劲的点位', costAp: 1, effects: { kpi: 6, popularity: 4, energy: -10, health: -3 } },
      { id: 'opt_b', text: '坐镇指挥，逐点调度', costAp: 1, effects: { mgmt: 5, kpi: 3 } },
      { id: 'opt_c', text: '交班休息，让副手盯', costAp: 0, effects: { risk: 2, popularity: -3 } }
    ]
  },
  {
    id: 'evt_27_perk_prosecutor_rigid',
    title: '说情电话',
    npcName: '老同学',
    unitType: '检察系统',
    bands: ['科级', '处级'],
    theme: 'risk',
    description: '一件审查逮捕案，当事人的家属托到你老同学这儿，电话里绕着弯子要你"高抬贵手"。',
    options: [
      { id: 'opt_a', text: '依法独立审查，不接话', costAp: 2, effects: { authority: 8, kpi: 5, mgmt: -4 } },
      { id: 'opt_b', text: '按规定请示汇报', costAp: 1, effects: { mgmt: 4, risk: -2 } },
      { id: 'opt_c', text: '暗示"事在人为"', costAp: 0, effects: { risk: 8, popularity: -3 } }
    ]
  },
  {
    id: 'evt_27_perk_court_judge',
    title: '合议庭的意见',
    npcName: '审判长',
    unitType: '法院系统',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '一桩标的很大的案子到了你手里，合议庭里两种意见僵持不下，庭长希望你"拿个态度"。',
    options: [
      { id: 'opt_a', text: '依法公正裁判，责任自己扛', costAp: 2, effects: { authority: 8, kpi: 5, popularity: -3 } },
      { id: 'opt_b', text: '多做调解，能调则调', costAp: 1, effects: { popularity: 4, kpi: 2 } },
      { id: 'opt_c', text: '拖着，等风向明朗', costAp: 0, effects: { kpi: -3, popularity: -2 } }
    ]
  },
  {
    id: 'evt_27_perk_justice_mediate',
    title: '村里的陈年积怨',
    npcName: '司法所 老赵',
    unitType: '司法行政',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '两户人家为一条田埂闹了十年，镇里把信访件转到了你这里。普法与调解是你的看家本事。',
    options: [
      { id: 'opt_a', text: '上门调解，一次说透', costAp: 2, effects: { popularity: 8, kpi: 5, energy: -8 } },
      { id: 'opt_b', text: '办一场现场普法会', costAp: 1, effects: { popularity: 5, kpi: 2, energy: -4 } },
      { id: 'opt_c', text: '转回镇里，按程序办', costAp: 0, effects: { popularity: -3 } }
    ]
  },
  {
    id: 'evt_27_patron_dinner',
    title: '企业家设宴',
    npcName: '本地老板 周总',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'risk',
    description: '周总组了个高端饭局，席间要介绍几个"很有能量的朋友"给你认识。去不去，是个态度。',
    options: [
      { id: 'opt_a', text: '出席，只谈项目不谈私交', costAp: 1, effects: { mgmt: 4, risk: 5, popularity: 2 } },
      { id: 'opt_b', text: '婉拒，推说有会', costAp: 0, effects: { risk: -4 } },
      { id: 'opt_c', text: '带上同事同去，留个记录', costAp: 1, effects: { popularity: 3, kpi: 1, energy: -3 } }
    ]
  },
  {
    id: 'evt_27_patron_land',
    title: '一块地的审批',
    npcName: '开发商 吴老板',
    unitType: '常规局委',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '一块工业用地的手续卡在你这一环。吴老板明说：批下来，干股、好处都好商量。',
    options: [
      { id: 'opt_a', text: '按规矩批，不越权', costAp: 1, effects: { kpi: 5, authority: 4, risk: -2 } },
      { id: 'opt_b', text: '收下干股，顺手放行', costAp: 1, effects: { risk: 30, popularity: -4 }, gainIllicit: 2000000 },
      { id: 'opt_c', text: '拖一拖，看看风声', costAp: 0, effects: { kpi: -3, risk: 2 } }
    ]
  },
  {
    id: 'evt_27_patron_whiteglove',
    title: '白手套的提议',
    npcName: '企业家 郑总',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'risk',
    description: '郑总递过来一份方案：豪宅豪车挂在他远房亲戚名下，你照住照开，查不到你头上。',
    options: [
      { id: 'opt_a', text: '不碰这种安排', costAp: 0, effects: { risk: -5 } },
      { id: 'opt_b', text: '点头，走白手套代持', costAp: 1, effects: { risk: 14, mgmt: 3 } },
      { id: 'opt_c', text: '只口头试探，不留把柄', costAp: 1, effects: { mgmt: 3, risk: 4 } }
    ]
  },
  {
    id: 'evt_27_patron_giftbox',
    title: '节前的礼盒',
    npcName: '供货商 老孙',
    unitType: '通用',
    bands: ['科级'],
    theme: 'risk',
    description: '节前，老孙送来一个"土特产"礼盒，拎着格外沉。你打开一角，里面码得整整齐齐。',
    options: [
      { id: 'opt_a', text: '原样退回', costAp: 0, effects: { risk: -3 } },
      { id: 'opt_b', text: '收下，就当土特产', costAp: 1, effects: { risk: 8 }, gainMoney: 20000 },
      { id: 'opt_c', text: '上缴单位纪检', costAp: 1, effects: { authority: 4, risk: -4, popularity: -1 } }
    ]
  },
  {
    id: 'evt_27_campaign_warning',
    title: '督导组要来了',
    npcName: '办公室 小周',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '小周小声告诉你：上面要派专项督导组下来，重点就是你们这条线，已经开始摸排了。',
    options: [
      { id: 'opt_a', text: '主动自查，先整改', costAp: 2, effects: { kpi: 6, risk: -4, authority: 2 } },
      { id: 'opt_b', text: '按部就班，静观其变', costAp: 1, effects: { kpi: 2 } },
      { id: 'opt_c', text: '不当回事', costAp: 0, effects: { risk: 6, kpi: -2 } }
    ]
  },
  {
    id: 'evt_27_campaign_reception',
    title: '督导组到基层接访',
    npcName: '督导组',
    unitType: '基层乡镇',
    bands: ['科级'],
    theme: 'daily',
    description: '督导组不打招呼直接进了村，要现场接访。群众反映的问题，一件件都摆到了你面前。',
    options: [
      { id: 'opt_a', text: '全程陪同，现场办公', costAp: 2, effects: { popularity: 8, kpi: 5, energy: -8 } },
      { id: 'opt_b', text: '安排专人对接、逐件反馈', costAp: 1, effects: { mgmt: 4, popularity: 2 } },
      { id: 'opt_c', text: '避而不见，躲过这阵', costAp: 0, effects: { popularity: -5, risk: 3 } }
    ]
  },
  {
    id: 'evt_27_promo_talk',
    title: '组织上找你谈话',
    npcName: '组织部',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    minGates: { ability: 70 },
    description: '组织部来谈话，问你对下一步工作的想法。言外之意，班子调整的名单里有你的名字。',
    options: [
      { id: 'opt_a', text: '汇报实绩，谈打算', costAp: 1, effects: { mgmt: 6, authority: 4 } },
      { id: 'opt_b', text: '谦虚表态，服从安排', costAp: 1, effects: { popularity: 5, mgmt: 3 } },
      { id: 'opt_c', text: '旁敲侧击打听名单', costAp: 0, effects: { risk: 5, mgmt: -2 } }
    ]
  },
  {
    id: 'evt_27_promo_mentor',
    title: '老领导的一句点拨',
    npcName: '老领导',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '老领导拍拍你的肩："你这一坎差不多了，就差最后那几步。别急，也别忘了该走动的人。"',
    options: [
      { id: 'opt_a', text: '沉下心再干一程', costAp: 1, effects: { kpi: 5, popularity: 3 } },
      { id: 'opt_b', text: '按老领导意思走动走动', costAp: 1, grayBoost: true, effects: { mgmt: 6, risk: 3 }, costMoney: 30000 },
      { id: 'opt_c', text: '不以为然，顺其自然', costAp: 0, effects: { mgmt: -3 } }
    ]
  },
  {
    id: 'evt_27_promo_faction',
    title: '人选前的暗流',
    npcName: '班子里的老熟人',
    unitType: '核心部门',
    bands: ['处级'],
    theme: 'daily',
    description: '常委会讨论人事安排前，各路人马都在走动。你的名字被反复提起，也被反复掂量。',
    options: [
      { id: 'opt_a', text: '主动请缨啃硬任务', costAp: 1, effects: { authority: 6, kpi: 6, risk: 3, energy: -6 } },
      { id: 'opt_b', text: '静观其变，不掺和', costAp: 0, effects: { risk: -2 } },
      { id: 'opt_c', text: '私下打点关键人物', costAp: 1, grayBoost: true, effects: { mgmt: 10, risk: 8 }, costMoney: 80000 }
    ]
  },
  {
    id: 'evt_27_legacy_old_sub',
    title: '当年带过的年轻人',
    npcName: '旧部 小刘',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    minGates: { mgmt: 55 },
    description: '当年你手把手带过的一个年轻人，如今已独当一面。他专程来谢你，说"没有您就没有我的今天"。',
    options: [
      { id: 'opt_a', text: '扶上马，再送一程', costAp: 1, effects: { mgmt: 6, popularity: 4, authority: 3 } },
      { id: 'opt_b', text: '让他放手去闯', costAp: 1, effects: { kpi: 4, popularity: 2 } },
      { id: 'opt_c', text: '保持距离，公私分明', costAp: 0, effects: { popularity: -3 } }
    ]
  },
  {
    id: 'evt_27_review_retire',
    title: '退休前夜',
    npcName: '自己',
    unitType: '通用',
    bands: ['厅级', '省部级'],
    theme: 'daily',
    description: '夜深了，你翻出这些年的工作笔记。快退下来了，有些事该想想清楚：这一路，值不值。',
    options: [
      { id: 'opt_a', text: '把经验写下来，留给后来人', costAp: 1, effects: { popularity: 5, authority: 4, energy: -6 } },
      { id: 'opt_b', text: '站好最后一班岗', costAp: 1, effects: { kpi: 6, popularity: 3 } },
      { id: 'opt_c', text: '顺其自然，不多想', costAp: 0, effects: { kpi: -2 } }
    ]
  },

  // ═══════════════ 2.8.0 白手套暴露度预警 ═══════════════
  {
    id: 'evt_28_patron_audit_warning',
    title: '审计延伸调查',
    npcName: '审计组',
    unitType: '通用',
    bands: ['处级', '厅级', '省部级'],
    theme: 'daily',
    needFlag: { patronWarning: true },
    onceFlag: 'patronWarned',
    description: '你与老板之间的往来太密，审计组延伸调查到了你辖区，老板那边资金链也绷得紧。风声已经起来了，有人开始旁敲侧击打听你俩的关系。',
    options: [
      { id: 'opt_a', text: '低调切割，早做了断', costAp: 1, effects: { risk: -3, mgmt: -2 } },
      { id: 'opt_b', text: '让老板先出去避风头', costAp: 1, effects: { risk: 3, mgmt: 2 } },
      { id: 'opt_c', text: '静观其变，赌它查不到', costAp: 0, effects: { risk: 4, popularity: -2 } }
    ]
  },

  // ═══════════════ 2.9.0 灰色博弈冲刺 ═══════════════
  {
    id: 'evt_29_gray_fast_track',
    title: '政绩的捷径',
    npcName: '围上来的中间人',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '任期考核临近，你的政绩还差一截。有人递来一条"捷径"：用灰色资金打点上下，把几个项目"运作"出成绩。',
    options: [
      { id: 'opt_a', text: '走灰色捷径，快速出成绩', costAp: 1, grayBoost: true, effects: { kpi: 12, mgmt: 6, risk: 10 }, costMoney: 150000 },
      { id: 'opt_b', text: '按部就班，慢慢来', costAp: 1, effects: { kpi: 5, energy: -4 } },
      { id: 'opt_c', text: '拒绝捷径', costAp: 0, effects: { kpi: -2, authority: 2 } }
    ]
  },
  {
    id: 'evt_29_gray_bridge',
    title: '灰色过桥资金',
    npcName: '金桥实业 孙总',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '一个重点项目资金链断裂，眼看要烂尾。孙总表示可以"过桥"垫资，条件是你事后在政策上关照他的公司。',
    options: [
      { id: 'opt_a', text: '用灰色过桥资金救项目', costAp: 1, grayBoost: true, effects: { kpi: 10, mgmt: 4, risk: 12 }, gainIllicit: 200000 },
      { id: 'opt_b', text: '走正规渠道申请资金', costAp: 1, effects: { kpi: 4, energy: -5 } },
      { id: 'opt_c', text: '项目烂尾就烂尾', costAp: 0, effects: { kpi: -6, popularity: -3 } }
    ]
  },

  // ═══════════════ 2.9.0 复合事件链·烂尾楼 ═══════════════
  {
    id: 'evt_29_chain_building_1',
    title: '接手烂尾楼',
    npcName: '分管副县长',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '城西那个烂尾了三年的楼盘，县里决定重启。领导把这事交给你："干成了是政绩，干砸了可就是你的责任。"',
    options: [
      { id: 'opt_a', text: '全力推进，抢工期出成绩', costAp: 1, startChain: 'building', effects: { kpi: 10, risk: 8, energy: -6 } },
      { id: 'opt_b', text: '稳扎稳打，先把账算清', costAp: 1, effects: { kpi: 4, energy: -4 } },
      { id: 'opt_c', text: '推掉这个烫手山芋', costAp: 0, effects: { kpi: -4, risk: -2 } }
    ]
  },
  {
    id: 'evt_29_chain_building_2',
    title: '施工方资金断裂',
    npcName: '农民工 老王',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needFlag: { building_chain: 1 },
    needDue: 'building_due',
    description: '当年你拍板重启的楼盘，施工方资金链断裂了，几十号农民工堵在项目部讨薪。事情发酵得很快。',
    options: [
      { id: 'opt_a', text: '垫资续建，稳住局面', costAp: 1, advanceChain: 'building', setFlag: { building_save: true }, effects: { kpi: 8, popularity: 4, risk: 6 }, costMoney: 200000 },
      { id: 'opt_b', text: '找接盘方，切割风险', costAp: 1, advanceChain: 'building', setFlag: { building_save: true }, effects: { kpi: 6, mgmt: -4, risk: 4 }, costMoney: 300000 },
      { id: 'opt_c', text: '撒手不管，让企业自生自灭', costAp: 0, advanceChain: 'building', setFlag: { building_save: false }, effects: { kpi: -6, popularity: -6, risk: 10 } }
    ]
  },
  {
    id: 'evt_29_chain_building_3a',
    title: '盘活成地标',
    npcName: '县里干部',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needFlag: { building_chain: 2, building_save: true },
    needDue: 'building_due',
    description: '当年那个烂尾楼，几经周折终于盘活了，成了县里的新地标。回头看，这一路的担惊受怕总算有了着落。',
    options: [
      { id: 'opt_a', text: '借势再进一步', costAp: 1, endChain: 'building', effects: { kpi: 15, popularity: 8, authority: 5 } },
      { id: 'opt_b', text: '归功于组织，不居功', costAp: 0, endChain: 'building', effects: {} }
    ]
  },
  {
    id: 'evt_29_chain_building_3b',
    title: '烂尾追责',
    npcName: '审计组',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'risk',
    needFlag: { building_chain: 2, building_save: false },
    needDue: 'building_due',
    description: '当年那个楼盘最终还是烂了尾，债务与信访一起压了过来。审计的追责意见摆上了会，矛头指向你。',
    options: [
      { id: 'opt_a', text: '主动担责，争取从轻', costAp: 1, endChain: 'building', effects: { risk: 12, authority: -6, kpi: -8, popularity: 3 } },
      { id: 'opt_b', text: '找人背锅', costAp: 1, endChain: 'building', effects: { risk: 6, mgmt: -4, popularity: -8 } },
      { id: 'opt_c', text: '装聋作哑，赌它查不深', costAp: 0, endChain: 'building', effects: { risk: 4, popularity: -4, authority: -3 } }
    ]
  },

  // ═══════════════ 2.9.0 复合事件链·招商项目 ═══════════════
  {
    id: 'evt_29_chain_invest_1',
    title: '招商的框架协议',
    npcName: '招商局 老周',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    description: '季度招商到位资金还差一截。老周递来一个方案：先跟一家企业签个框架协议，把数凑上去。',
    options: [
      { id: 'opt_a', text: '签协议，先把数凑上', costAp: 1, startChain: 'invest', effects: { kpi: 10, risk: 7, mgmt: 4 } },
      { id: 'opt_b', text: '真招商，慢慢谈', costAp: 1, effects: { kpi: 5, energy: -5 } },
      { id: 'opt_c', text: '不凑这个数', costAp: 0, effects: { kpi: -3, authority: 2 } }
    ]
  },
  {
    id: 'evt_29_chain_invest_2',
    title: '企业资金链出问题',
    npcName: '远大建设 赵总',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    needFlag: { invest_chain: 1 },
    needDue: 'invest_due',
    description: '当年你签下的那家企业，资金链出了问题，项目眼看要停摆。当初的框架协议，如今成了别人嘴里的"注水招商"。',
    options: [
      { id: 'opt_a', text: '协调银行续贷', costAp: 1, advanceChain: 'invest', setFlag: { invest_save: true }, effects: { kpi: 6, mgmt: 4, risk: 4 }, costMoney: 100000 },
      { id: 'opt_b', text: '帮企业引入战略投资', costAp: 1, advanceChain: 'invest', setFlag: { invest_save: true }, effects: { kpi: 8, popularity: 3, risk: 5 }, costMoney: 150000 },
      { id: 'opt_c', text: '看着它黄', costAp: 0, advanceChain: 'invest', setFlag: { invest_save: false }, effects: { kpi: -8, popularity: -4, risk: 8 } }
    ]
  },
  {
    id: 'evt_29_chain_invest_3a',
    title: '项目投产见效',
    npcName: '市里干部',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'daily',
    needFlag: { invest_chain: 2, invest_save: true },
    needDue: 'invest_due',
    description: '当年那个被质疑的招商项目，最终投产见效，成了区域经济的亮点。当初的"注水"说法不攻自破。',
    options: [
      { id: 'opt_a', text: '打造招商样板', costAp: 1, endChain: 'invest', effects: { kpi: 16, mgmt: 6, popularity: 5 } },
      { id: 'opt_b', text: '归功于组织，不居功', costAp: 0, endChain: 'invest', effects: {} }
    ]
  },
  {
    id: 'evt_29_chain_invest_3b',
    title: '烂尾项目追责',
    npcName: '巡察组',
    unitType: '通用',
    bands: ['处级', '厅级'],
    theme: 'risk',
    needFlag: { invest_chain: 2, invest_save: false },
    needDue: 'invest_due',
    description: '当年那个招商项目彻底黄了，投入打了水漂，巡察组把"注水招商"的旧账翻了出来。',
    options: [
      { id: 'opt_a', text: '主动担责，争取从轻', costAp: 1, endChain: 'invest', effects: { risk: 12, authority: -5, kpi: -8, popularity: 3 } },
      { id: 'opt_b', text: '切割责任', costAp: 1, endChain: 'invest', effects: { risk: 5, mgmt: -5, popularity: -7 } },
      { id: 'opt_c', text: '装聋作哑，赌它查不深', costAp: 0, endChain: 'invest', effects: { risk: 4, popularity: -4, authority: -2 } }
    ]
  },

  // ═══════════════ 2.9.0 复合事件链·旧城改造 ═══════════════
  {
    id: 'evt_29_chain_demolish_1',
    title: '旧城改造启动',
    npcName: '街道办主任',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    description: '旧城改造项目正式启动，涉及上千户居民。这是块硬骨头，也是块大政绩。',
    options: [
      { id: 'opt_a', text: '大干快上，抢进度', costAp: 1, startChain: 'demolish', effects: { kpi: 9, risk: 7, popularity: -3 } },
      { id: 'opt_b', text: '先摸底，再动迁', costAp: 1, effects: { kpi: 4, energy: -5 } },
      { id: 'opt_c', text: '缓一缓，别急着动', costAp: 0, effects: { kpi: -3, risk: -1 } }
    ]
  },
  {
    id: 'evt_29_chain_demolish_2',
    title: '钉子户与补偿纠纷',
    npcName: '拆迁户 老李',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needFlag: { demolish_chain: 1 },
    needDue: 'demolish_due',
    description: '改造推进到一半，冒出几户"钉子户"，补偿谈不拢，闹到了网上。围观的人举着手机拍。',
    options: [
      { id: 'opt_a', text: '提高补偿，快速化解', costAp: 1, advanceChain: 'demolish', setFlag: { demolish_save: true }, effects: { kpi: 6, popularity: 5, risk: 3 }, costMoney: 150000 },
      { id: 'opt_b', text: '依法推进，做细工作', costAp: 1, advanceChain: 'demolish', setFlag: { demolish_save: true }, effects: { kpi: 5, popularity: 3, energy: -6 } },
      { id: 'opt_c', text: '强拆推进，压下去', costAp: 0, advanceChain: 'demolish', setFlag: { demolish_save: false }, effects: { kpi: -4, popularity: -5, risk: 8 }, addSentiment: 8 }
    ]
  },
  {
    id: 'evt_29_chain_demolish_3a',
    title: '顺利搬迁',
    npcName: '居民代表',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'daily',
    needFlag: { demolish_chain: 2, demolish_save: true },
    needDue: 'demolish_due',
    description: '旧城改造终于顺利收尾，上千户居民搬进了新居。当初的僵局，如今成了"依法拆迁、以情动人"的样板。',
    options: [
      { id: 'opt_a', text: '打造改造样板', costAp: 1, endChain: 'demolish', effects: { kpi: 13, popularity: 8, mgmt: 4 } },
      { id: 'opt_b', text: '归功于组织，不居功', costAp: 0, endChain: 'demolish', effects: {} }
    ]
  },
  {
    id: 'evt_29_chain_demolish_3b',
    title: '群体事件',
    npcName: '区委书记',
    unitType: '通用',
    bands: ['科级', '处级'],
    theme: 'risk',
    needFlag: { demolish_chain: 2, demolish_save: false },
    needDue: 'demolish_due',
    description: '强拆激化了矛盾，居民集体上访，网上舆情发酵。区里点名要你说明情况。',
    options: [
      { id: 'opt_a', text: '主动担责化解', costAp: 1, endChain: 'demolish', effects: { risk: 10, authority: -5, popularity: 2, kpi: -6 }, addSentiment: -6 },
      { id: 'opt_b', text: '压下去，封锁消息', costAp: 1, endChain: 'demolish', effects: { risk: 6, popularity: -8, authority: -3 }, addSentiment: 8 },
      { id: 'opt_c', text: '装聋作哑，赌它平息', costAp: 0, endChain: 'demolish', effects: { risk: 5, popularity: -5, authority: -2 } }
    ]
  }
]

export default EXTRA_EVENTS
